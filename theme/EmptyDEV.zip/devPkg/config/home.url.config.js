/*********************************************************************
 * defined home page router file
 * Created by deming-su on 2019/7/5
 *********************************************************************/

const HOME_INDEX_URL = "/static/assets";


export {
    HOME_INDEX_URL
}