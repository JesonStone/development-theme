/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/28
*********************************************************************/

<template>
    <div class="common-default-page">
        <img class="right" src="../../images/common/no-permission.jpg" alt=""/>
    </div>
</template>

<script>
    export default {
        created() {
            // todo something here
        }
    }
</script>