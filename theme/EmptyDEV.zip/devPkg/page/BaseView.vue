/*********************************************************************
* Created by deming-su on 2017/12/30
* 所有继承页面，如果要用到表格分页功能，需要实现getTableData方法
* 实现了精确查询按钮事件，需要给事件一个弹出框ID
*********************************************************************/

<script>
    import { getRequestMethod, postDataRequest, getFullUrl } from "@/api/common";

    export default {
        data() {
            return {
                isInit: true,
                cacheKey: 'page_list_params_cache',
                pageLoading: false,
                pagingData: {
                    size: 15,
                    current: 1,
                    sizes: [15, 30, 50, 100],
                    total: 0
                },
                tableData: {
                    loading: false,
                    column: [],
                    data: []
                },
                exportData: {},
                queryType: 'vague' // vague 当前页面查询类型为模糊查询，accurate 为精确查询
            }
        },
        methods: {
            /* 精确查询框展开收起方法 */
            accurateEvent(id) {
                let node = null;
                if (this.queryType === 'vague') {
                    this.queryType = 'accurate';
                    /* 延时对v-show做保障 */
                    setTimeout(() => {
                        node = document.getElementById(id);
                        if (node) {
                            node.setAttribute('style', `height: ${node.scrollHeight}px;`);
                        }
                    }, 80);
                } else {
                    node = document.getElementById(id);
                    if (node) {
                        node.setAttribute('style', `height: 0;`);
                        setTimeout(() => {
                            this.queryType = 'vague';
                        }, 300);
                    }
                }

            },
            /* 页面获取表格数据 */
            async getTableData() {
                console.log('base view method...');
            },
            /* 分页事件 */
            pagingEvent(val, type) {
                if (!this.isInit) {
                    if (type === 'size') {
                        this.pagingData.size = val;
                        this.pagingData.current = 1;
                    } else {
                        this.pagingData.current = val;
                    }
                    this.getTableData();
                }
            },
            /* 页面错误处理 */
            handleErrorMessage(error, loading) {
                if (!!loading) loading.close();
                this.$message({message: error.message || "服务器错误，请重试"});
            },
            /* 页面导出方法: ids:勾选导出，tableData：表格数据， urlKey：请求地址，isPost：是否是post请求 */
            async exportEvent(ids, tableData, urlKey, isPost) {
                console.log("导出", this.exportData)
                if (!urlKey) return;
                if (ids.length <= 0 && tableData.length <= 0) {
                    this.$message.warning('没有数据提供导出');
                    return;
                }

                let hasIds = ids.length > 0;
                if (tableData.length > 0) {
                    this.tableData.loading = true;
                    let result = {};
                    if (isPost) {
                        result = await postDataRequest(urlKey, hasIds ? {ids: JSON.stringify(ids)} : this.exportData);
                    } else {
                        result = await getRequestMethod(urlKey, hasIds ? {ids: JSON.stringify(ids)} : this.exportData);
                    }
                    this.tableData.loading = false;

                    if (!!result && result.code === 200 && !!result.data) {
                        let file = result.data;
                        let el = document.createElement("a");
                        document.body.appendChild(el);
                        el.setAttribute('download', '');
                        let downUrl = `${getFullUrl('FILE_DOWNLOAD_URL')}?filePath=${encodeURIComponent(file.filePath)}`+
                            `&fileName=${file.fileName}&isDelete=false`;
                        el.href = encodeURI(downUrl);
                        el.target = '_blank';

                        el.click();
                        document.body.removeChild(el);
                    } else {
                        this.$message.error('导出数据错误');
                    }
                }
            }
        },
        created() {

            let _cache = sessionStorage.getItem(this.cacheKey);
            if (!!_cache) {

                try {

                    _cache = JSON.parse(_cache);
                    this.exportData = _cache;

                    /* 对分页数据进行重置 */
                    this.pagingData.size = this.exportData.pageSize;
                    this.pagingData.total = this.exportData.pageTotal;
                    this.pagingData.current = this.exportData.pageNum;
                    sessionStorage.removeItem(this.cacheKey);
                } catch(e) {
                    console.log(e);
                    console.log('===================== publish list base view created ========================');
                }
            }
            this.isInit = false;
        }
    }
</script>