/*********************************************************************
* Static variable file
* Created by deming-su on 2019/11/21
*********************************************************************/

<template>
    <div>
        <!-- content here -->
    </div>
</template>

<script>
    export default {
        created() {
            // todo something here
        }
    }
</script>