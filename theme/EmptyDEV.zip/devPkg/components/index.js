/*********************************************************************
 * Vue directive & filter register file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import * as Filter from "./filter";
import * as Directive from "./directive";
import * as Components from "./components";
import * as Property from "./property";

export default {
    install(Vue) {
        if (!Vue.prototype.$zznode) {
            Vue.prototype.$zznode = {};
        }
        this.registerFilter(Vue);
        this.registerDirective(Vue);
        this.registerPrototype(Vue);
        this.registerComponents(Vue);
    },

    registerFilter(Vue) {
        for (let name in Filter) {
            if (Filter.hasOwnProperty(name)) {
                /* 注册过滤器 */
                Vue.filter(name, Filter[name]);
            }
        }
    },

    registerDirective(Vue) {
        for (let name in Directive) {
            if (Directive.hasOwnProperty(name)) {
                /* 注册指令 */
                Vue.directive(name.toLowerCase(), Directive[name]);
            }
        }
    },

    registerPrototype(Vue) {
        for (let name in Property) {
            if (Property.hasOwnProperty(name)) {
                Property[name].install(Vue);
            }
        }
    },

    registerComponents(Vue) {
        for (let name in Components) {
            if (Components.hasOwnProperty(name)) {
                /* 生成组件key */
                let key = name.replace(/[A-Z]/g, (char, index) => {
                    let res = char.toLowerCase();
                    res = index > 0 ? `-${res}` : res;
                    return res;
                });

                /* 注册组件 */
                Vue.component(key, Components[name]);
            }
        }
    }
};