/*********************************************************************
* Vue MainLayout file
* Created by deming-su on 2019/7/7
*********************************************************************/

<template>
    <div class="application-container">
        <div :class="['layout-main-container', {collapse: menuCollapse}]">
            <div class="nav">
                <navigator-node :menu-path="menuPath" :menu-collapse.sync="menuCollapse"></navigator-node>
            </div>
            <div class="menu">
                <menu-node @changeMenu="changeMenu" :menu-collapse="menuCollapse"></menu-node>
            </div>
            <div class="view">
                <router-view></router-view>
            </div>
        </div>
    </div>
</template>
<script>

    export default {
        data() {
            return {
                menuCollapse: false,
                menuPath: []
            }
        },
        methods: {
            changeMenu(val) {
                this.menuPath = val;
            }
        },
        created() {

        }
    }
</script>