/*********************************************************************
 * Static variable file
 * Created by deming-su on 2019/10/28
 *********************************************************************/

<template>
    <div class="common-default-page">
        <img class="found" src="../../images/common/not-found.png" alt=""/>
    </div>
</template>

<script>
    export default {
        created() {
            // todo something here
        }
    }
</script>