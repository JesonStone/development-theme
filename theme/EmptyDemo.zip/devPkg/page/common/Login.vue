/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/28
*********************************************************************/

<template>
    <div class="login-container">
        <div class="enter-box">
            <div class="title"><i class="icon"></i>Zznode FET</div>
            <span class="sub-title">直真前端开发库，基本功能演示DEMO</span>
            <div class="box">
                <el-row>
                    <el-col :span="12" class="login-type">
                        <span @click="loginType = 'pwd'" :class="['text', {active: loginType === 'pwd'}]">账号登录</span>
                    </el-col>
                    <el-col :span="12" class="login-type">
                        <span @click="loginType = 'phone'" :class="['text', {active: loginType === 'phone'}]">手机登录</span>
                    </el-col>
                </el-row>
                <el-form v-show="loginType === 'pwd'" label-width="0" :model="loginModel">
                    <el-form-item>
                        <el-input prefix-icon="zz-icon-user" v-model="loginModel.userName"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-input prefix-icon="zz-icon-password" v-model="loginModel.userPwd"></el-input>
                    </el-form-item>
                </el-form>
                <el-form v-show="loginType === 'phone'" label-width="0" :model="loginModel">
                    <el-form-item>
                        <el-input prefix-icon="zz-icon-phone" v-model="loginModel.userPhone"></el-input>
                    </el-form-item>
                    <el-row :gutter="16">
                        <el-col :span="14">
                            <el-form-item>
                                <el-input prefix-icon="zz-icon-code" v-model="loginModel.userCode"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="10">
                            <el-form-item>
                                <el-button style="width: 100%;" @click="getValidateCode"
                                           :icon="codeGetting ? 'el-icon-loading' : ''" plain>{{btnText}}</el-button>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
                <el-form label-width="0">
                    <el-form-item>
                        <el-checkbox v-model="rememberUser">记住密码</el-checkbox>
                    </el-form-item>
                </el-form>
                <el-row>
                    <el-col>
                        <el-button @click="loginEvt" style="width: 100%;" type="primary">登录</el-button>
                    </el-col>
                </el-row>
            </div>
        </div>
        <div class="login-copyright">
            Copyright
            <i aria-label="图标: copyright" class="anticon anticon-copyright">
                <svg viewBox="64 64 896 896" focusable="false" class="" data-icon="copyright"
                     width="1em" height="1em" fill="currentColor" aria-hidden="true">
                    <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372zm5.6-532.7c53 0 89 33.8 93 83.4.3 4.2 3.8 7.4 8 7.4h56.7c2.6 0 4.7-2.1 4.7-4.7 0-86.7-68.4-147.4-162.7-147.4C407.4 290 344 364.2 344 486.8v52.3C344 660.8 407.4 734 517.3 734c94 0 162.7-58.8 162.7-141.4 0-2.6-2.1-4.7-4.7-4.7h-56.8c-4.2 0-7.6 3.2-8 7.3-4.2 46.1-40.1 77.8-93 77.8-65.3 0-102.1-47.9-102.1-133.6v-52.6c.1-87 37-135.5 102.2-135.5z"></path></svg>
            </i>
            {{new Date().getFullYear()}} 直真前端技术部
        </div>
    </div>
</template>

<script>
    import { getDataRequest } from "@/api/common";

    export default {
        data() {
            return {
                loginModel: {
                    userName: '',
                    userPwd: '',
                    userPhone: '',
                    userCode: ''
                },
                loginType: 'pwd',
                rememberUser: false,
                btnText: '获取验证码',
                codeGetting: false
            }
        },
        methods: {
            async loginEvt() {

                let _result = await getDataRequest('LOGIN_URL', {userName: this.userName, userPwd: this.userPwd});
                /* 存储token */
                let _d = !!_result && _result.code === 200 ? _result.data : {};
                this.$store.dispatch('setApplicationToken', window.btoa(`${_d.userName}-${_d.userId}-${_d.phone}-${_d.role}-${_d.right}`));
                this.$store.dispatch('setLoginUserInfo', {userInfo: _result.data});
                this.$store.dispatch('setUserMenuData', {menuData: _result.data.menuData});
                this.$router.push("/home");
            },
            async getValidateCode() {

                if (!this.codeGetting) {
                    this.codeGetting = true;
                    this.btnText = "验证码获取中";
                    setTimeout(() => {
                        this.codeGetting = false;
                        this.btnText = "再次获取(60s)";
                        this.loopTime(Date.now());
                    }, 600);
                }
            },
            loopTime(_dist) {
                let _now = Date.now(),
                    _dis = Math.ceil((_now - _dist) / 1000);
                if (_dis < 60) {
                    this.btnText = `再次获取(${60 - _dis}s)`;
                    setTimeout(() => {
                        this.loopTime(_dist);
                    }, 200);
                } else {
                    this.btnText = '获取验证码';
                }
            }
        },
        created() {

        }
    }
</script>