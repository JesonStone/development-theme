/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/**
 * 状态数据库对象
 */
const state = {
    applicationToken: '',
    loginUserInfo: {},
    userMenuData: [],
    currentMenuData: []
};

/**
 * 状态数据库设值方法
 */
const getters = {
    getApplicationToken: state => state.applicationToken,
    getLoginUserInfo: state => state.loginUserInfo,
    getUserMenuData: state => state.userMenuData,
    getCurrentMenuData: state => state.currentMenuData
};

const actions = {
	setApplicationToken({commit}, token) {
        commit('mutationApplicationToken', token);
    },
    setLoginUserInfo({commit}, {userInfo}) {
        commit('mutationLoginUserInfo', {userInfo});
    },
    setUserMenuData({commit}, {menuData}) {
	    commit('mutationUserMenuData', {menuData});
    },
    setCurrentMenuData({commit}, {menuData}) {
	    commit('mutationCurrentMenuData', {menuData});
    }
};

const mutations = {
    mutationApplicationToken(state, token) {
        /* 扭转数据状态 */
        state.applicationToken = token;
    },
    mutationLoginUserInfo(state, {userInfo}) {
        /* 扭转数据状态 */
        state.loginUserInfo = userInfo;
    },
    mutationUserMenuData(state, {menuData}) {
        /* 扭转数据状态 */
        state.userMenuData = menuData;
    },
    mutationCurrentMenuData(state, {menuData}) {
        /* 扭转数据状态 */
        state.currentMenuData = menuData;
    }
};

export default {
	state,
	getters,
	actions,
	mutations
};