/*********************************************************************
 * defined text message page router file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 报告首页路由 */
const MessageIndex = () => {
    return import(/* webpackChunkName: "MessageIndex"*/"../page/home/Index.vue");
};

const routes = [
    { path: "/home", component: MessageIndex, meta: {  }},
    { path: "/dashboard", component: MessageIndex, meta: {  }},
    { path: "/demand/demand_list", component: MessageIndex, meta: {  }},
    { path: "/demand/demand_presentation", component: MessageIndex, meta: {  }},
    { path: "/home", component: MessageIndex, meta: {  }},
    { path: "/home", component: MessageIndex, meta: {  }},
    { path: "/home", component: MessageIndex, meta: {  }},
    { path: "/home", component: MessageIndex, meta: {  }},
];

export default routes;