/*********************************************************************
 * Defined URL path variable for common file
 * Created by deming-su on 2019/11/22
 *********************************************************************/

/* 登录地址 */
const LOGIN_URL = "/mock/common/login.json";

export {
    LOGIN_URL
}