/*********************************************************************
 * Defined navigator component file
 * Created by deming-su on 2019/11/22
 *********************************************************************/

<template>
    <div class="layout-nav-container">
        <i @click="$emit('update:menu-collapse', !menuCollapse)" :class="['collapse-icon', {collapse: menuCollapse}]"></i>
        <div class="breadcrumb-box">
            <div class="item" v-for="(item,i) in breadcrumbList" :key="`breadcrumb_key_${i}`">
                <i v-if="i > 0" class="icon"></i>
                <span :class="['text', {active: i === (breadcrumbList.length - 1)}]">{{item}}</span>
            </div>
        </div>
        <div class="opt-box">
            <i @click="scaleEvt" class="scale-icon"></i>
            <el-popover placement="bottom-end" popper-class="navigator-info-popover" :visible-arrow="false" width="336" trigger="click">
                <navigator-info></navigator-info>
                <i class="info-icon active" slot="reference"></i>
            </el-popover>
            <i class="user-icon"></i>
            <el-popover placement="bottom-end" :visible-arrow="false" width="200" trigger="click">
                <span class="layout-nav-user-item" @click="logoutEvt">退出</span>
                <i class="user-info" slot="reference">{{userInfo.userName}}</i>
            </el-popover>
        </div>
    </div>
</template>

<script>
    import { mapGetters } from "vuex";
    const screenfull = require("screenfull");
    import NavigatorInfo from "@/components/common/NavigatorInfo";

    export default {
        components: { NavigatorInfo },
        props: {
            menuCollapse: {
                type: Boolean,
                default: false
            },
            menuPath: {
                type: Array,
                default: () => []
            }
        },
        watch: {
            menuPath: function(val) {
                console.log(val);
                let _l = [];
                val.map(it => {
                    _l.push(it.label);
                });

                this.breadcrumbList = _l;
            }
        },
        computed: {
            ...mapGetters({
                menuList: 'getUserMenuData',
                userInfo: 'getLoginUserInfo'
            })
        },
        data() {
            return {
                breadcrumbList: []
            }
        },
        methods: {
            logoutEvt() {
                this.$router.push('/');
            },
            scaleEvt() {
                if (screenfull.isEnabled) screenfull.toggle();
            }
        }
    }
</script>