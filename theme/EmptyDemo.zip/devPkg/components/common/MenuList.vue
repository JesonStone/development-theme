/*********************************************************************
* Static variable file
* Created by deming-su on 2019/11/23
*********************************************************************/

<script>
    export default {
        props: {
            menuData: {
                type: Array,
                required: true,
                default: () => []
            },
            menuState: {
                type: Boolean,
                required: true,
                default: false
            }
        },
        render() {

            return this.makeRenderNodes();
        },
        methods: {
            makeRenderNodes() {
                let _children = this.assembleChildren();
                return (
                    <div class={{"layout-menu-list": true, "collapse": this.menuState}}>
                        {_children}
                    </div>
                );
            },
            assembleChildren() {

                let _list = [];
                for (let item of this.menuData) {
                    let _isMenu = item.type === 'menu',
                        _isModule = item.type === 'module',
                        _box = [];

                    if (item.type !== 'menu' && !!item.method && item.method.length > 0) _box = this.makeChildBox(item, 0);

                    let _label = this.menuState ? '' : this.makeLabel(_isMenu, item),
                        _expandIcon = this.menuState ? '' : this.makeExpandIcon(_isModule),
                        _icon = this.makeIcon(item, this.menuState);
                    _list.push(
                        <div class="layout-menu-item">
                            <div class={{"label": true, "active": item.active}}>
                                { _icon }
                                { _label }
                                { _expandIcon }
                            </div>
                            { _box }
                        </div>
                    );
                }
                return _list;
            },
            makeChildBox(data, layer) {
                let _node = [];
                if (!data.method) return [];
                for (let item of data.method) {
                    if (item.type !== 'action') {
                        let _child = [],
                            _isMenu = item.type === 'menu',
                            _isModule = item.type === 'module',
                            _expandIcon = this.makeExpandIcon(_isModule, item);

                        if (!!item.method && item.method.length > 0) _child = this.makeChildBox(item, layer + 1);
                        _node.push(
                            <div class="layout-menu-item">
                                <div class={{"label": true, "active": item.active}} style={{"padding-left": `${this.menuState ? 20 : layer * 24 + 52}px`}}>
                                    <span class={{"text": true, "menu": _isMenu}} onClick={() => this.menuClickEvt(item)}>{item.label}</span>
                                    { _expandIcon }
                                </div>
                                {_child}
                            </div>
                        );
                    }
                }
                return _node.length < 1 ? "" : (
                    <div class={{"layout-menu-content-box": true, "popover": this.menuState}}>
                        <div class="box">{ _node }</div>
                    </div>
                );
            },
            makeIcon(item, tooltip) {
                return !!tooltip && item.type === 'menu' ? (
                    <el-tooltip className="item" effect="dark" content={item.label} placement="right">
                        <i class="icon collapse"
                           onClick={() => this.menuClickEvt(item)}
                           domPropsInnerHTML={item.img}>''</i>
                    </el-tooltip>
                ) : (<i class="icon" domPropsInnerHTML={item.img}></i>)
            },
            makeLabel(_isMenu, item) {
                return (
                    <span class={{"text": true, "menu": _isMenu}}
                          onClick={() => this.menuClickEvt(item)}>{item.label}</span>
                );
            },
            makeExpandIcon(_show) {
                if (_show) {
                    return (
                        <i class="expand" onClick={this.expandEvt}>''</i>
                    );
                } else {
                    return '';
                }
            },
            expandEvt(evt) {
                if (this.menuState) return;
                let _target = evt.target,
                    _pNode = _target.parentNode.parentNode,
                    _isExpand = _pNode.getAttribute('menu-expand-state');
                if (!!_isExpand && _isExpand === 'EXPAND') {
                    _target.setAttribute('class', 'expand');
                    _pNode.setAttribute('menu-expand-state', 'COLLAPSE');
                    _pNode.setAttribute('style', `height: ${_pNode.scrollHeight}px`);
                    setTimeout(() => {
                        _pNode.setAttribute('style', '');
                    });
                } else {
                    _target.setAttribute('class', 'expand active');
                    _pNode.setAttribute('menu-expand-state', 'EXPAND');
                    _pNode.setAttribute('style', `height: ${_pNode.scrollHeight}px`);
                    setTimeout(() => {
                        _pNode.setAttribute('style', 'height: auto')
                    }, 220);
                }
            },
            menuClickEvt(_item) {
                if (_item.type === 'menu') {

                    if (!!_item.data) {
                        this.$store.dispatch('setCurrentMenuData', {menuData: _item.method || {}});
                        this.$router.push(_item.data)
                            .catch(() => {
                                console.log('多次触发一个地址，报的错误，解决可以将vue-router升级至3.1以上');
                            });
                    }
                }
            }
        }
    }
</script>