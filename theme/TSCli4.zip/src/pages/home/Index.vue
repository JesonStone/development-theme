/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/23
*********************************************************************/

<template>
    <list-layout title="测试标题&&test">
        <el-table v-loading="tableData.loading" :data="tableData.data" stripe style="width: 100%">
            <el-table-column v-for="(item,i) in tableData.column"
                            :prop="item.key"
                            :label="item.label"
                            :min-width="item.width"
                            align="center"
                            :key="`table_key_${i}`">
                <template slot-scope="scope">
                    <span v-if="item.link" class="common-table-cell link"
                            @click="tableEvent(scope.column.property, scope.row)">{{scope.row[scope.column.property]}}</span>
                    <el-tooltip v-else-if="item.tooltip" class="item" effect="dark" :content="scope.row[scope.column.property]" placement="top">
                        <span class="common-table-cell">{{scope.row[scope.column.property]}}</span>
                    </el-tooltip>
                    <span v-else class="common-table-cell">{{scope.row[scope.column.property]}}</span>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination background layout="total, prev, pager, next, sizes"
                        style="margin-top: 12px; text-align: right;"
                        @size-change="pagingEvent($event, 'size')"
                        @current-change="pagingEvent($event, 'current')"
                        :page-sizes="pagingData.sizes"
                        :page-size="pagingData.size"
                        :current-page="pagingData.current"
                        :total="pagingData.total"></el-pagination>


        <div>
            <jsx-view></jsx-view>
        </div>
    </list-layout>
</template>

<script lang="ts">
    import {Component} from "vue-property-decorator";
    import BaseView from '../BaseView.vue';
    import { CONFIG_DURATION_ORDER_COLUMN } from '../../config/home.config';
    import JsxView from './JSXView.vue';

    @Component({
        components: {JsxView}
    })
    export default class Index extends BaseView {

        protected async getTableData() {

            this.tableData.loading = true;
            let result = {
                code: 200,
                description: "",
                data: {
                    total: 2222,
                    rows: []
                }
            };

            for (let i = 0;i < this.pagingData.size;i ++) {
                result.data.rows.push({
                    flowId: 'ID-04932RRE9-0' + (i > 9 ? `${i}` : `0${i}`),
                    startTime: '2020-01-01 10:10:10',
                    userName: '中国移动--科技事业群',
                    serviceLevel: '001',
                    serviceType: '互联网数据',
                    county: '长沙',
                    flowStatus: '正常',
                    name: '张三'
                } as never);
            }

            setTimeout(() => {
                this.tableData.loading = false;
                this.tableData.data = result.data.rows;
                this.pagingData.total = result.data.total;
            }, 800)
        }

        private tableEvent(colName: string, row: any) {
            console.log(colName, '====================');
        }

        async created() {
            this.tableData.column = JSON.parse(JSON.stringify(CONFIG_DURATION_ORDER_COLUMN));
            await this.$nextTick();
            this.getTableData();
        }
    }
</script>
