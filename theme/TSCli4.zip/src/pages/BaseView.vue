<script lang="ts">
    import {Component, Vue} from "vue-property-decorator";
    import {PagingData, TableData} from "common";
    import {getFullUrl} from "@/api/common";
    
    @Component
    export default class BaseView extends Vue {
        protected tableData: TableData = {
            data: [],
            column: [],
            loading: false
        };
        public pagingData: PagingData = {
            size: 15,
            current: 1,
            total: 0,
            sizes: [15, 50, 100, 200]
        };
        protected exportData: any;

        protected pagingEvent(val: number, type: string = '') {
            if (type === 'size') {
                this.pagingData.size = val;
                this.pagingData.current = 1;
            } else {
                this.pagingData.current = val;
            }
            this.getTableData();
        }

        protected getTableData() {
            // TODO something
            console.log('get table data... ...');
        }

       protected exportEvent(urlKey: string, tableData = this.tableData.data, ids = []) {
           if (!urlKey) throw new Error('export data url mapping key is required');
           if (ids.length < 1 && tableData.length < 1) {
               this.$message.warning('没有数据提供导出');
               return;
           }

           let _params = ids.length > 0 ? {ids: JSON.stringify(ids)} : this.exportData,
               _str = '',
               el = document.createElement("a");

           for (let _key in _params) {
               if (_params.hasOwnProperty(_key)) {
                   _str += `${_key}=${_params[_key]}&`;
               }
           }

           _str = encodeURI(_str.slice(0, _str.length - 1));
           document.body.appendChild(el);
           el.setAttribute('download', '');
           el.href = `${getFullUrl(urlKey)}?${_str}`;
           el.target = '_blank';

           el.click();
           document.body.removeChild(el);
       }
    };
</script>
