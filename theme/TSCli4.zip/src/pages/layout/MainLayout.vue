/*********************************************************************
 * Vue private main layout file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

<template>
    <div class="application-container">
        <router-view></router-view>
    </div>
</template>

<script lang="ts">
    import { Component, Vue } from "vue-property-decorator";

    @Component
    export default class MainLayout extends Vue {

        protected mounted() {

        }
    };
</script>
