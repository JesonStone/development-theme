<template>
    <component :is="currentLayout"></component>
</template>

<script lang="ts">
    import { Component, Vue, Prop } from "vue-property-decorator";
    import BlankLayout from "./layout/BlankLayout.vue";
    import MainLayout from "./layout/MainLayout.vue";

    @Component({
        components: {BlankLayout, MainLayout}
    })
    export default class extends Vue {
        @Prop({type: String, default: "main-layout"})
        private layout: string;

        get currentLayout() {
            return this.layout;
        }
    };
</script>
