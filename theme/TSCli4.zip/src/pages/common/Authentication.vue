/*********************************************************************
* Static variable file
* Created by deming-su on 2019/11/13
*********************************************************************/

<template>
    <div class="authentication-node">

    </div>
</template>

<script lang="ts">
    import {Vue, Component} from "vue-property-decorator";
    import {Action} from "vuex-class";

    @Component
    export default class Authentication extends Vue {
        @Action('setApplicationToken', {namespace: 'common'})
        private changeToken: (token: string) => void;
        @Action('setApplicationCache', {namespace: 'common'})
        private changeCache: (data: any) => void;

        private authenticationEvt(res: any) {
            if (!!res.token && !!res.remoteOrigin) {
                this.changeToken(res.token);
                this.changeCache(res);
                sessionStorage.setItem('ZZNODE_CF_CUSTOMIZED_TOKEN', res.token);
                sessionStorage.setItem('ZZNODE_CF_CUSTOMIZED_REMOTEORIGIN', res.remoteOrigin);
                this.$router.push("/home");
            } else {
                this.$router.push("/not/right");
            }
        }

        created() {

            let cache: string = localStorage.getItem('CUSTOMIZE_PARAMS_CACHE') as string,
                data: any = {};
            try {
                data = JSON.parse(cache);
                if (!data.token) throw new Error('no token');
                localStorage.clear();
                this.authenticationEvt({
                    token: data.token,
                    pageType: data.pageType,
                    remoteOrigin: data.remoteOrigin,
                    formId: data.formId,
                    dataId: data.dataId
                });
            } catch (e) {
                console.log(e);
                this.$router.push('/not/right');
            }
        }
    }
</script>
