/*********************************************************************
 * Static variable file
 * Created by deming-su on 2019/10/24
 *********************************************************************/


export const CONFIG_DURATION_ORDER_COLUMN = [
    {label: '流程编号', key: 'flowId', minWidth: 160, link: true},
    {label: '发起时间', key: 'startTime', minWidth: 160},
    {label: '客户名称', key: 'userName', minWidth: 160, tooltip: true},
    {label: '服务等级', key: 'serviceLevel', minWidth: 160},
    {label: '业务类型', key: 'serviceType', minWidth: 160},
    {label: '归属区县', key: 'county', minWidth: 160},
    {label: '流程状态', key: 'flowStatus', minWidth: 160},
    {label: '姓名', key: 'name', minWidth: 160}
];
