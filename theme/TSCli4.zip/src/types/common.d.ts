/*********************************************************************
 * project common interface defined file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

/* 请求参数接口 */
interface RequestData {
    url: string;
    method?: string;
    data?: object;
    params?: object;
    contentType?: string;
    urlParam?: any;
    hasUrl?: boolean;
    onUploadProgress?: (progressEvent: any) => void;
}

/* 页面缓存接口 */
interface CommonVuex {
    applicationToken?: string;
    customizeCache?: any;
    currentStepNum?: any;
    applicationCache?: any;
}

/* 列属性 */
interface TableColumnInf {
    label: string;
    key: string;
    width?: number;
    minWidth?: number;
    tooltip?: boolean;
    isLink?: boolean;
    editAble?: boolean;
}

/* 表格接口 */
interface TableData {
    data: any[];
    column: TableColumnInf[];
    loading: boolean;
}

/* 分页接口 */
interface PagingData {
    size: number;
    current: number;
    sizes: number[];
    total: number;
}

export {
    RequestData,
    CommonVuex,
    TableColumnInf,
    TableData,
    PagingData
};
