/*********************************************************************
 * Static variable file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import ToastNode from "@/components/common/Toast.install";

export {
    ToastNode
};