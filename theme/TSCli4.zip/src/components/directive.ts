/*********************************************************************
 * Vue directive file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

const Autofocus = {
    inserted(el: HTMLElement): void {
        el.focus();
    }
};

const Position = {
    inserted(el: HTMLElement, data: any) {
        if (!data) {
            throw new Error("此指令必须传值!");
        }
        let img: string =  data.value,
            parent: HTMLElement = el.parentNode as HTMLElement,
            image = new Image();

        image.onload = function() {
            setTimeout(() => {
                let pRect = parent.getBoundingClientRect();
                if (image.height < pRect.height) {
                    el.setAttribute('style', `margin-top: ${(pRect.height - image.height) / 2}px`);
                }
            }, 160);
        };

        image.src = img;
    }
};

export {
    Autofocus,
    Position
};