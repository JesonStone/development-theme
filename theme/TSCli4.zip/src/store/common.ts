/*********************************************************************
 * common Vue store file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import { Module, ActionTree, GetterTree, MutationTree } from "vuex";
import { CommonVuex } from "common";

const initState: CommonVuex = {
    applicationToken: "",
    applicationCache: {}
};

const getters: GetterTree<any, any> = {
    getApplicationToken(state) {
        return state.applicationToken || "";
    },
    getApplicationCache(state) {
        return state.applicationCache;
    }
};

const actions: ActionTree<any, any> = {
    setApplicationToken({commit}, obj): void {
        commit('mutationApplicationToken', obj);
    },
    setApplicationCache({commit}, data): void {
        commit('mutationApplicationCache', data);
    }
};

const mutations: MutationTree<any> = {
    mutationApplicationToken(state, obj) {
        state.applicationToken = obj;
    },
    mutationApplicationCache(state, data) {
        state.applicationCache = data;
    }
};

export const common: Module<any, any> = {
    namespaced: true,
    state: {...initState},
    getters,
    actions,
    mutations
};
