/* 添加console在IE9下的支持，仅重写了常用的warn，log，error，assert，debug，info */
(function() {
    if(!window.console) {
        window.console = {
            warn: function() {
                // 提示信息
            },
            log: function() {
                // 提示信息
            },
            error: function() {
                // 提示信息
            },
            assert: function() {
                // 提示信息
            },
            debug: function() {
                // 提示信息
            },
            info: function() {
                // 提示信息
            }
        };
    }

    /* 获取页面的url地址解析 */
    window.getRequestUrlParams = function(key) {
        var str = location.search;

        if (!str) {
            var i = location.hash.indexOf('?');
            str = i > -1 ? location.hash.substring(i) : '';
        }

        str = str.substring(1).split('&');

        var _s = key + '=';
        var params = '';
        for (var i = 0;i < str.length;i ++) {
            if (str[i].indexOf(_s) > -1) {
                params = str[i];
                break;
            }
        }

        return params !== '' ? params.replace(_s, '') : '';
    };

    /* 如果是页面引用，需要解析地址参数，然后重定位 */
    var customize_params = getRequestUrlParams('customize_params');

    var customize = "eyJ0b2tlbiI6ImpmZGxzamxmamRzZmxzamxmZGtmZHMiLCJyZW1vdGVPcmlnaW4iOiJodHRwOi8vMTI3LjAuMC4xOjEzNjY2IiwicGFnZVR5cGUiOiJmb3JtLWN1cyIsImZvcm1JZCI6Inh4eHh4IiwiZGF0YUlkIjoieXl5eXkifQ==";
    var render = "eyJ0b2tlbiI6ImpmZGxzamxmamRzZmxzamxmZGtmZHMiLCJyZW1vdGVPcmlnaW4iOiJodHRwOi8vMTI3LjAuMC4xOjEzNjY2IiwicGFnZVR5cGUiOiJmb3JtLXJlbiIsImZvcm1JZCI6Inh4eHh4IiwiZGF0YUlkIjoieXl5eXkifQ==";
    var b = window.btoa(JSON.stringify({
        token:'jfdlsjlfjdsflsjlfdkfds',
        remoteOrigin:'http://127.0.0.1:13666',
        pageType:'form-cus', // 'form-ren' 'plan-cus' 'plan-ren'
        formId:'xxxxx',
        dataId:'yyyyy'
    }));
    if (!!customize_params) {
        localStorage.setItem('CUSTOMIZE_PARAMS_CACHE', window.atob(customize_params));
        var ei = location.href.indexOf('?');
        window.location = location.href.substring(0, ei);
    }
})(window);
