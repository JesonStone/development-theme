const path = require("path"),
    env = process.env.NODE_ENV.trim(),
    isPRD = env === "production",
    outputDir = 'dist',
    title = "VUE-CLI4-DEMO";

const config = {
    publicPath: "./",
    outputDir,
    lintOnSave: false,
    chainWebpack: () => { },
    pages: {
        index: {
            entry: "src/main.ts",
            template: "public/index.html",
            filename: "index.html",
            title
        }
    },
    configureWebpack: config => {
        config.mode = isPRD ? "production" : "development";
        Object.assign(config, {
            resolve: {
                extensions: [".js", ".vue", ".json", ".ts", ".tsx"],
                alias: {
                    "@": path.resolve(__dirname, "./src")
                }
            }
        });
    },
    productionSourceMap: !isPRD,
    css: {
        extract: true,
        sourceMap: false,
        loaderOptions: {},
        modules: false
    },
    parallel: require("os").cpus().length > 1,
    devServer: {
        open: 'Google Chrome',
        openPage: '/index.html',
        host: "localhost",
        port: 13520,
        https: false,
        hotOnly: false,
        proxy: {
            "/plat": {
                target: "http://127.0.0.1:13666",
                // pathRewrite: {"^/apis": ""},
                secure: false
            }
        }
    },
    pluginOptions: {
        // TODO something here
    }
};

if (env !== 'publish') module.exports = config;
