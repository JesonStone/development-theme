/*********************************************************************
 * common Vue store file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import { Module, ActionTree, GetterTree, MutationTree } from "vuex";
import { CommonVuex, MenuData, UserState } from "common";

const initState: CommonVuex = {
    applicationToken: "",
    applicationCache: {},
};

const menuData: MenuData = {
    currentMenuData: []
}

const userState: UserState = {
    userMenuData: []
}

const userInfo: any = {
    userInfo: {}
}

const getters: GetterTree<any, any> = {
    getApplicationToken( state: any ): string {
        return state.applicationToken || "";
    },
    getApplicationCache( state: any ): string{
        return state.applicationCache;
    },
    getUserMenuData( state: any ): any[] {
        return state.currentMenuData
    },
    getCurrentMenuData( state: any ): any[]{
        return state.currentMenuData
    },
    getLoginUserInfo( state: any ): any {
        return state.userInfo.userInfo
    }
};

const actions: ActionTree<any, any> = {
    setApplicationToken({commit}, token): void {
        commit('mutationApplicationToken', token);
    },
    setApplicationCache({commit}, data): void {
        commit('mutationApplicationCache', data);
    },
    setUserMenuData({commit}, menuData): void {
        commit('mutationUserMenuData', menuData);
    },
    setCurrentMenuData({commit}, menuData): void {
        commit('mutationCurrentMenuData', menuData);
    },
    setLoginUserInfo({commit}, {userInfo}): void {
        commit('mutationLoginUserInfo', userInfo);
    },
    resetCommonVuexData({commit}): void {
        commit("mutationApplicationToken", "")
    }
};

const mutations: MutationTree<any> = {
    mutationApplicationToken( state: any, token: string ): void {
        state.applicationToken = token;
    },
    mutationApplicationCache( state: any, data: any ): void {
        state.applicationCache = data;
    },
    mutationUserMenuData( state: any, data: any ): void {
        state.applicationCache = data;
    },
    mutationCurrentMenuData(state: any, menuData: any): void {
        state.currentMenuData = menuData;
    },
    mutationLoginUserInfo(state: any, userInfo: any): void {
        state.loginUserInfo = userInfo;
    },
};

export const common: Module<any, any> = {
    namespaced: true,
    state: {...initState, ...menuData, ...userState, ...userInfo},
    getters,
    actions,
    mutations,
};
