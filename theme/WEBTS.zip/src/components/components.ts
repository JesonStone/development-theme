/*********************************************************************
 * Vue components file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import ListLayout from "@/components/common/ListLayout.vue";

export {
    ListLayout
};
