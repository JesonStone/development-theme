/*********************************************************************
* Static variable file
* Created by deming-su on 2019/11/24
*********************************************************************/

<template>
    <el-tabs>
        <el-tab-pane label="通知（12）">
            <div class="layout-navigator-info">
                <div class="item" v-for="(item,i) in noticeList" :key="`nav_info_${i}`">
                    <i class="icon" v-html="item.icon"></i>
                    <div class="info">
                        <span class="title">{{item.title}}</span>
                        <span class="text">{{item.time}} {{item.userName}}</span>
                    </div>
                </div>
                <div class="item btn">
                    <el-button type="text">更多...</el-button>
                </div>
            </div>
        </el-tab-pane>
        <el-tab-pane label="消息（18）">
            <div class="layout-navigator-info">
                <div class="item" v-for="(item,i) in noticeList" :key="`nav_info_${i}`">
                    <i class="icon" v-html="item.icon"></i>
                    <div class="info">
                        <span class="title">{{item.title}}</span>
                        <span class="text">{{item.time}} {{item.userName}}</span>
                    </div>
                </div>
                <div class="item btn">
                    <el-button type="text">更多...</el-button>
                </div>
            </div>
        </el-tab-pane>
    </el-tabs>
</template>

<script>
    export default {
        data() {
            return {
                noticeList: []
            }
        },
        methods: {
            async getNoticeData() {
                let _result = {
                    code: 200,
                    description: '',
                    data: [
                        {icon: '&#xe606;', title: '【直真科技】用餐审批申请', time: '2019-11-22', userName: '张三娃'},
                        {icon: '&#xe60a;', title: '【直真科技】用餐审批申请', time: '2019-11-22', userName: '张三娃'},
                        {icon: '&#xe609;', title: '【直真科技】用餐审批申请', time: '2019-11-22', userName: '张三娃'},
                        {icon: '&#xe607;', title: '【直真科技】用餐审批申请', time: '2019-11-22', userName: '张三娃'},
                        {icon: '&#xe603;', title: '【直真科技】用餐审批申请', time: '2019-11-22', userName: '张三娃'},
                        {icon: '&#xe600;', title: '【直真科技】用餐审批申请', time: '2019-11-22', userName: '张三娃'},
                        {icon: '&#xe601;', title: '【直真科技】用餐审批申请', time: '2019-11-22', userName: '张三娃'}
                    ]
                };

                this.noticeList = !!_result && _result.code === 200 ? _result.data : [];
            }
        },
        created() {

            /* 可以按需接收，可以使用socket接收 */
            this.getNoticeData();
        }
    }
</script>