<template>
    <div class="layout-menu-container">
        <el-row style="margin-top:20px;margin-bottom: 20px;">
            <span>项目启动信息</span>
        </el-row>
        <el-row :gutter="16">
            <el-col :span="8">
            <el-form-item label="项目启动时间" prop="title">
                    <el-date-picker
                    v-model="pageData.endDate"
                    type="datetime"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    placeholder="选择截止时间"
                ></el-date-picker>
            </el-form-item>
            </el-col>
            <!-- <el-col :span="8">
            <el-form-item label="项目计划结束时间" prop="upperLimit">
                <el-date-picker
                    v-model="pageData.endDate"
                    type="datetime"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    placeholder="选择截止时间"
                ></el-date-picker>
            </el-form-item>
            </el-col>            
            <el-col :span="8">
            <el-form-item label="项目主要内容描述" prop="limitDis">
                <el-date-picker
                    v-model="pageData.endDate"
                    type="datetime"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    placeholder="选择截止时间"
                ></el-date-picker>
            </el-form-item>
            </el-col>
            <el-col :span="8">
            <el-form-item label="项目启动资料" prop="limitDis">
                <el-input v-model="pageData.limitDis" placeholder="请填写时限要求"></el-input>
            </el-form-item>
            </el-col>                                                                     -->
        </el-row>        
    </div>
</template>
<script>
export default {
    props: {
        cols: {
            type: Array,
            required: true,
            default: false
        }
    },
    data(){
        return{
            pageData:{
                endDate:''                
            },
            elCol:[
               [
                   {
                       name:'项目启动',
                   obj:[
                        {label:'项目启动时间',type:'date',value:'endDate'},
                        {label:'项目计划结束时间',type:'date',value:'endDate'},
                        {label:'项目主要内容描述',type:'text',value:'endDate'},
                        {label:'项目启动资料',type:'file',value:'endDate'},                        
                    ]
                    }                                     
               ],
               [
                   {
                       name:'设计批复',
                   obj:[
                        {label:'设计批复时间',type:'date',value:'endDate'},
                        {label:'设计批复文号',type:'text',value:'endDate'},
                        {label:'设计批复金额（元）',type:'text',value:'endDate'},
                        {label:'附件',type:'file',value:'endDate'},                        
                    ]
                    }  
               ],
               [
                    {
                       name:'工程实施',
                   obj:[
                        {label:'实施单位',type:'text',value:'endDate'},
                        {label:'实施负责人',type:'text',value:'endDate'},
                        {label:'实施联系方式',type:'text',value:'endDate'},
                        {label:'监理单位',type:'text',value:'endDate'},                        
                        {label:'监理负责人',type:'text',value:'endDate'},                        
                        {label:'监理联系方式',type:'text',value:'endDate'},                        
                        {label:'设计单位',type:'text',value:'endDate'},                        
                        {label:'设计负责人',type:'text',value:'endDate'},                        
                        {label:'设计联系方式',type:'text',value:'endDate'},                        
                        {label:'预计到货时间',type:'date',value:'endDate'},                        
                        {label:'实际到货时间',type:'date',value:'endDate'},                        
                        {label:'工程实施附件',type:'file',value:'endDate'},                        
                        {label:'是否到货',type:'text',value:'endDate'},                        
                        {label:'到货清单/附件',type:'file',value:'endDate'},                        
                        {label:'是否完工',type:'text',value:'endDate'},                        
                        {label:'工程完工日期',type:'date',value:'endDate'},                        
                        {label:'完工凭证',type:'file',value:'endDate'}                                                                    
                    ]
                    } 
               ],
               [
                   {
                       name:'项目采购',
                   obj:[
                        {label:'采购订单号',type:'date',value:'text'},
                        {label:'采购负责人',type:'text',value:'text'},
                        {label:'成本IT采购金额（元）',type:'text',value:'endDate'},
                        {label:'成本CT采购金额（元）',type:'text',value:'endDate'},                        
                        {label:'资本IT采购金额（元）',type:'text',value:'endDate'},                        
                        {label:'资本CT采购金额（元）',type:'text',value:'endDate'},                        
                        {label:'采购总金额（元）',type:'text',value:'endDate'},                        
                        {label:'采购方式',type:'text',value:'endDate'},                        
                        {label:'采购清单',type:'file',value:'endDate'},                        
                        {label:'采购时间',type:'date',value:'endDate'}                                                                                                               
                    ]
                    } 
               ],
               [
                    {
                       name:'工程验收',
                   obj:[
                        {label:'竣工验收批复时间',type:'date',value:'endDate'},
                        {label:'竣工验收批复文号',type:'text',value:'endDate'},
                        {label:'业主侧验收时间',type:'date',value:'endDate'},
                        {label:'验收报告',type:'file',value:'endDate'}                                                                                                                                                              
                    ]
                    } 
               ]
            ]
        }
    },
}
</script>
<style scoped>
    .layout-menu-container{
        background: none;
    }
</style>
