/*********************************************************************
 * Defined menu component file
 * Created by deming-su on 2019/11/22
 *********************************************************************/

<template>
    <div class="layout-menu-container">
        <div class="brand">
            <i class="icon"></i>
            项目管理系统
        </div>
        <menu-list :menu-state="menuCollapse" :menu-data="menuRenderData"></menu-list>
    </div>
</template>

<script lang="ts">
    // import { mapGetters } from "vuex";
    import MenuList from "./MenuList";
    console.log(MenuList)
    import { Component, Prop, Watch } from "vue-property-decorator";
    import Vue from 'vue';
    import { Getter } from "vuex-class"
    @Component({components:{MenuList}})
    export default class extends Vue {

        @Prop({type: Boolean, default: false})
        private menuCollapse: Boolean;

        @Getter("getUserMenuData", {namespace: "common"})
        public menuData: any;

        menuRenderData: any[] = []
        
        @Watch("$route.path")
        routePath(val: string){
            this.assembleMenu(val);
        }
        assembleMenu(_path: string) {
                let _list = [],
                    _resource = this.menuData.authority || [];
                for (let _item of _resource) {
                    let _l = [];
                    if (!!_item.method && _item.method.length > 0) _l = this.loopData(_item.method, _path);
                    if (_item.type === 'menu') _item.active = _item.data === _path;
                    _item.method = _l;
                    _list.push(_item);
                }

                this.menuRenderData = _list;
                // this.$root.eventBus.$emit('MENU_CHANGE_DATA', this.makeBreadcrumb(_list));
                this.$emit('changeMenu', this.makeBreadcrumb(_list));
        }
        loopData(_data: any, _path: string) {
                let _dist: any = [];
                for (let _item of _data) {
                    let _l = [];
                    if (!!_item.method && _item.method.length > 0) _l = this.loopData(_item.method, _path);
                    if (_item.type === 'menu') _item.active = _item.data === _path;
                    _item.method = _l;
                    _dist.push(_item);
                }
                return _dist;
        }
        makeBreadcrumb(_list: any) {
                let nodes: any = [];
                for (let node of _list) {
                    if (this.loopTree(node, nodes)) {
                        nodes.push(node);
                        break;
                    }
                }
                return nodes.reverse();
        }
        loopTree(node: any, nodes: any) {
            if (node.active) return true;
            if (node.type === 'module' && !!node.method && node.method.length > 0) {
                for (let it of node.method) {
                    if (this.loopTree(it, nodes)) {
                        nodes.push(it);
                        return true;
                    }
                }
            }
            return false;
        }
        // watch: {
        //     "$route.path": function(val) {
        //         this.assembleMenu(val);
        //     }
        // }
        
    };
    // export default {
    //     components: { MenuList },
    //     props: {
    //         menuCollapse: {
    //             type: Boolean,
    //             required: true,
    //             default: false
    //         }
    //     },
    //     data() {
    //         return {
    //             menuRenderData: []
    //         }
    //     },
    //     computed: {
    //         ...mapGetters({
    //             menuData: "getUserMenuData"
    //         })
    //     },
    
    //     methods: {
            // assembleMenu(_path) {
            //     let _list = [],
            //         _resource = this.menuData.authority || [];
            //     for (let _item of _resource) {
            //         let _l = [];
            //         if (!!_item.method && _item.method.length > 0) _l = this.loopData(_item.method, _path);
            //         if (_item.type === 'menu') _item.active = _item.data === _path;
            //         _item.method = _l;
            //         _list.push(_item);
            //     }

            //     this.menuRenderData = _list;
            //     // this.$root.eventBus.$emit('MENU_CHANGE_DATA', this.makeBreadcrumb(_list));
            //     this.$emit('changeMenu', this.makeBreadcrumb(_list));
            // },
    //         loopData(_data, _path) {
    //             let _dist = [];
    //             for (let _item of _data) {
    //                 let _l = [];
    //                 if (!!_item.method && _item.method.length > 0) _l = this.loopData(_item.method, _path);
    //                 if (_item.type === 'menu') _item.active = _item.data === _path;
    //                 _item.method = _l;
    //                 _dist.push(_item);
    //             }
    //             return _dist;
    //         },
    //         makeBreadcrumb(_list) {
    //             let nodes = [];
    //             for (let node of _list) {
    //                 if (this.loopTree(node, nodes)) {
    //                     nodes.push(node);
    //                     break;
    //                 }
    //             }
    //             return nodes.reverse();
    //         },
    //         loopTree(node, nodes) {
    //             if (node.active) return true;
    //             if (node.type === 'module' && !!node.method && node.method.length > 0) {
    //                 for (let it of node.method) {
    //                     if (this.loopTree(it, nodes)) {
    //                         nodes.push(it);
    //                         return true;
    //                     }
    //                 }
    //             }
    //             return false;
    //         }
    //     },
    //     created() {
    //         this.assembleMenu(this.$route.path);
    //     }
    // }
</script>