/*********************************************************************
* Meeting second router file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
    <router-view :breadList="breadList"></router-view>
</template>

<script>
    export default {
        data() {
            return {
                breadcrumbList: {
                    "_sale_saleFlowList": [{path: '', name: '售中'}, {path: '', name: '售中流程列表'}],                                      
                    "_sale_saleFlowAdd": [{path: '', name: '售中'}, {path: '', name: '售中流程新增'}],                                      
                    "_sale_saleFlowUpdate": [{path: '', name: '售中'}, {path: '', name: '售中流程修改'}],                                      
                    "_sale_saleFlow": [{path: '', name: '售中'}, {path: '', name: '售中流程'}],                                      
                    "_sale_saleFlowDetail": [{path: '', name: '售中'}, {path: '', name: '售中流程详情'}],                                      
                },
                breadList: []
            }
        },
        watch: {
            "$route.path": function(val) {
                this.assembleBreadcrumb(val);
            }
        },
        methods: {
            assembleBreadcrumb(path) {
                if (path !== '') path = path.replace(/\//g, '_');
                this.breadList = JSON.parse(JSON.stringify(this.breadcrumbList[path] || []));
            }
        },
        created() {

            sessionStorage.removeItem('page_list_params_cache');

            this.assembleBreadcrumb(this.$route.path);
        }
    }
</script>