/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <list-layout :breadcrumb-list="breadList">
    <!-- 查询form表单 -->
    <el-form slot="header" inline :model="queryData" size="small" label-position="left">
      <el-form-item label="项目名称:">
         <el-select v-model="queryData.pName"  @change="changePName(queryData.pName)" placeholder="请选择">
                <el-option                       
                v-for="(item,k) in pNames"
                :key="`key_${k}`"
                :label="item.projectName"
                :value="item.sn"
                ></el-option>
        </el-select>   
      </el-form-item>
      <el-form-item label="项目编号:">
        <el-select v-model="queryData.upperLimit"  placeholder="请选择">
                <el-option                       
                v-for="(item,k) in upperLimits"
                :key="`key_${k}`"
                :label="item.sn"
                :value="item.sn"
                ></el-option>
        </el-select>    
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small" @click="pageEvent">查询</el-button>
        <el-button @click="add()" size="small" type="primary">
            增加           
        </el-button>   
      </el-form-item>
      
    </el-form>
    <!-- 正文表格 -->    
    <el-table :data="tableData.data" width="100%" style="overflow-y: scroll;height: 100%;">
            <el-table-column  
                prop="onSaleStatus"          
                type="expand">     
                <template slot-scope="scope">                 
                    <div v-if="scope.row.capitalExpenditureType!=='成本类'" style="display: inherit;">
                        <div v-for="(item,i) in stateList" :key=i style="margin-left:40px;width:100px" >                                                    
                            <span v-if="scope.row.onSaleStatus===item"  :style="{color:'green',fontWeight:'800'}"><i class="el-icon-loading"></i>{{item}}</span>                                                                            
                            <span v-else :style="{color:'black'}">{{item}}</span>                                                  
                            <span v-if="item!=='工程验收'" :style="{color:'black'}">></span>                                                                            
                        </div>
                    </div> 
                    <div v-else style="display: inherit;">
                        <div v-for="(item,i) in stateListT" :key=i style="margin-left:40px;width:100px" >                                                    
                            <span v-if="scope.row.onSaleStatus===item"  :style="{color:'green',fontWeight:'800'}"><i class="el-icon-loading"></i>{{item}}</span>                                                                            
                            <span v-else :style="{color:'black'}">{{item}}</span>                                                  
                            <span v-if="item!=='工程验收'" :style="{color:'black'}">></span>                                                                            
                        </div>
                    </div> 
                </template> 
            </el-table-column>                
            <el-table-column
            label="项目名称"            
            prop="pName">           
            </el-table-column>
            <el-table-column
            label="项目编号"
            width="220"
            prop="projectSn">
            </el-table-column>
            <el-table-column
            label="资金支出类型"
            prop="capitalExpenditureType">
            </el-table-column>   
             <el-table-column
            label="年份"
            prop="projectYear">
            </el-table-column>   
             <el-table-column
            label="建设单位"
            prop="cUnit">
            </el-table-column>   
             <el-table-column
            label="归属县区"
            prop="region">
            </el-table-column>   
             <el-table-column
            label="行业属性"
            prop="industry">
            </el-table-column>   
             <el-table-column
            label="项目类型"
            prop="projectType">
            </el-table-column>   
             <el-table-column
            label="状态"
            prop="onSaleStatus">
            </el-table-column>   
             <el-table-column
            label="操作"
            fixed="right"
            prop="opt">
            <template slot-scope="scope">
                <el-button type="text" size="mini" icon="el-icon-tickets" @click="tableCellEvt(scope.row)"></el-button>
                <el-button type="text" v-if="scope.row.edite" size="mini" icon="el-icon-edit" @click="tableCellEdite(scope.row)"></el-button>  
            </template>
            </el-table-column>   
    </el-table>
    <!-- 导出/分页 -->
    <!-- <el-button slot="footer" type="primary" icon="el-icon-download" size="small">导出</el-button> -->
    <el-pagination @size-change="pagingEvent($event, 'size')" @current-change="pagingEvent($event, 'current')"
      :current-page="pagingData.current" :page-sizes="pagingData.sizes" :page-size="pagingData.size"
      :total="pagingData.total" slot="footer" layout="total, sizes, prev, pager, next, jumper"></el-pagination>
  </list-layout>
</template>

<script>
import ListLayout from "@/pages/layout/ListLayout";
import BaseView from "@/pages/BaseView";
import { getRequestMethod, postRequestMethod } from "@/api/common";

export default {
    extends: BaseView,
    components: { ListLayout },
    props: {
        breadList: {
        type: Array,
        default: () => []
        }
    },
    data () {
        return {
            pNames:[],
            upperLimits:[],
            publishTime: [],
            queryData: {
                pName: '',
                projectSn: '',                
            },
            stateList:[
                '项目启动',
                '设计批复',
                '项目采购',
                '工程实施',
                '工程验收'
            ],
            stateListT:[
                '项目启动',                
                '项目采购',
                '工程实施',
                '工程验收'
            ]
        }
    },
    methods: {
        changePName(data){            
            this.upperLimits=[];               
            let pName='';
            this.pNames.forEach(item=>{
                if(item.sn===data){
                    pName=item.projectName;
                }
            })                        
            this.pNames.forEach(item=>{
                if(item.projectName===pName){
                    this.upperLimits.push(item)
                }
            })                                
        },       
        add(){            
            this.$router.push({ path: '/sale/saleFlowAdd'});
        },
        pageEvent () {
            if (this.tableData.loading) return;
            this.pagingData.current = 1;
            this.getTableData();
        },
        async getTableData () {
            this.tableData.loading = true;
            this.queryData.del='del';
            let result = await getRequestMethod('PROJECT_ALL_PRIJECT', Object.assign(this.queryData, {
                pageSize: this.pagingData.size,
                pageNum: this.pagingData.current}
            ));

            if (!!result && result.code === 'SUCCESS') {
                this.tableData.data = result.data.dataList;
                this.pagingData.total = result.data.totalNum;
                this.tableData.loading = false;
                this.dealData();
            } else {
                this.$message.error(!!result ? result.message : '接口异常');
                this.tableData.show = false;
            }
        },
        dealData () {
            console.log(this.$store)
            this.tableData.data.map((item, k) => {
                item.edite=false;
                if(item.createUser===this.$store.getters.getLoginUserInfo.userInfo.loginName){                    
                    item.edite=true;
                }
                item.index = k + 1;
                // item.opt = ['详情'];
            })
        },
        tableCellEvt (row) {
            sessionStorage.setItem(this.cacheKey, JSON.stringify({ ...this.queryData, pageTotal: this.pagingData.total }));            
            this.$router.push({ path: '/sale/saleFlowDetail', query: { id: row.pid } })
        },
        tableCellEdite(row){                
            sessionStorage.setItem(this.cacheKey, JSON.stringify({ ...this.queryData, pageTotal: this.pagingData.total }));      
            this.$router.push({ path: '/sale/SaleFlow', query: { id: row.pid } })
        },
        async getPName(){           
            let result = await getRequestMethod('PROJECT_INFO_LIST',{});            
            if (!!result && result.code === 'SUCCESS') {
                this.pNames=result.data;
            } else {
                this.$message.error(!!result ? result.message : '接口异常');
                this.tableData.show = false;
            }
        }
    },
    mounted () {

        /* 如果 exportData 存在数据需要对页面参数进行回填，主要判断是否有分页参数 */
        if (!!this.exportData.pageSize) {
            this.queryData.subject = this.exportData.subject;
            this.queryData.gbB = this.exportData.gbB;
            this.queryData.gbE = this.exportData.gbE;
            this.publishTime.push(this.exportData.gbB);
            this.publishTime.push(this.exportData.gbE);
        }

        /* 初始化页面表格列属性数据 */
        this.tableData.column = [
            { label: '项目名称', key: 'pName', width: 200 },
            { label: '项目编号', key: 'projectSn', width: 220 },
            { label: '资金支出类型', key: 'capitalExpenditureType', width: 180 },
            { label: '年份', key: 'projectYear', width: 180 },
            { label: '建设单位', key: 'cUnit', minWidth: 200 },
            { label: '归属县区', key: 'region', minWidth: 200 },
            { label: '行业属性', key: 'industry', minWidth: 200 },
            { label: '项目类型', key: 'projectType', minWidth: 200 },
            { label: '状态', key: 'state', minWidth: 200 },
            { label: '操作', key: 'opt', width: 100 ,fixed:'right'}
        ];

        /* 查询表格数据 */
        this.getTableData();
        
        this.$root.eventBus.$emit('orderChange', this.breadList);
    },
    created(){
        this.getPName();
    }
}
</script>
<style lang="less" scoped>
    /deep/.el-table__expanded-cell{
        display: inline-flex;
    }
    /deep/.el-table el-table--fit.el-table--enable-row-transition{
        max-height: 3000px;
    }
</style>