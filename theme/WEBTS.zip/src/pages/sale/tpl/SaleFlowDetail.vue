/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <detail-layout v-loading="pageLoading" :breadcrumb-list="breadList">
    <div class="common-form-container full">
      <article>
        <el-form
          ref="submitForm"
          :model="pageData"
          :rules="rules"
          label-position="top"
          size="medium"
        >
            <el-row style="margin-top:20px;margin-bottom: 20px;">
                <span>项目信息</span>
            </el-row>
          <el-row :gutter="16">
            <el-col :span="8" v-for="(item,k) in projectList" :key=k>
              <el-form-item :label="item.laber">
                <el-input  :disabled="true" :value="item.value" placeholder="请填写项目命题"></el-input>
              </el-form-item>
            </el-col>                          
          </el-row>
           <el-row style="margin-top:20px;margin-bottom: 20px;">
                <span>项目启动信息</span>
            </el-row>
             <el-row :gutter="24">
                <el-tabs v-model="activeName" @tab-click="handleClick" :style="{padding:'10px'}">
                    <el-tab-pane label="项目启动" :disabled="begin"  name="first">
                        <el-row style="margin-top:20px;margin-bottom: 20px;">
                            <span>项目启动信息</span>
                        </el-row>
                        <el-row :gutter="16">
                            <el-col :span="8" v-for="(item,k) in beginList" :key=k>
                                <el-form-item :label="item.laber" >
                                    <el-input :value="item.value" :disabled="true" ></el-input>
                                </el-form-item>
                            </el-col>                                                                                                                     
                        </el-row>                       
                    </el-tab-pane>
                    <el-tab-pane label="设计批复" :disabled="review" name="second">
                        <el-row style="margin-top:20px;margin-bottom: 20px;">
                                <span>设计批复</span>
                            </el-row>
                        <el-row :gutter="16">
                            <el-col :span="8" v-for="(item,k) in reviewList" :key=k>
                                <el-form-item :label="item.laber" >
                                    <el-input :value="item.value" :disabled="true" ></el-input>
                                </el-form-item>
                            </el-col>                                                                                                                                                          
                        </el-row> 
                    </el-tab-pane>
                    <el-tab-pane label="项目采购" :disabled="purchase" name="third">
                        <el-row style="margin-top:20px;margin-bottom: 20px;">
                                <span>项目采购</span>
                            </el-row>
                        <el-row :gutter="16">
                            <el-col :span="8" v-for="(item,k) in purchaseList" :key=k>
                                <el-form-item :label="item.laber" >
                                    <el-input :value="item.value" :disabled="true" ></el-input>
                                </el-form-item>
                            </el-col>                                                     
                        </el-row>                       
                    </el-tab-pane>
                    <el-tab-pane label="工程实施" :disabled="implemetation" name="fourth">
                        <el-row style="margin-top:20px;margin-bottom: 20px;">
                                <span>项目采购</span>
                            </el-row>
                        <el-row :gutter="16">
                             <el-col :span="8" v-for="(item,k) in completeList" :key=k>
                                <el-form-item :label="item.laber" >
                                    <el-input :value="item.value" :disabled="true" ></el-input>
                                </el-form-item>
                            </el-col>                                                                                         
                        </el-row>                        
                    </el-tab-pane>
                    <el-tab-pane label="工程验收" :disabled="acceptance" name="fiveth">                        
                        <el-row style="margin-top:20px;margin-bottom: 20px;">
                            <span>工程验收</span>
                        </el-row>
                        <el-row :gutter="16">
                            <el-col :span="8" v-for="(item,k) in acceptanceList" :key=k>
                                <el-form-item :label="item.laber" >
                                    <el-input :value="item.value" :disabled="true" ></el-input>
                                </el-form-item>
                            </el-col>                                                    
                        </el-row>
                    </el-tab-pane>
                </el-tabs>
          </el-row>
        </el-form>
      </article>
      <footer>
        <!-- <el-button size="small" @click="submitEvent" type="primary">提&nbsp;&nbsp;交</el-button> -->
        <el-button @click="$router.go(-1)" size="small" plain>取消</el-button>
      </footer>
    </div>
  </detail-layout>
</template>

<script>
import DetailLayout from "@/pages/layout/DetailLayout";
import { getRequestMethod, postRequestMethod, postNewRequestMethod } from "@/api/common";
import Tool from "@/util/tool";
import { mapGetters } from "vuex";
import SaleFlow from "@/components/common/SaleFlow";

export default {
    components: { DetailLayout,SaleFlow },
    props: {
        breadList: {
        type: Array,
        default: () => []
        }
    },
    computed: {
        ...mapGetters({
        userInfo: 'common/getUserInfo'
        })
    },
    data () {      
        return {
            flowState:'',
            activeName: 'first',
            flowUrl:'',
            pageLoading: false,
            id:'',
            begin:true,
            review:true,
            purchase:true,
            implemetation:true,
            acceptance:true,
            pageData: {
                title: '',
                attachment: '',
                attachmentName: '',
                devReq: '',//开发需求
                endDate: '',
                limitDis: '',//时限要求
                submitDate: '',
                submit: '',
                submitName: '',
                submitPhone: '',
                upperLimit: '',//成本剔除上限
                startupDate:'',
                anticipateEndTime:'',
                projectDesc:"",
                startupRemarkFileName:'',
            },
            rules: {
                title: [{ required: true, message: '项目命题不能为空', trigger: 'blur' }],
                upperLimit: [{ required: true, message: '成本剔除上限不能为空', trigger: 'blur' }],                   
                devReq: [{ required: true, message: '开发要求不能为空', trigger: 'blur' }],
                attachmentName: [{ required: true, message: '附件不能为空', trigger: 'blur' }],
                limitDis: [{ required: true, message: '时限要求不能空', trigger: 'blur' }]
            },
            projectList:[
                {laber:'项目名称:',key:'pName',value:''}, 
                {laber:'项目编号:',key:'projectSn',value:''},                
                {laber:'资金支出类型:',key:'capitalExpenditureType',value:''},                
                {laber:'年份:',value:'',key:'projectYear'},                
                {laber:'建设单位:', value:'',key:'cUnit'},                
                {laber:'归属县区:', value:'',key:'region'},                
                {laber:'行业属性:', value:'',key:'industry'},                
                {laber:'项目类型:', value:'',key:'projectType'}
            ],
            beginList:[
                {laber:'项目启动时间:',key:"startupDate",value:''}, 
                {laber:'项目计划结束时间:',key:'anticipateEndTime',value:''},                
                {laber:'项目主要内容描述:',key:'projectDesc',value:''},                
                {laber:'项目启动资料:',value:'',key:"startupRemarkFile"}                
            ],
            reviewList:[
                {laber:'设计批复时间:',key:'reviewDate',value:''}, 
                {laber:'设计批复文号:',key:'reviewSn',value:''},                
                {laber:'设计批复金额（元）:',key:'amount',value:''},                
                {laber:'附件:',value:'',key:'reviewFile'}      
            ],
            purchaseList:[
                {laber:'采购订单号:',key:'orderNo',value:''}, 
                {laber:'采购人:',key:'chief',value:''}, 
                {laber:'成本IT采购金额(元):',key:'itCostAmount',value:''},                
                {laber:'成本CT采购金额（元）:',key:'ctCostAmount',value:''},                                            
                {laber:'资本IT采购金额（元）:', value:'',key:'itCapitalAmount'},                
                {laber:'资本CT采购金额（元）:', value:'',key:'ctCapitalAmount'},                                              
                {laber:'采购方式:', value:'',key:'purchaseType'},
                {laber:'采购清单:', value:'',key:'purchaseListFile'},
                {laber:'采购时间:', value:'',key:'purchaseTime'}                
            ],
            completeList:[
                {laber:'实施单位:',key:'construnctionUnit',value:''}, 
                {laber:'实施负责人:',key:'construnctionChief',value:''}, 
                {laber:'实施联系方式:',key:'construnctionContact',value:''},                
                {laber:'监理单位:',key:'supervisorUnit',value:''},                                            
                {laber:'监理负责人:', value:'',key:'supervisorChief'},                
                {laber:'监理联系方式:', value:'',key:'supervisorContact'},                                              
                {laber:'设计单位:', value:'',key:'designUnit'},
                {laber:'设计负责人:', value:'',key:'designChief'},
                {laber:'设计联系方式:', value:'',key:'designContact'},
                {laber:'预计到货时间:',key:'anticipateArrivalDate',value:''}, 
                {laber:'实际到货时间:',key:'actualArrivalDate',value:''}, 
                {laber:'是否到货:',key:'isArrivaled',value:''},                
                {laber:'是否完工:',key:'isCompleted',value:''},                                            
                {laber:'工程完工日期:', value:'',key:'completeDate'},                
                {laber:'到货清单/附件:', value:'',key:'arrivalFile'},                                              
                {laber:'工程实施附件:', value:'',key:'impleFile'},
                {laber:'完工凭证:', value:'',key:'completeFile'}                
            ],
            acceptanceList:[
                {laber:'竣工验收批复时间:',key:'replyDate',value:''}, 
                {laber:'竣工验收批复文号:',key:'replySn',value:''}, 
                {laber:'业主侧验收时间:',key:'customerCheckDate',value:''},                
                {laber:'验收报告:',key:'checkReport',value:''},  
            ]
        }
    },
    methods: {       
        async getTableInfo(){            
            this.pageLoading = true;
            let result = await getRequestMethod('QUERY_PROJECT_START_BY_ID', {pid: this.id});
            this.pageLoading = false;
            if (!!result && result.code === 'SUCCESS') {                                    
                let data = result.data;                    
                this.dealData(data);    
                this.flowState=result.data[0].onSaleStatus;  
                this.checkState(this.flowState);                          
            } else {
                this.$message.error(!!result? result.message:'接口异常');
            }
        },
        checkState(state){                                    
            switch (state) {              
                case '项目启动':                    
                    this.activeName='first';                                                                            
                    break;                    
                case '设计批复':
                    this.activeName='second';
                    break;
                case '项目采购':
                    this.activeName='third';
                    break;
                case '工程实施':
                    this.activeName='fourth';
                    break;
                case '工程验收':
                    this.activeName='fiveth';
                    break;
            };              
            if(this.activeName==='first'){
                this.begin=false;
                this.firstFlow();  
            }else if(this.activeName==='second'){
                this.review=false;
                this.secondFlow(); 
            }else if(this.activeName==='third'){
                this.purchase=false;
                this.thirdFlow(); 
            }else if(this.activeName==='fourth'){
                this.implemetation=false;
                this.fourthFlow(); 
            }else{
                this.acceptance=false;
                this.fivethFlow(); 
            }       
        },
        dealData(data){            
            this.projectList.map( oo => {
                oo.value = data[0][oo.key];
            });                                              
        },
        async firstFlow(){
            this.pageLoading = true;
            let result = await getRequestMethod('BEIGIN_FLOW', {pid: this.id});
            this.pageLoading = false;
            if (!!result && result.code === 'SUCCESS') {                    
               this.beginList.map((item, k) => {                                                                                
                    if(item.laber==='项目启动资料:'){                                    
                        if(result.data[0][item.key]!==null){                            
                            item.value =result.data[0][item.key].fileName;
                        }                            
                    }else{
                        
                        item.value =result.data[0][item.key]
                    }                    
                })                                             
            } else {
                this.$message.error(!!result? result.message:'接口异常');
            }
        },
        async secondFlow(){
            this.pageLoading = true;
            let result = await getRequestMethod('REVIEW_INFO', {pid: this.id});
            this.pageLoading = false;
            if (!!result && result.code === 'SUCCESS') {                                    
                this.reviewList.map((item, k) => {                                                                                
                    if(item.laber==='附件:'){                                    
                        if(result.data[0][item.key]!==null){
                            item.value =result.data[0][item.key].fileName;
                        }                            
                    }else{
                        item.value =result.data[0][item.key]
                    }                    
                })   
            } else {
                this.$message.error(!!result? result.message:'接口异常');
            }
        },
        async thirdFlow(){            
            this.pageLoading = true;
            let result = await getRequestMethod('PURCHASE_INFO', {pid: this.id});
            this.pageLoading = false;
            if (!!result && result.code === 'SUCCESS') {                                     
                this.purchaseList.map((item, k) => {                                                                                
                    if(item.laber==='采购清单:'){                                    
                        if(result.data[0][item.key]!==null){
                            item.value =result.data[0][item.key].fileName;
                        }                            
                    }else{
                        item.value =result.data[0][item.key]
                    }                    
                })   
            } else {
                this.$message.error(!!result? result.message:'接口异常');
            }
        },
        async fourthFlow(){            
            this.pageLoading = true;
            let result = await getRequestMethod('IMPLEMETATION_INFO', {pid: this.id});
            this.pageLoading = false;
            if (!!result && result.code === 'SUCCESS') {                                     
                this.completeList.map((item, k) => {                                                                                
                    if(item.laber==='到货清单/附件:'||item.laber==='工程实施附件:'||item.laber==='完工凭证:'){                        
                        if(result.data[0][item.key]!==null){                            
                            item.value =result.data[0][item.key].fileName;
                        }                            
                    }else{
                        if(result.data[0][item.key]===true){
                            item.value ="是";
                        }else if(result.data[0][item.key]===false){
                            item.value ="否";
                        }else{
                            item.value =result.data[0][item.key]
                        }
                        
                    }                    
                })   
            } else {
                this.$message.error(!!result? result.message:'接口异常');
            }
        },
        async fivethFlow(){            
            this.pageLoading = true;
            let result = await getRequestMethod('ACCEPTANCE_INFO', {pid: this.id});
            this.pageLoading = false;
            if (!!result && result.code === 'SUCCESS') {                                     
                this.acceptanceList.map((item, k) => {                                                                                                    
                    if(item.laber==='验收报告:'){                                        
                        if(result.data[0][item.key]!==null){                            
                            item.value =result.data[0][item.key].fileName;
                        }                            
                    }else{                       
                        item.value =result.data[0][item.key]                                               
                    }                    
                })   
            } else {
                this.$message.error(!!result? result.message:'接口异常');
            }
        },
        handleClick(){}
    },
    created () {        
        this.id = this.$route.query.id;
        this.getTableInfo();
    },
    mounted () {   
        this.$root.eventBus.$emit('orderChange', this.breadList);
    }
}
</script>

<style lang="less" scoped>
    .flow-height {
        height: 130px !important;
    }
</style>