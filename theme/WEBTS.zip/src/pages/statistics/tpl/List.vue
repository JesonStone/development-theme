<template>
    <list-layout>
        <!-- 查询form表单 -->
        <div slot="header">
            <el-form slot="header" inline :model="queryData" size="small" label-position="left">
                <el-form-item label="评估时间:">
                    <el-date-picker
                        v-model="queryData.assessTime"
                        type="month"
                        value-format="yyyy-MM"
                        style="width:150px;"
                        :picker-options="pickerOptions"
                        placeholder="选择日期">
                    </el-date-picker>
                </el-form-item>
                <el-form-item label="建设单位" prop="cUnit">                                                
                     <el-select v-model="queryData.cUnit" placeholder="请选择" style="width:120px;">
                        <el-option v-for="(item,k) in cUnits" :key="`key_${k}`" :label="item.label" :value="item.value"></el-option>
                    </el-select>   
                </el-form-item>
                <el-form-item label="项目已完成节点" prop="cUnit">                                                
                     <el-select v-model="queryData.node" placeholder="请选择" style="width:120px;">
                        <el-option v-for="(item,k) in nodes" :key="`key_${k}`" :label="item.value" :value="item.value"></el-option>
                    </el-select>   
                </el-form-item>
                <el-form-item label="年份" prop="year">                                                
                     <el-date-picker
                        v-model="queryData.year"
                        type="year"
                        value-format="yyyy"
                        style="width:120px;"
                        placeholder="选择日期">
                    </el-date-picker>  
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" size="small" @click="pageEvent('query')">查询</el-button>
                    <!-- <el-button type="success" size="small" @click="pageEvent('export')">统计</el-button> -->
                </el-form-item>
            </el-form>
            <el-button class='new-btn' type="primary" size="small" @click="pageEvent('add')"><i class="el-icon-plus"></i> 指标集</el-button>
        </div>
        <!-- 正文表格 -->
        <div style="font-size:16px;">评估时间：{{queryData.assessTime}}</div>
        <el-table border v-loading="tableData.loading" :data="tableData.data" height="95%">
            <template v-for="(item,i) in tableData.column" >
                <el-table-column 
                    :label="item.label" 
                    :prop="item.key"
                    :width="item.width" 
                    v-if="item.show"
                    :key="`table_key_${i}`" 
                    show-overflow-tooltip>
                </el-table-column>
            </template>
        </el-table>
        <!-- 导出/分页 -->
        <el-pagination 
                @size-change="pagingEvent($event, 'size')" 
                @current-change="pagingEvent($event, 'current')"
                :current-page="pagingData.current" 
                :page-sizes="pagingData.sizes" 
                :page-size="pagingData.size"
                :total="pagingData.total" 
                slot="footer" 
                layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
        <el-dialog 
            title="指标集配置" 
            :visible.sync="dialogTableVisible"
            :append-to-body = true
            >
             <el-checkbox-group v-model="checkList" @change="checkOne">
                <template v-for="(item,k) in this.tableData.column">
                    <el-checkbox v-if="item.canConfig" :key="`key_${k}`" :label="item.label"></el-checkbox>
                </template>
            </el-checkbox-group>
        </el-dialog>
    </list-layout>
</template>

<script>
    import ListLayout from "@/pages/layout/ListLayout";
    import BaseView from "@/pages/BaseView";
    import { getRequestMethod, postRequestMethod, deleteRequestMethod } from "@/api/common";
    import { mapGetters } from "vuex";
    import * as Tool from "@/util/tool";
    import ConstConfig from "@/config/const.config";

    export default {
        extends: BaseView,
        components: {
            ListLayout
        },
        props: {
            breadList: {
                type: Array,
                default: () => []
            }
        },
        computed: {
            ...mapGetters({
                userInfo: 'getUserInfo',
            }),
        },
        data() {
            return {
                dialogTableVisible:false,
                checkList:[],
                cUnits:[],
                nodes:[],
                pickerOptions:{
                    disabledDate(time) {
                        return time.getTime() > Date.now();
                    }
                },
                queryData: {
                    assessTime: '',
                    cUnit: '',
                    node: '',
                    year:''
                },
            }
        },
        methods: {
            pageEvent(type) {
                if (type === 'query') {
                    if (this.tableData.loading) return;
                    this.pagingData.current = 1;
                    this.getTableData();
                } else if (type === 'add') {
                    this.dialogTableVisible = true;
                } else if (type === 'export') {
                    this.exportExcel();
                }
            },
            async queryAllBrrach(){
                let result = await getRequestMethod('COMPANY_TREE');
                if(!!result && result.code==='SUCCESS'){                    
                    let newList=[];                
                    result.data[0]['children'].forEach((item, index) => {
                        newList.push({
                            value:item.orgCode,
                            label:item.orgName,                            
                        })                                                  
                    });                                                                                      
                    this.cUnits=newList;                     
                }        
            },
            async getIcomeTypes(){
                let result = await getRequestMethod('MENU_LIST',{key:'项目已完成节点'});
                if(!!result && result.code==='SUCCESS'){                        
                    this.nodes=result.data;
                } else {
                    this.$message.error(!!result.message ? result.message:'接口异常');
                }
            },
            async exportExcel () {
                Tool.exportExcel('', this.queryData, '项目效益评估统计');
            },

            async getTableData() {
                this.tableData.loading = true;
                let result = await getRequestMethod('PROJECT_STATISTICS', Object.assign(this.queryData, {
                    pageSize: this.pagingData.size,
                    pageNum: this.pagingData.current ? this.pagingData.current : 0
                }));
                this.tableData.loading = false;

                if (!!result && result.code === 'SUCCESS') {                    
                    this.tableData.data = result.data;
                    this.pagingData.total = result.data.totalNum;
                    this.tableData.loading = false;
                } else {
                    this.$message.error(!!result ? result.message:'接口异常');
                }
            },
            checkOne(value){
                this.tableData.column.forEach( oo => {
                    if (oo.canConfig) oo.show = value.includes(oo.label);
                });
            },
            dealbuttonPormision(){
                this.canNew = this.actions.includes(ConstConfig.buttonConfig.annual_plan_add);
                this.canExport = this.actions.includes(ConstConfig.buttonConfig.annual_plan_export);
            },
        },
        created() {

            /* 如果 exportData 存在数据需要对页面参数进行回填，主要判断是否有分页参数 */
            if (!!this.exportData.pageSize) {
                this.queryData.patentType = this.exportData.patentType;
                this.queryData.registCertificateDateSt = this.exportData.registCertificateDateSt;
            } else {
                this.queryData.assessTime = Tool.dateFormat('YYYY-MM',new Date());
            }

            /* 初始化页面表格列属性数据 */
            this.tableData.column = [
                {label: '项目编号',key: 'projectSn',canConfig:false, show:true},
                {label: '项目名称',key: 'projectName',canConfig:false, show:true},
                {label: '建设单位', key: 'constructionUnit',canConfig:false, show:true},
                {label: '项目已完成节点', key: 'projectState',canConfig:false, show:true},
                {label: '年份', key: 'year',canConfig:false, show:true, width: 120},
                {label: '战略型or效益型', key: 'benefitType',canConfig:false, show:true, width: 130},
                {label: '售前-资本IT（万元）',key: 'itCapital',canConfig:true, show:false, width: 120},
                {label: '售前-资本CT（万元）', key: 'ctCapital',canConfig:true, show:false, width: 120},
                {label: '立项编号', key: 'approvalSn',canConfig:true, show:false, width: 120},
                {label: '售前-成本IT（万元）', key: 'itCost',canConfig:true, show:false, width: 120},
                {label: '售前-成本CT（万元）', key: 'ctCost',canConfig:true, show:false, width: 120},
                {label: '预算编号', key: 'budgetSn',canConfig:true, show:false, width: 120},
                {label: '售前-总投入IT（万元）', key: 'itTotalOut',canConfig:true, show:false, width: 120},
                {label: '售前-总投入CT（万元）', key: 'ctTotalOut',canConfig:true, show:false, width: 120},
                {label: '售前-总收入IT（万元）', key: 'itIncome',canConfig:true, show:false, width: 120},
                {label: '售前-总收入CT（万元）', key: 'ctIncome',canConfig:true, show:false, width: 120},
                {label: '收入合同编码', key: 'incomeContractSn',canConfig:true, show:false, width: 120},
                {label: '售前-总利润IT（万元）', key: 'itProfit',canConfig:true, show:false, width: 120},
                {label: '售前-总利润CT（万元）', key: 'ctProfit',canConfig:true, show:false, width: 120},
                {label: '售前-年平均净利润率（%）', key: 'profitMargin',canConfig:true, show:false, width: 120},
                {label: '售前-累计现金净现值（万元）', key: 'npv',canConfig:true, show:false, width: 120},
                {label: '售前-回收期(年）', key: 'pbp',canConfig:true, show:false, width: 120},
                {label: '实际执行-资本IT（万元）', key: 'actualCtCost',canConfig:true, show:false, width: 120},
                {label: '实际执行-资本CT（万元）', key: 'actualCtCapital',canConfig:true, show:false, width: 120},
                {label: '实际执行-成本IT（万元）', key: 'actualItCost',canConfig:true, show:false, width: 120},
                {label: '实际执行-成本CT（万元）', key: 'actualItCapital',canConfig:true, show:false, width: 120},
                {label: '实际执行-总投入IT（万元）', key: 'actualTotalIt',canConfig:true, show:false, width: 120},
                {label: '实际执行-总投入CT（万元）', key: 'actualTotalCt',canConfig:true, show:false, width: 120},
                {label: '实际执行-总收入IT（万元） ', key: 'actualItIncome',canConfig:true, show:false, width: 120},
                {label: '实际执行-总收入CT（万元）', key: 'actualCtIncome',canConfig:true, show:false, width: 120},
                {label: '实际执行-总利润IT（万元）', key: 'actualITTotalProfilt',canConfig:true, show:false, width: 120},
                {label: '实际执行-总利润CT（万元）', key: 'actualCTTotalProfit',canConfig:true, show:false, width: 120},
                {label: '项目开始时间', key: 'startupDate',canConfig:true, show:false, width: 120},
                {label: '项目结束时间', key: 'endTime',canConfig:true, show:false, width: 120},
            ];

            /* 查询表格数据 */
            this.getTableData();
            this.queryAllBrrach()

        },
        mounted(){
            // this.dealbuttonPormision();
            this.$root.eventBus.$emit('orderChange', this.breadList);
        }
    }
</script>
<style lang="less" scoped>
    /deep/.el-form-item {
        margin-bottom: 18px;
    }
    .new-btn{
        margin: 15px 0 0 12px;
    }
    .el-checkbox {
        margin:0 50px 0 0;
        width: 230px;
    }
</style>