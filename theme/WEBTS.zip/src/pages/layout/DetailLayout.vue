<!--
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-19 11:17:57
-->
/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/30
*********************************************************************/

<template>
    <div class="common-list-layout">
        <div class="content no-query">
            <article class="detail" :class="{'no-footer': !hasFooter}">
                <section>
                    <slot></slot>
                </section>
                <footer v-if="hasFooter">
                    <slot name="footer"></slot>
                </footer>
            </article>
        </div>
    </div>
</template>

<script>

    export default {
        props: {
            breadcrumbList: {
                type: Array,
                default: () => []
            },
            hasGoBack: {
                type: Boolean,
                default: () => false
            }
        },
        computed: {
            hasFooter() {
                return !!this.$slots.footer;
            }
        },
        // creacted(){
        //     this.$root.eventBus.$emit('orderChange',this.breadcrumbList);
        // }
    }
</script>