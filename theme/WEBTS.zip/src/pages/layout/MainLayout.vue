<!--
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-19 11:17:57
 -->
/*********************************************************************
* Vue private main layout file
* Created by deming-su on 2017/12/30
*********************************************************************/

<template>
    <div class="application-container">
        <div :class="['layout-main-container', {collapse: menuCollapse}]">
            <div class="nav">
                <navigator-node :menu-collapse.sync="menuCollapse"></navigator-node>
            </div>
            <div class="menu">
                <menu-node :menu-collapse="menuCollapse"></menu-node>
            </div>
            <div class="view">
                <router-view></router-view>
            </div>
        </div>
    </div>
</template>

<script>
    import MenuNode from "@/components/common/MenuNode.vue";
    import NavigatorNode from "@/components/common/NavigatorNode"
    export default {
        components: {
            MenuNode,
            NavigatorNode
        },
        data() {
            return {
                collapse: false,
                menuCollapse: false
            }
        },
        methods: {
            menuEvent(type, data) {
                switch (type) {
                    case 'message':
                        console.log('message event ... ...');
                        break;
                    case 'collapse':
                        this.collapse = data;
                        break;
                }
            }
        },
        mounted() {
            this.$nextTick(() => {

                this.$root.eventBus.$emit('NoticeBroadcast', {type: 'notice', data: {}});
            });
        }
    };
</script>
