<!--
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-19 11:17:57
 -->
/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/30
*********************************************************************/

<template>
    <div class="common-list-layout">
        <div class="content" :class="{'no-query': !hasHeader}">
            <header>
                <slot name="header"></slot>
            </header>
            <article :class="{'no-footer': !hasFooter}">
                <slot></slot>
                <footer>
                    <slot name="footer"></slot>
                </footer>
            </article>
        </div>
    </div>
</template>

<script>

    export default {
        props: {
            breadcrumbList: {
                type: Array,
                default: () => []
            },
            hasCreacteBtn: {
                type: Boolean,
                default: false
            }
        },
        computed: {
            hasHeader() {
                return !!this.$slots.header;
            },
            hasFooter() {
                return !!this.$slots.footer;
            }
        },
        // creacted(){
        //     debugger;
        //     this.$root.eventBus.$emit('orderChange',this.breadcrumbList);
        // }
    }
</script>