<!--
 * @Descripttion: 任务管理
 * @Author: zhixiang-bai
 * @Date: 2020-01-07 11:43:18
 -->

<template>
    <detail-layout v-loading="pageLoading">
        <div class="commone-detail-layout">
            <div class="main">
                <div class="box-detail">
                    <div class="title">项目信息</div>
                    <div class="box-content">
                        <div v-for="(item,k) in baseObj" :key="`key_${k}`" :class="item.clx">
                            <div v-if="item.value!==''" class="label">{{item.label}}</div>
                            <div v-if="item.value!==''" class="text2">{{item.value}}</div>
                        </div>
                    </div>
                </div>
                <div class="box-detail">
                    <div class="title">项目金额</div>
                    <div class="box-content">
                        <div v-for="(item,k) in moneyObj" :key="`key_${k}`" :class="item.clx">
                            <div class="label">{{item.label}}</div>
                            <div class="text2">{{item.value}}</div>
                        </div>
                    </div>
                </div>                            
            </div>
            <div class="footer">
                <el-button  @click="$router.go(-1)" size="small">返回</el-button>
            </div>
        </div>
    </detail-layout>
</template>

<script>
    import DetailLayout from "@/pages/layout/DetailLayout";
    import {getFullUrl, getRequestMethod} from "@/api/common";
    import Tool from "@/util/tool";
    import {mapGetters} from 'vuex';

    export default {
        components: { DetailLayout },
        props: {
            breadList: {
                type: Array,
                default: () => []
            }
        },
        computed:{
            ...mapGetters({
                userInfo:'getUserInfo'
            })
        },
        data() {
            return {
                pageLoading: false,
                sn: '',
                baseObj: [
                    {label:'项目名称:',clx:'item w2', key:'pName', value:''},
                    {label:'项目编号:',clx:'item w2', key:'projectSn', value:''},                    
                    {label:'年份:',clx:'item w2', key:'projectYear', value:''},
                    {label:'建设单位:',clx:'item w2', key:'cUnit', value:''},
                    {label:'归属县区:',clx:'item w2', key:'region', value:''},
                    {label:'行业属性:',clx:'item w2', key:'industry', value:''},
                    {label:'决策类型:',clx:'item w2', key:'policyDecision', value:''},
                    {label:'资金支出类型:',clx:'item w2', key:'capitalExpenditureType', value:''},
                    {label:'项目类型:',clx:'item w2', key:'projectType', value:''},
                    {label:'立项编码:',clx:'item w2', key:'approvalSn', value:''},
                    {label:'预算编码:',clx:'item w2', key:'budgetSn', value:''},
                    {label:'省公司行业支撑经理:',clx:'item w2', key:'pcManager', value:''},
                    {label:'分公司行业支撑经理:',clx:'item w2', key:'ccManager', value:''},
                ],
                moneyObj:[
                    {label:'资本类总金额(元)IT:',clx:'item w2', key:'itCapital', value:''},
                    {label:'资本类总金额(元)CT:',clx:'item w2', key:'ctCapital', value:''},
                    {label:'成本类总金额(元)IT:',clx:'item w2', key:'itCost', value:''},
                    {label:'成本类总金额(元)CT:',clx:'item w2', key:'ctCost', value:''},
                    {label:'总收入金额(元)IT"',clx:'item w2', key:'itAmount', value:''},
                    {label:'总收入金额(元)CT:',clx:'item w2', key:'ctAmount', value:''},
                    {label:'年平均净利润率(%):',clx:'item w2', key:'profitMargin', value:''},
                    {label:'累计现金净现值(元):',clx:'item w2', key:'npv', value:''},
                    {label:'回收期(年):',clx:'item w2', key:'pbp', value:''},
                    {label:'采购方式:',clx:'item w2', key:'purchaseType', value:''},
                    {label:'支撑方式:',clx:'item w2', key:'supportType', value:''},
                    {label:'会议纪要号:',clx:'item w2', key:'minutesSn', value:''},
                    {label:'备注说明:',clx:'item w2', key:'remark', value:''},
                    {label:'会议纪要附件:',clx:'item w2', key:'adjunk', value:''},
                    {label:'其它附件:',clx:'item w2', key:'otherAdJunk', value:''},
                ]
            }
        },
        methods: {
            async getDetailInfo() {
                this.pageLoading = true;
                let result = await getRequestMethod('QUERY_PROJECT_ALL_INFO_BY_PID', {id: this.id});
                this.pageLoading = false;

                if (!!result && result.code === 'SUCCESS') {                    
                    let data = result.data;                    
                    this.dealData(data);                    
                } else {
                    this.$message.error(!!result? result.message:'接口异常');
                }
            },
            dealData(data){
                this.baseObj.map( oo => {
                    oo.value = data[oo.key];
                });
                this.moneyObj.map( oo => {                    
                    if(oo.label==='其它附件:'){
                        oo.value = data.otherAdJunk.fileName;
                    }else if(oo.label==='会议纪要附件:'){
                        oo.value = data.adJunk.fileName;
                    }else{
                        oo.value = data[oo.key];
                    }                    
                });                              
            },
            downloadEvent (fileName, filePath) {
                let downloadBase = getFullUrl('DOWNLOAD_URL');
                let url = downloadBase + '?filePath=' + filePath;
                Tool.downloadFiles(url, fileName);
            },
        },
        created() {
            this.id = this.$route.query.id;
            if (!this.id) {
                this.$message.error('非法进入页面，请重新进入');
            } else {
                this.getDetailInfo();
            }
        },
        mounted(){
            this.$root.eventBus.$emit('orderChange', this.breadList);
        }
    }
</script>

<style lang="less" scoped>
</style>