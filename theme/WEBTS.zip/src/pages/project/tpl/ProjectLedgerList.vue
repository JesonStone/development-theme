/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <list-layout :breadcrumb-list="breadList">
    <!-- 查询form表单 -->
    <el-form slot="header" inline :model="queryData" size="small" label-position="left">
      <el-form-item label="合同名称:">
        <el-input v-model="queryData.subject" size="small" placeholder="请输入"></el-input>
      </el-form-item>
      <el-form-item label="收入类型:">
        <el-input v-model="queryData.subject" size="small" placeholder="请输入"></el-input>
      </el-form-item>
      <el-form-item class="right">
        <el-button type="primary" size="small" @click="pageEvent">查询</el-button>
      </el-form-item>
    </el-form>
    <!-- 正文表格 -->
    <el-table v-loading="tableData.loading" :data="tableData.data" height="100%">
      <el-table-column v-for="(item,i) in tableData.column" :label="item.label" :prop="item.key"
        :min-width="item.minWidth" :width="item.width" :key="`table_key_${i}`" align="center" show-overflow-tooltip>
        <template slot-scope="scope">
          <div v-if="item.key === 'opt'">
            <el-button type="text" size="mini" icon="el-icon-tickets" @click="tableCellEvt(scope.row)"></el-button>
          </div>
          <span v-else class="common-table-cell">{{scope.row[item.key]}}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 导出/分页 -->
    <!-- <el-button slot="footer" type="primary" icon="el-icon-download" size="small">导出</el-button> -->
    <el-pagination @size-change="pagingEvent($event, 'size')" @current-change="pagingEvent($event, 'current')"
      :current-page="pagingData.current" :page-sizes="pagingData.sizes" :page-size="pagingData.size"
      :total="pagingData.total" slot="footer" layout="total, sizes, prev, pager, next, jumper"></el-pagination>
  </list-layout>
</template>

<script>
import ListLayout from "@/pages/layout/ListLayout";
import BaseView from "@/pages/BaseView";
import { getRequestMethod, postRequestMethod } from "@/api/common";

export default {
  extends: BaseView,
  components: { ListLayout },
  props: {
    breadList: {
      type: Array,
      default: () => []
    }
  },
  data () {
    return {
      publishTime: [],
      queryData: {
        subject: '',
        gbB: '',
        gbE: ''
      }
    }
  },
  watch: {
    publishTime: function (val) {
        if (!val) {
            this.queryData.gbB = '';
            this.queryData.gbE = '';
        } else {
            this.queryData.gbB = val[0] || '';
            this.queryData.gbE = val[1] || '';
        }
    }
  },
  methods: {
    pageEvent () {
      if (this.tableData.loading) return;
      this.pagingData.current = 1;
      this.getTableData();
    },
    async getTableData () {
    //   this.tableData.loading = true;
    //   let result = await postRequestMethod('BILLBOARD_LISTPUBLISH', Object.assign(this.queryData, {
    //     pageSize: this.pagingData.size,
    //     pageNum: this.pagingData.current - 1      }
    //   ));

    //   if (!!result && result.code === 'success') {
    //     this.tableData.data = result.data.content;
    //     this.pagingData.total = result.data.totalElements;
    //     this.tableData.loading = false;
    //     this.dealData();
    //   } else {
    //     this.$message.error(!!result ? result.message : '接口异常');
    //     this.tableData.show = false;
    //   }
    },
    dealData () {
      this.tableData.data.map((item, k) => {
        item.index = k + 1;
        item.opt = ['详情'];
      })
    },
    tableCellEvt (row) {
      sessionStorage.setItem(this.cacheKey, JSON.stringify({ ...this.queryData, pageTotal: this.pagingData.total }));
      this.$router.push({ path: '/notice/publish/detail', query: { id: row.id } })
    }
  },
  mounted () {

    /* 如果 exportData 存在数据需要对页面参数进行回填，主要判断是否有分页参数 */
    if (!!this.exportData.pageSize) {
      this.queryData.subject = this.exportData.subject;
      this.queryData.gbB = this.exportData.gbB;
      this.queryData.gbE = this.exportData.gbE;
      this.publishTime.push(this.exportData.gbB);
      this.publishTime.push(this.exportData.gbE);
    }

    /* 初始化页面表格列属性数据 */
    this.tableData.column = [
      { label: '合同名称', key: 'index', width: 200 },
      { label: '收入类型', key: 'title', width: 220 },
      { label: 'IT收入金额（元）', key: 'selectUnitName', width: 180 },
      { label: 'CT收入金额（元）', key: 'pubDate', width: 180 },
      { label: '到账时间', key: 'unionDis', minWidth: 200 },
      { label: '到账凭证', key: 'unionDis', minWidth: 200 },
      { label: '备注', key: 'unionDis', minWidth: 200 },      
      { label: '操作', key: 'opt', width: 100 }
    ];

    /* 查询表格数据 */
    this.getTableData();
    
    this.$root.eventBus.$emit('orderChange', this.breadList);

  }
}
</script>