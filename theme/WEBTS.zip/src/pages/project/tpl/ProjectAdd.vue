/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <detail-layout v-loading="pageLoading" :breadcrumb-list="breadList">
    <div class="common-form-container full">
      <article>
        <el-form
          ref="submitForm"
          :model="pageData"
          :rules="rules"
          label-position="top"
          size="medium">
            <el-row style="margin-top:20px;margin-bottom: 20px;">
                <span>项目基础信息</span>
            </el-row>
          <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label="项目名称" prop="pName">
                <el-input v-model="pageData.pName" placeholder="请填写项目名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目编号">
                <el-input v-model="pageData.upperLimit" :disabled="true" ></el-input>
              </el-form-item>
            </el-col>
             <el-col :span="8">
              <el-form-item label="年份" prop="year">                  
                 <el-input v-model="pageData.year" :disabled="true" ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="建设单位" prop="cUnit">                                                
                     <el-select v-model="pageData.cUnit"  @change="changeCUnit(pageData.cUnit)"  placeholder="请选择">
                        <el-option                       
                        v-for="(item,k) in cUnits"
                        :key="`key_${k}`"
                        :label="item.label"
                        :value="item.value"
                        ></el-option>
                    </el-select>   
              </el-form-item>
            </el-col>                      
            <el-col :span="8">
              <el-form-item label="归属县区" prop="region" v-if='regionShow'>
                <!-- <el-input v-model="pageData.region" ></el-input> -->
                 <el-select v-model="pageData.region" placeholder="请选择">
                        <el-option                        
                        v-for="(item,k) in regions"
                        :key="`key_${k}`"
                        :label="item.orgName"
                        :value="item.orgCode"
                        ></el-option>
                    </el-select>  
              </el-form-item>
            </el-col>            
            <el-col :span="8">
              <el-form-item label="行业属性" prop="industry">
                    <el-select v-model="pageData.industry" placeholder="请选择">
                        <el-option
                        v-for="(item,k) in industrys"
                        :key="`key_${k}`"
                        :label="item.value"
                        :value="item.value"
                        ></el-option>
                    </el-select>                
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="决策类型" prop="policyDecision">                    
                 <el-select v-model="pageData.policyDecision" placeholder="请选择" @change="changePolicyDecision(pageData.policyDecision)">
                        <el-option
                        v-for="(item,k) in policyDecisions"
                        :key="`key_${k}`"
                        :label="item.value"
                        :value="item.value"
                        ></el-option>
                    </el-select> 
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="资金支出类型" prop="capitalExpenditureType">                
                <el-select v-model="pageData.capitalExpenditureType" placeholder="请选择">
                        <el-option
                        v-for="(item,k) in capitalExpenditureTypes"
                        :key="`key_${k}`"
                        :label="item.value"
                        :value="item.value"
                        ></el-option>
                    </el-select> 
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目类型" prop="projectType">                              
                <el-select v-model="pageData.projectType" placeholder="请选择">
                    <el-option
                    v-for="(item,k) in projectTypes"
                    :key="`key_${k}`"
                    :label="item.value"
                    :value="item.value"
                    ></el-option>
                </el-select>                              
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="立项编码" prop="approvalSn">
                <el-input v-model="pageData.approvalSn" placeholder="请填写立项编码"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="预算编码" prop="budgetSn">
                <el-input v-model="pageData.budgetSn" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="省公司行业支撑经理" prop="pc" v-if="pcOrcc">
                <!-- <el-input v-model="pageData.pc" placeholder="请填写时限要求"></el-input> -->
                 <el-select v-model="pageData.pcManager" placeholder="请选择">
                        <el-option                        
                        v-for="(item,k) in pcs"
                        :key="`key_${k}`"
                        :label="item.name"
                        :value="item.name"
                        ></el-option>
                    </el-select> 
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="分公司行业支撑经理" prop="cc" v-if="!pcOrcc">
                <!-- <el-input v-model="pageData.cc" placeholder="请填写时限要求"></el-input> -->
                 <el-select v-model="pageData.ccManager" placeholder="请选择">
                        <el-option                        
                        v-for="(item,k) in ccs"
                        :key="`key_${k}`"
                        :label="item.name"
                        :value="item.name"
                        ></el-option>
                    </el-select> 
              </el-form-item>
            </el-col>                      
          </el-row>
           <el-row style="margin-top:20px;margin-bottom: 20px;">
                <span>项目金额信息</span>
            </el-row>
             <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label="总投资金额（元）IT" prop="CostItCount">
                <el-input v-model="pageData.CostItCount" :disabled="true" placeholder="请填写项目命题"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="总投资金额（元）CT" prop="CostCtCount">
                <el-input v-model="pageData.CostCtCount" :disabled="true" placeholder="请填写成本剔除上线"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="资本类总金额（元）IT" prop="itCapital">
                <el-input v-model="pageData.itCapital" @input.native="pageData.itCapital=checkInput(pageData.itCapital)" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="资本类总金额（元）CT" prop="ctCapital">
                <el-input v-model="pageData.ctCapital" @input.native="pageData.ctCapital=checkInput(pageData.ctCapital)" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>            
            <el-col :span="8">
              <el-form-item label="成本类总金额（元）IT" prop="itCost">
                <el-input v-model="pageData.itCost" @input.native="pageData.itCost=checkInput(pageData.itCost)" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="成本类总金额（元）CT" prop="ctCost">
                <el-input v-model="pageData.ctCost" @input.native="pageData.ctCost=checkInput(pageData.ctCost)" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="总收入金额（元）IT" prop="itAmount">
                <el-input v-model="pageData.itAmount" @input.native="pageData.itAmount=checkInput(pageData.itAmount)" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="总收入金额（元）CT" prop="ctAmount">
                <el-input v-model="pageData.ctAmount" @input.native="pageData.ctAmount=checkInput(pageData.ctAmount)" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
             <el-col :span="8">
              <el-form-item label="总收入金额（元）" prop="allAmount">
                <el-input v-model="pageData.allAmount" :disabled="true" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="年平均净利润率（%）" prop="profitMargin">
                <el-input v-model="pageData.profitMargin"  @input.native="pageData.profitMargin=checkInput(pageData.profitMargin)" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="累计现金净现值（元）" prop="npv">
                <el-input v-model="pageData.npv"  @input.native="pageData.npv=checkInput(pageData.npv)"  placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="回收期(年）" prop="pbp">
                <el-input v-model="pageData.pbp" @input.native="pageData.pbp=checkInput(pageData.pbp)" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="采购方式">               
                <el-select v-model="pageData.purchaseType" placeholder="请选择">
                    <el-option
                    v-for="(item,k) in purchaseTypes"
                    :key="`key_${k}`"
                    :label="item.value"
                    :value="item.value"
                    ></el-option>
                </el-select> 
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="支撑方式">                
                <el-select v-model="pageData.supportType" placeholder="请选择">
                    <el-option
                    v-for="(item,k) in supportTypes"
                    :key="`key_${k}`"
                    :label="item.value"
                    :value="item.value"
                    ></el-option>
                </el-select> 
              </el-form-item>
            </el-col> 
            <el-col :span="8">
              <el-form-item label="会议纪要号">
                <el-input v-model="pageData.minutesSn" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col> 
            <el-col :span="8">
              <el-form-item label="备注说明" prop="remark">
                  <el-input v-model="pageData.remark" placeholder="请填写时限要求"></el-input>                
              </el-form-item>
            </el-col>   
            <el-col :span="8">
                <el-form-item label="附件">   
                    <el-input v-model="pageData.adjunkFileName" size="small">
                        <el-button style="color:#409EFF;" slot="append" @click="pickFileEvent()" icon="el-icon-upload" size="small"></el-button>
                    </el-input>
                </el-form-item>
            </el-col> 
            <el-col :span="8">
              <el-form-item label="其它附件">                  
                  <el-input v-model="pageData.otherAdJunkFileNAme" size="small">
                    <el-button style="color:#409EFF;" slot="append" @click="otherPickFileEvent()" icon="el-icon-upload" size="small"></el-button>
                </el-input>
              </el-form-item>
            </el-col> 
                                          
          </el-row>
        </el-form>
      </article>
      <footer>
        <el-button size="small" @click="submitEvent" type="primary">提&nbsp;&nbsp;交</el-button>
        <el-button @click="$router.go(-1)" size="small" plain>取消</el-button>
      </footer>
    </div>
  </detail-layout>
</template>

<script>
import DetailLayout from "@/pages/layout/DetailLayout";
import { getRequestMethod, postRequestMethod, postNewRequestMethod } from "@/api/common";
import Tool from "@/util/tool";
import { mapGetters } from "vuex";
import BaseView from "@/pages/BaseView";

export default {
    extends: BaseView,
    components: { DetailLayout },
    props: {
        breadList: {
        type: Array,
        default: () => []
        }
    },
    computed: {
        ...mapGetters({
            userInfo: 'getUserInfo'
        }),        
    },
    watch:{
        "pageData.itCost": function (value) {            
            this.pageData.CostItCount=this.pageData.itCapital*1+this.pageData.itCost*1
        },
        "pageData.itCapital": function (value) {            
            this.pageData.CostItCount=this.pageData.itCapital*1+this.pageData.itCost*1
        },
        "pageData.ctCost":function(value){
            this.pageData.CostCtCount=this.pageData.ctCapital*1+this.pageData.ctCost*1
        },
        "pageData.ctCapital":function(value){
            this.pageData.CostCtCount=this.pageData.ctCapital*1+this.pageData.ctCost*1
        },
        "pageData.itAmount":function(value){
            this.pageData.allAmount=this.pageData.itAmount*1+this.pageData.ctAmount*1
        },
        "pageData.ctAmount":function(value){
            this.pageData.allAmount=this.pageData.itAmount*1+this.pageData.ctAmount*1
        }
    },
    data () {                       
        return {
            list:[],
            pcOrcc:true,
            regionShow:false,
            pageLoading: false,
            industrys:[],
            projectTypes:[],
            supportTypes:[],
            purchaseTypes:[],
            policyDecisions:[],
            capitalExpenditureTypes:[],
            cUnits:[],
            regions:[],
            pcs:[],
            ccs:[],
            pageData: {
                allAmount:'',
                CostItCount:'',
                CostCount:'',
                year:'',
                appDep: '',
                appMan: '',
                approvalSn: '',
                benefitType: '',
                budgetSn: '',
                cUnit: [""],
                capitalExpenditureType: '',
                pcManager:'',
                ccManager: '',
                ctAmount: '',
                ctCapital: '',
                ctCost: '',
                itCost: '',
                industry:'',
                itAmount:'',
                itCapital:'',            
                minutesSn:'',
                npv:'',
                pName:'',
                pbp:'',                
                policyDecision:'',
                profitMargin:'',
                projectType:'',
                purchaseType:'',
                region:'',
                remark:'',
                supportType:'',    
                otherAdJunk:{},
                adJunk:{},
                adjunkFileName:'',
                otherAdJunkFileNAme:''                                
            },
            rules: {
                pName: [{ required: true, message: '项目名称不能为空', trigger: 'blur' }],      
                year : [{ required: true, message: '年份不能为空', trigger: 'blur' }],         
                cUnit : [{ required: true, message: '建设单位不能为空', trigger: 'blur' }],  
                region : [{ required: true, message: '归属区县不能为空', trigger: 'blur' }],    
                industry: [{ required: true, message: '行业属性不能为空', trigger: 'blur' }],  
                policyDecision: [{ required: true, message: '决策类型不能为空', trigger: 'blur' }],    
                capitalExpenditureType: [{ required: true, message: '资金类型不能为空', trigger: 'blur' }],   
                projectType : [{ required: true, message: '项目类型不能为空', trigger: 'blur' }],   
                approvalSn: [{ required: true, message: '立项编码不能为空', trigger: 'blur'}],   
                budgetSn: [{ required: true, message: '预算编码不能为空', trigger: 'blur' }],   
                pc: [{ required: true, message: '省公司行业支撑经理不能为空', trigger: 'blur' }],   
                cc: [{ required: true, message: '分公司行业支撑经理不能为空', trigger: 'blur' }],   
                itCapital:[{ required: true, message: '资本类总金额IT不能为空', trigger: 'blur' }], 
                ctCapital:[{ required: true, message: '资本类总金额CT不能为空', trigger: 'blur' }], 
                ctCost:[{ required: true, message: '成本类总金额CT不能为空', trigger: 'blur' }], 
                itCost:[{ required: true, message: '成本类总金额IT不能为空', trigger: 'blur' }], 
                itAmount:[{ required: true, message: '总收入金额IT不能为空', trigger: 'blur' }], 
                ctAmount:[{ required: true, message: '总收入金额CT不能为空', trigger: 'blur' }], 
                profitMargin:[{ required: true, message: '年平均净利润率不能为空', trigger: 'blur' }], 
                npv:[{ required: true, message: '累计现金净现值不能为空', trigger: 'blur' }], 
                pbp:[{ required: true, message: '回收期不能为空', trigger: 'blur' }]                
            },
            /* 文件上传数据 */
            fileUploadLoading: {
                load: false,
                info: '',
            }
            }
        },
        methods: {
            checkInput(data){                       
                data=data.replace(/[^\-\d.]/g,""); //清除"数字","-"和"."以外的字符                    
                data=data.replace(/^\./g,""); //验证第一个字符是数字或"-"
                data=data.replace(/\.{2,}/g,"").replace(/\-{2,}/g,"-"); //只保留第一个, 清除多余的
                data=data.replace(".","$#$").replace(/\./g,"").replace("$#$",".");     
                data=data.replace("-","$#$").replace(/\-/g,"").replace("$#$","-");   
                data=data.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3'); //只能输入两个小数
                return data;                
            },
            pickFileEvent(item){
                Tool.fileUploadMethod(async files => {
                    if (files[0].size > 1024 * 1024 * 300) {
                        this.$message.error('请上传小于300M的文件！');
                        return
                    }
                    if (files[0].name.length > 200) {
                        this.$message.error('文件名称不能大于200个字符！');
                        return
                    }
                    this.pageLoading = true;
                    this.fileLoading.info = '文件开始上传';
                    let str = `上传文件成功！`;
                    /* 文件上传方法 */
                    let result = await postRequestMethod('FILE_ADD', { 'file': files[0] }, progress => {
                        this.fileLoading.info = `文件上传中，已完成：${Math.floor((progress.loaded / progress.total) * 100)}%`;
                        if (progress.loaded / progress.total * 100 >= 100) {
                            this.fileLoading.info = `文件上传完成`;
                        }
                    });
                    this.pageLoading = false;
                    if (!!result && result.code === 'SUCCESS') {
                        /* 附件回显 */                    
                        this.pageData.adjunkFileName = result.data.fileName;
                        this.pageData.adJunk=result.data;
                        this.$notify.success({
                            title: '上传文件',
                            type: 'success',
                            message: str,
                            duration: 3000,
                            showClose: false
                        });
                    } else {
                        this.$message.error(!!result ? result.message : '接口异常');
                    }
                });
            },
            otherPickFileEvent(item){
                Tool.fileUploadMethod(async files => {
                    if (files[0].size > 1024 * 1024 * 300) {
                        this.$message.error('请上传小于300M的文件！');
                        return
                    }
                    if (files[0].name.length > 200) {
                        this.$message.error('文件名称不能大于200个字符！');
                        return
                    }
                    this.pageLoading = true;
                    this.fileLoading.info = '文件开始上传';
                    let str = `上传文件成功！`;
                    /* 文件上传方法 */
                    let result = await postRequestMethod('FILE_ADD', { 'file': files[0] }, progress => {
                        this.fileLoading.info = `文件上传中，已完成：${Math.floor((progress.loaded / progress.total) * 100)}%`;
                        if (progress.loaded / progress.total * 100 >= 100) {
                            this.fileLoading.info = `文件上传完成`;
                        }
                    });
                    this.pageLoading = false;
                    if (!!result && result.code === 'SUCCESS') {
                        /* 附件回显 */                    
                        this.pageData.otherAdJunkFileNAme = result.data.fileName;
                        this.pageData.otherAdJunk=this.adjunk=result.data;
                        this.$notify.success({
                            title: '上传文件',
                            type: 'success',
                            message: str,
                            duration: 3000,
                            showClose: false
                        });
                    } else {
                        this.$message.error(!!result ? result.message : '接口异常');
                    }
                });
            },
            submitEvent () {
                // this.$refs.submitForm.validate(valid => {
                    // if (valid) {
                        this.submitFunc();
                    // } else {
                        // return 0;
                    // }
                // });
            },
            changeCUnit(data){               
                if(data*1>=1000007){
                        this.regionShow=true;
                    }else{
                        this.regionShow=false;
                }                                                                     
                this.list['children'].forEach((item,index)=>{                                                              
                    if(item.orgCode===data){                              
                        this.pageData.region='';                                                    
                        this.regions=item.children                                    
                        // this.getPc(item.orgCode);
                    }
                })            
            },
            changePolicyDecision(data){                   
                if(data.indexOf('省')>-1){
                    this.pcOrcc=true;
                    this.getBranch('');
                }else{
                    this.pcOrcc=false;
                    this.getBranch(this.pageData.region);
                }

            },
            async getBranch(code){
                
                let result = await getRequestMethod('QUERY_USER_BRANCH',{roleCode:'HYZCJL',orgCode:code});                
                if(result.code==='SUCCESS'){                                        
                    this.pcs=result.data;
                }
            },
            // async getPc(code){                   
            //     let result = await getRequestMethod('QUERY_USER_BRANCH',{roleCode:'HYZCJL',orgCode:code});
            //     if(result.code==='SUCCESS'){                                        
            //         this.pcs=result.data;                
            //     }
            // },
            async getMenu(){
                
                let result = await getRequestMethod('MENU_LIST',{key:'行业属性'});
                if(result.code==='SUCCESS'){                        
                    this.industrys=result.data;
                }

                let result2 = await getRequestMethod('MENU_LIST',{key:'项目类型'});
                if(result2.code==='SUCCESS'){
                    this.projectTypes=result2.data
                }

                let result3 = await getRequestMethod('MENU_LIST',{key:'支撑方式'});
                if(result3.code==='SUCCESS'){
                    this.supportTypes=result3.data
                }

                let result4 = await getRequestMethod('MENU_LIST',{key:'采购方式'});
                if(result4.code==='SUCCESS'){                
                    this.purchaseTypes=result4.data
                }

                let result5 = await getRequestMethod('MENU_LIST',{key:'决策类型'});
                if(result5.code==='SUCCESS'){
                    this.policyDecisions=result5.data
                }

                let result6 = await getRequestMethod('MENU_LIST',{key:'资金支出类型'});
                if(result6.code==='SUCCESS'){
                    this.capitalExpenditureTypes=result6.data
                }         
            },        
            async queryAllBrrach(){
                let result7 = await getRequestMethod('COMPANY_TREE');
                if(result7.code==='SUCCESS'){                
                    let newList=[];                
                    result7.data[0]['children'].forEach((item, index) => {
                        newList.push({
                            value:item.orgCode,
                            label:item.orgName,                            
                        })                                                  
                    });                                  
                    this.list=result7.data[0];                                   
                    this.cUnits=newList;
                }        
            },
            async submitFunc () {                          
                let result = await postRequestMethod('PROJECT_ADD', this.pageData);
                if (!!result && result.code === '200') {
                    this.$router.go(-1);
                } else {
                    this.$message.error(!!result ? result.message : '接口异常');
                }
            }           
        },
        created () {               
            this.getMenu();
            this.queryAllBrrach();        
        },
    // mounted () {   
    //     this.$root.eventBus.$emit('orderChange', this.breadList);
    // }
}
</script>

<style lang="less" scoped>
.flow-height {
  height: 130px !important;
}
/deep/.el-cascader.el-cascader--medium{
    width: 100%;
}
</style>