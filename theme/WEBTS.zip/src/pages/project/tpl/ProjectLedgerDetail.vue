/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <detail-layout v-loading="pageLoading" :breadcrumb-list="breadList">
    <div class="common-form-container full">
      <article>
        <el-form
          ref="submitForm"
          :model="pageData"
          :rules="rules"
          label-position="top"
          size="medium"
        >
            <el-row style="margin-top:20px;margin-bottom: 20px;">
                <span>项目信息</span>
            </el-row>
          <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label="项目名称" prop="title">
                <el-input v-model="pageData.title" placeholder="请填写项目命题"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目编号" prop="upperLimit">
                <el-input v-model="pageData.upperLimit" placeholder="请填写成本剔除上线"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="资金支出类型" prop="limitDis">
                <el-input v-model="pageData.limitDis" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>            
            <el-col :span="8">
              <el-form-item label="年份" prop="endDate">
                <el-date-picker
                  v-model="pageData.endDate"
                  type="datetime"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  placeholder="选择截止时间"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="建设单位" prop="limitDis">
                <el-input v-model="pageData.limitDis" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="归属县区" prop="limitDis">
                <el-input v-model="pageData.limitDis" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="行业属性" prop="limitDis">
                <el-input v-model="pageData.limitDis" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
           
            <el-col :span="8">
              <el-form-item label="项目类型" prop="limitDis">
                <el-input v-model="pageData.limitDis" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
                    
          </el-row>
           <el-row style="margin-top:20px;margin-bottom: 20px;">
                <span>项目金额</span>
            </el-row>
             <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label=" IT总收入金额" prop="title">
                <el-input v-model="pageData.title" placeholder="请填写项目命题"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label=" IT总收入总收入进度（%）" prop="upperLimit">
                <el-input v-model="pageData.upperLimit" placeholder="请填写成本剔除上线"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label=" IT总收入总收入进度（%）" prop="limitDis">
                <el-input v-model="pageData.limitDis" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label=" IT总收入总收入进度（%）" prop="limitDis">
                <el-input v-model="pageData.limitDis" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>                                               
          </el-row>

          <el-row style="margin-top:20px;margin-bottom: 20px;">
                <span>出账信息</span>
            </el-row>
             <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label=" IT总收入金额" prop="title">
                <el-input v-model="pageData.title" placeholder="请填写项目命题"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label=" IT总收入总收入进度（%）" prop="upperLimit">
                <el-input v-model="pageData.upperLimit" placeholder="请填写成本剔除上线"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label=" IT总收入总收入进度（%）" prop="limitDis">
                <el-input v-model="pageData.limitDis" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label=" IT总收入总收入进度（%）" prop="limitDis">
                <el-input v-model="pageData.limitDis" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>                                               
          </el-row>
        </el-form>
      </article>
      <footer>
        <el-button size="small" @click="submitEvent" type="primary">提&nbsp;&nbsp;交</el-button>
        <el-button @click="$router.go(-1)" size="small" plain>取消</el-button>
      </footer>
    </div>
  </detail-layout>
</template>

<script>
import DetailLayout from "@/pages/layout/DetailLayout";
import { getRequestMethod, postRequestMethod, postNewRequestMethod } from "@/api/common";
import Tool from "@/util/tool";
import { mapGetters } from "vuex";

export default {
  components: { DetailLayout },
  props: {
    breadList: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    ...mapGetters({
      userInfo: 'getUserInfo'
    })
  },
  data () {
      let endDateValidater = (rules, value, callback) =>{
          let endTime = new Date(value).getTime();
          let nowTime = new Date().getTime();
          if (endTime > nowTime) {
            callback(); 
          } else {
            callback(new Error('截止时间不能早于当前时间'));
          }
      };
    return {
      pageLoading: false,
      pageData: {
        title: '',
        attachment: '',
        attachmentName: '',
        devReq: '',//开发需求
        endDate: '',
        limitDis: '',//时限要求
        submitDate: '',
        submit: '',
        submitName: '',
        submitPhone: '',
        upperLimit: '',//成本剔除上限
      },
      rules: {
        title: [{ required: true, message: '项目命题不能为空', trigger: 'blur' }],
        upperLimit: [{ required: true, message: '成本剔除上限不能为空', trigger: 'blur' }],
        endDate: [
            { required: true, message: '截止时间不能为空', trigger: 'blur' },
            { validator: endDateValidater}
        ],
        devReq: [{ required: true, message: '开发要求不能为空', trigger: 'blur' }],
        attachmentName: [{ required: true, message: '附件不能为空', trigger: 'blur' }],
        limitDis: [{ required: true, message: '时限要求不能空', trigger: 'blur' }]
      },
      /* 文件上传数据 */
      fileUploadLoading: {
        load: false,
        info: '',
      }
    }
  },
  methods: {
    submitEvent () {
      this.$refs.submitForm.validate(valid => {
        if (valid) {
          this.submitFunc();
        } else {
          return 0;
        }
      });
    },
    async submitFunc () {
      let result = await postRequestMethod('BILLBOARD_SAVE', this.pageData);
      if (!!result && result.code === 'success') {
        this.$router.go(-1);
      } else {
        this.$message.error(!!result ? result.message : '接口异常');
      }
    },
    uploadFileEvt () {
      Tool.fileUploadMethod(async files => {
        if (files[0].size > 1024 * 1024 * 300) {
          this.$message.error('请上传小于300M的文件！');
          return
        }
        this.fileUploadLoading.load = true;
        this.fileUploadLoading.info = '文件开始上传';
        let str = `上传文件成功！`;
        /* 文件上传方法 */
        let result = await postNewRequestMethod('UPLOAD_FILE', { 'file': files[0] }, progress => {
          console.log(`当前的进度--${(progress.loaded / progress.total) * 100}%`)
          this.fileUploadLoading.info = `文件上传中，已完成：${Math.floor((progress.loaded / progress.total) * 100)}%`;
          if (progress.loaded / progress.total * 100 >= 100) {
            this.fileUploadLoading.info = `文件上传完成`;
          }
        });
        this.fileUploadLoading.load = false;
        if (!!result && result.success) {
          /* 附件回显 */
          this.pageData.attachment = result.filePath;
          this.pageData.attachmentName = result.fileName;

          this.$notify.success({
            title: '上传文件',
            type: 'success',
            message: str,
            duration: 3000,
            showClose: false
          });
        } else {
          this.$message.error(!!result ? result.message : '接口异常');
        }
      });
    }    
  },
  created () {


  },
  mounted () {   
    this.$root.eventBus.$emit('orderChange', this.breadList);
  }
}
</script>

<style lang="less" scoped>
.flow-height {
  height: 130px !important;
}
</style>