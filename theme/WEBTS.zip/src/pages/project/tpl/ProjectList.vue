/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <list-layout :breadcrumb-list="breadList">
    <!-- 查询form表单 -->
    <el-form slot="header" id="vague" inline :model="queryData" size="small" label-position="left">
        <el-form-item label="项目名称:">
            <el-input v-model="queryData.pName" size="small" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="项目编号:">
            <el-input v-model="queryData.projectSn" size="small" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item >
            <el-button type="primary" size="medium" @click="accurateEvent('')">查询</el-button>
        </el-form-item>
        <el-button @click="add()" size="medium" type="primary">
            增加           
        </el-button>               
    </el-form>  
    <!-- 正文表格 -->
    <el-table v-loading="tableData.loading" :data="tableData.data" height="100%">
      <el-table-column v-for="(item,i) in tableData.column" :label="item.label" :prop="item.key"
        :min-width="item.minWidth" :width="item.width" :key="`table_key_${i}`" align="center" show-overflow-tooltip>
        <template slot-scope="scope">
          <div v-if="item.key === 'state'">
            <el-button type="text" size="mini" icon="el-icon-tickets" @click="tableCellEvt(scope.row)"></el-button>
            <el-button type="text" v-if="scope.row.edite" size="mini" icon="el-icon-edit" @click="tableCellEdite(scope.row)"></el-button>          
          </div>
          <span v-else class="common-table-cell">{{scope.row[item.key]}}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 导出/分页 -->
    <!-- <el-button slot="footer" type="primary" icon="el-icon-download" size="small">导出</el-button> -->
    <el-pagination @size-change="pagingEvent($event, 'size')" @current-change="pagingEvent($event, 'current')"
      :current-page="pagingData.current" :page-sizes="pagingData.sizes" :page-size="pagingData.size"
      :total="pagingData.total" slot="footer" layout="total, sizes, prev, pager, next, jumper"></el-pagination>
  </list-layout>
</template>

<script>
import ListLayout from "@/pages/layout/ListLayout";
import BaseView from "@/pages/BaseView";
import { getRequestMethod, postRequestMethod } from "@/api/common";
import { mapGetters } from "vuex";

export default {
    extends: BaseView,
    components: { ListLayout },
    props: {
        breadList: {
        type: Array,
        default: () => []
        }
    },
    computed: {
        ...mapGetters({
            userInfo: 'getUserInfo'
        }),        
    },
    data () {
        return {        
        queryData: {
            pName: '',
            projectSn: '',        
        }
        }
    },   
    methods: {
            add(){
                this.$router.push({ path: '/project/projectAdd'});
            },
            pageEvent (type) {
                if(type==='expand'){
                    this.queryShow = !this.queryShow;
                }else{
                    if (this.tableData.loading) return;
                    this.pagingData.current = 1;
                    this.getTableData();
                }
            
            },
            accurateEvent(){
                this.getTableData();
            },

            async getTableData () {            
                this.tableData.loading = true;
                let result = await getRequestMethod('PROJECT_ALL_PRIJECT', Object.assign(this.queryData, {
                    pageSize: this.pagingData.size,
                    pageNum: this.pagingData.current}
                ));

                if (!!result && result.code === 'SUCCESS') {                                     
                    this.tableData.data = result.data.dataList;
                    this.pagingData.total = result.data.totalNum;
                    this.tableData.loading = false;
                    this.dealData();
                } else {
                    this.$message.error(!!result ? result.message : '接口异常');
                    this.tableData.show = false;
                }
            },
            dealData () {
                this.tableData.data.map((item, k) => {
                    item.edite=false;
                    if(item.createUser===this.$store.getters.getLoginUserInfo.userInfo.loginName){
                        
                        item.edite=true;
                    }
                    item.index = k + 1;
                    item.opt = ['详情'];
                })                
            },
            tableCellEvt (row) {
                sessionStorage.setItem(this.cacheKey, JSON.stringify({ ...this.queryData, pageTotal: this.pagingData.total }));      
                this.$router.push({ path: '/project/projectDetail', query: { id: row.pid } })
            },
            tableCellEdite(row){                
                sessionStorage.setItem(this.cacheKey, JSON.stringify({ ...this.queryData, pageTotal: this.pagingData.total }));      
                this.$router.push({ path: '/project/projectUpdate', query: { id: row.pid } })
            }  
    },
    mounted () {

        /* 如果 exportData 存在数据需要对页面参数进行回填，主要判断是否有分页参数 */
        if (!!this.exportData.pageSize) {
            this.queryData.subject = this.exportData.subject;        
        }
        /* 初始化页面表格列属性数据 */
        this.tableData.column = [
        { label: '项目名称', key: 'pName', width: 200 },
        { label: '项目编号', key: 'projectSn', width: 220 },
        { label: '年份', key: 'projectYear', width: 180 },
        { label: '建设单位', key: 'cUnit', width: 180 },
        //   { label: '归属县区', key: 'region', minWidth: 200 },
        { label: '行业属性', key: 'industry', minWidth: 200 },
        { label: '决策类型', key: 'policyDecision', minWidth: 200 },
        { label: '资金支出类型', key: 'capitalExpenditureType', minWidth: 200 },
        { label: '项目类型', key: 'projectType', minWidth: 200 },
        { label: '立项编码', key: 'approvalSn', minWidth: 200 },
        { label: '预算编码', key: 'budgetSn', minWidth: 200 },
        //   { label: '省公司行业支撑经理', key: 'pc', minWidth: 200 },
        //   { label: '分公司行业支撑经理', key: 'cc', minWidth: 200 },
        //   { label: '总投资金额（元）IT', key: 'CostItCount', minWidth: 200 },
        //   { label: '总投资金额（元）CT', key: 'CostCtCount', minWidth: 200 },
        //   { label: '资本类金额（元）IT', key: 'itCapital', minWidth: 200 },
        //   { label: '资本类金额（元）CT', key: 'ctCapital', minWidth: 200 },
        //   { label: '成本类总金额（元）CT', key: 'itCost', minWidth: 200 },
        //   { label: '成本类总金额（元）IT', key: 'ctCost', minWidth: 200 },
        //   { label: '总收入金额（元）IT', key: 'itAmount', minWidth: 200 },
        //   { label: '总收入金额（元）CT', key: 'ctAmount', minWidth: 200 },
        //   { label: '年平均净利润率（%）', key: 'profitMargin', minWidth: 200 },
        //   { label: '累计现金净现值（元）', key: 'npv', minWidth: 200 },
        //   { label: '回收期(年）', key: 'pbp', minWidth: 200 },
        //   { label: '采购方式', key: 'purchaseType', minWidth: 200 },
        //   { label: '支撑方式', key: 'supportType', minWidth: 200 },
        //   { label: '会议纪要号', key: 'minutesSn', minWidth: 200 },
        //   { label: '会议纪要附件', key: 'adjunk', minWidth: 200 },
        //   { label: '其它附件', key: 'OtherAdjunk', minWidth: 200 },
        //   { label: '备注说明', key: 'unionDis', minWidth: 200 },
        { label: '操作', key: 'state', width: 100 }
        ];    
        this.$root.eventBus.$emit('orderChange', this.breadList);
    },
    created(){
        /* 查询表格数据 */
        this.getTableData();    
    }
}
</script>