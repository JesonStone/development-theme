/*********************************************************************
* Meeting second router file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
    <router-view :breadList="breadList"></router-view>
</template>

<script>
    export default {
        data() {
            return {
                breadcrumbList: {
                    "_project_projectList": [{path: '', name: '项目管理'}, {path: '', name: '项目管理列表'}],                  
                    "_project_projectDetail": [{path: '', name: '项目管理'}, {path: '', name: '项目管理详情'}],   
                    "_project_LedgerList": [{path: '', name: '项目管理'}, {path: '', name: '项目管理出账列表'}],                  
                    "_project_LedgerDetail": [{path: '', name: '项目管理'}, {path: '', name: '项目管理出账详情'}],                  
                },
                breadList: []
            }
        },
        watch: {
            "$route.path": function(val) {
                this.assembleBreadcrumb(val);
            }
        },
        methods: {
            assembleBreadcrumb(path) {                
                if (path !== '') path = path.replace(/\//g, '_');
                this.breadList = JSON.parse(JSON.stringify(this.breadcrumbList[path] || []));
            }
        },
        created() {            
            sessionStorage.removeItem('page_list_params_cache');

            this.assembleBreadcrumb(this.$route.path);
        }
    }
</script>