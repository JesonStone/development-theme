/*********************************************************************
* Static variable file
* Created by deming-su on 2019/11/21
*********************************************************************/

<template>
    <div>
        <!-- content here -->
    </div>
</template>

<script>
    import { mapGetters } from "vuex";
    
    export default {
        computed: {
            ...mapGetters({
                menuData: "getCurrentMenuData"
            })
        },
        watch: {
            menuData: function(val) {
                console.log('================== watch start ==================');
                console.log(JSON.stringify(val));
                console.log('================== watch end ==================');
            }
        },
        created() {
            console.log('================== created start ==================');
            console.log(JSON.stringify(this.menuData));
            console.log('================== created end ==================');
        }
    }
</script>