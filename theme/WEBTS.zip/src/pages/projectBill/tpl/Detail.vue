<!--
 * @Descripttion: 任务管理
 * @Author: zhixiang-bai
 * @Date: 2020-01-07 11:43:18
 -->

<template>
    <detail-layout v-loading="pageLoading">
        <div class="commone-detail-layout">
            <div class="main">
                <div class="box-detail">
                    <div class="title">项目信息</div>
                    <div class="box-content">
                        <div v-for="(item,k) in baseObj" :key="`key_${k}`" :class="item.clx">
                            <div class="label">{{item.label}}</div>
                            <div class="text2">{{item.value}}</div>
                        </div>
                    </div>
                </div>
                <div class="box-detail">
                    <div class="title">项目金额</div>
                    <div class="box-content">
                        <div v-for="(item,k) in moneyObj" :key="`key2_${k}`" :class="item.clx">
                            <div class="label">{{item.label}}</div>
                            <div class="text2">{{item.value}}</div>
                        </div>
                    </div>
                </div>
                <div class="box-detail">
                    <div class="title">出账明细</div>
                    <div class="box-content">
                        <template v-for="(item,index) in icomeDetailList">
                            <div :key="`key31_${index}`" class="item w2">
                                <div class="label">序号：</div>
                                <div class="text2">{{index+1}}</div>
                            </div>
                            <div :key="`key32_${index}`" class="item w2">
                                <div class="label">合同名称：</div>
                                <div class="text2">{{item.contractName}}</div>
                            </div>
                            <div :key="`key33_${index}`" class="item w2">
                                <div class="label">收入类型：</div>
                                <div class="text2">{{item.incomeType}}</div>
                            </div>
                            <div :key="`key34_${index}`" class="item w2">
                                <div class="label">IT收入金额（元）：</div>
                                <div class="text2">{{item.itIncome}}</div>
                            </div>
                            <div :key="`key35_${index}`" class="item w2">
                                <div class="label">CT收入金额（元）：</div>
                                <div class="text2">{{item.ctIncome}}</div>
                            </div>
                            <div :key="`key36_${index}`" class="item w2">
                                <div class="label">到账时间：</div>
                                <div class="text2">{{item.arrivalDate}}</div>
                            </div>
                            <div :key="`key37${index}`" class="item w2">
                                <div class="label">到账凭证：</div>
                                <div class="text2">
                                    <template v-if="!!item.billFile && !!item.billFile.fileName">
                                        <span class="one-line" style="padding-left: 10px;">{{item.billFile.fileName}}</span>
                                        <span @click="downloadEvent(item.billFile.fileName, item.billFile.filePath)" class="download-btn download"></span>
                                    </template>
                                    <span v-else>无</span>
                                </div>
                            </div>
                            <div :key="`key38_${index}`" class="item w2">
                                <div class="label">备注：</div>
                                <div class="text2">{{item.remark}}</div>
                            </div>
                            <div :key="`key39_${index}`" class="one-splite-line" style="float: left;width: 100%;"></div>
                        </template>
                    </div>
                </div>
                <!-- <div class="box-detail">
                    <div class="title">相关附件</div>
                    <div class="box-content">
                        <div>计划表（PDF）</div>
                        <div v-for="(file,k) in this.pdfFiles" :key="`key_${k}`" class="bg-gray">
                            <span class="one-line" style="padding-left: 10px;">{{file.fileName}}</span>
                            <span @click="downloadEvent(file.fileName, file.filePath)" class="download-btn download"></span>
                        </div>
                        <div>计划表（EXCEL）</div>
                        <div v-for="(file,k) in this.excelFiles" :key="`key2_${k}`" class="bg-gray">
                            <span class="one-line" style="padding-left: 10px;">{{file.fileName}}</span>
                            <span @click="downloadEvent(file.fileName, file.filePath)" class="download-btn download"></span>
                        </div>
                    </div>
                </div> -->
            </div>
            <div class="footer">
                <el-button  @click="$router.go(-1)" size="small">返回</el-button>
            </div>
        </div>
    </detail-layout>
</template>

<script>
    import DetailLayout from "@/pages/layout/DetailLayout";
    import {getFullUrl, getRequestMethod} from "@/api/common";
    import Tool from "@/util/tool";
    import {mapGetters} from 'vuex';

    export default {
        components: { DetailLayout },
        props: {
            breadList: {
                type: Array,
                default: () => []
            }
        },
        // computed:{
        //     ...mapGetters({
        //         userInfo:'getUserInfo'
        //     })
        // },
        data() {
            return {
                pageLoading: false,
                rowId: '',
                baseObj: [
                    {label:'项目名称:',clx:'item w2', key:'pName', value:''},
                    {label:'项目编号：',clx:'item w2', key:'projectSn', value:''},
                    {label:'资金支出类型：',clx:'item w2', key:'capitalExpenditureType', value:''},
                    {label:'年份：',clx:'item w2', key:'projectYear', value:''},
                    {label:'建设单位：',clx:'item w2', key:'cUnit', value:''},
                    {label:'归属县区：',clx:'item w2', key:'region', value:''},
                    {label:'行业属性：',clx:'item w2', key:'industry', value:''},
                    {label:'项目类型：',clx:'item w2', key:'projectType', value:''},
                ],
                moneyObj:[
                    {label:'最近一次收款时间：',clx:'item w2', key:'maxArrivalDate', value:''},
                    {label:'所需收入总金额：',clx:'item w2', key:'totalIncome', value:''},
                    {label:'累计收入进度（%）：',clx:'item w2', key:'incomeRate', value:''},
                ],
                icomeDetailList:[],
                pdfFiles:[],
                excelFiles:[],
            }
        },
        methods: {
            async getDetailInfo() {
                this.pageLoading = true;
                let result = await getRequestMethod('PROJECT_BILL_QUERY_INFO', {pid: this.rowId});
                this.pageLoading = false;

                if (!!result && result.code === 'SUCCESS') {
                    let allData = result.data;
                    this.dealData(allData);
                } else {
                    this.$message.error(!!result? result.message:'接口异常');
                }
            },
            dealData(data){
                //项目信息回填
                let projectData = data.projectInfo;
                this.baseObj.map( oo => {
                    oo.value = projectData[oo.key];
                });

                //统计信息回填
                let staData = data.billSatEntity;
                this.moneyObj.map( oo => {
                    oo.value = staData[oo.key];
                });

                //出账明细回填
                this.icomeDetailList = data.billEntity;
            },
            downloadEvent (fileName, filePath) {
                let downloadBase = getFullUrl('DOWNLOAD_URL');
                let url = downloadBase + '?filePath=' + filePath;
                Tool.downloadFiles(url, fileName);
            },
        },
        created() {
            this.rowId = this.$route.query.id;
            if (!this.rowId) {
                this.$message.error('非法进入页面，请重新进入');
            } else {
                this.getDetailInfo();
            }
        },
        mounted(){
            this.$root.eventBus.$emit('orderChange', this.breadList);
        }
    }
</script>

<style lang="less" scoped>
</style>