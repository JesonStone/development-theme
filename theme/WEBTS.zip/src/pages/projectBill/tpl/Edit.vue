/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <detail-layout v-loading="pageLoading" :breadcrumb-list="breadList">
    <div class="common-form-container full">
      <article>
        <el-form ref="submitForm" :model="pageData" label-position="top" size="medium">
            <el-row style="margin-top:20px;margin-bottom: 20px;"><span>项目信息</span></el-row>
          <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label="项目名称" :rules="rules.pName" prop="projectName" size="small">
                <el-input v-model="pageData.pName" size="small" readonly></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目编号" size="small">
                <el-input v-model="pageData.projectSn" size="small" readonly></el-input>
              </el-form-item>
            </el-col>
             <el-col :span="8">
              <el-form-item label="资金支出类型"  size="small">
                  <el-input v-model="pageData.capitalExpenditureType" size="small" readonly></el-input>
              </el-form-item>
            </el-col>
             <el-col :span="8">
              <el-form-item label="年份"><el-input v-model="pageData.projectYear" size="small" readonly></el-input></el-form-item>
            </el-col>
            <el-col :span="8">
                <el-form-item label="建设单位"><el-input v-model="pageData.cUnit" size="small" readonly></el-input></el-form-item>
            </el-col>                      
            <el-col :span="8">
                <el-form-item label="归属县区"><el-input v-model="pageData.region" size="small" readonly></el-input></el-form-item>
            </el-col>            
            <el-col :span="8">
                <el-form-item label="行业属性"><el-input v-model="pageData.industry" size="small" readonly></el-input></el-form-item>
            </el-col>
            <el-col :span="8">
                <el-form-item label="项目类型"><el-input v-model="pageData.projectType" size="small" readonly></el-input></el-form-item>
            </el-col>
          </el-row>
           <el-row style="margin-top:20px;margin-bottom: 20px;"><span>项目金额</span></el-row>
            <el-row :gutter="16">
                <el-col :span="8">
                    <el-form-item label="最近一次收款时间">
                        <el-input v-model="pageData.incomeTime" size="small" readonly></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="所需收入总金额" prop="incomeMoney">
                        <el-input v-model="pageData.incomeMoney" size="small" readonly></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="累计收入进度（%）" prop="incomeRate">
                        <el-input v-model="pageData.incomeRate" size="small" readonly></el-input>
                    </el-form-item>
                </el-col>
            </el-row>
           <el-row style="margin-top:20px;margin-bottom: 20px;">
               <span>出账明细</span>
               <el-button type="text" class="el-icon-circle-plus" @click="addOne"></el-button>
            </el-row>
            <el-row :gutter="16" v-for="(item,index) in pageData.incomeDetails" :key="`icome_${index}`">
                <div class="">
                    <el-col :span="8">
                        <el-form-item label="合同名称">
                            <el-select v-model="item.contractName" size="small">
                                <el-option v-for="(item,k) in contractList" :key="`pname_${k}`" :label="item.contractName" :value="item.contractName"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="收入类型" :prop="'incomeDetails.' + index + '.incomeType'" :rules="rules.incomeType">
                            <el-select v-model="item.incomeType" size="small">
                                <el-option v-for="(item,k) in icomeTypes" :key="`pname_${k}`" :label="item.value" :value="item.value"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="IT收入金额（元）" :prop="'incomeDetails.'+ index + '.itIncome'" :rules="rules.itIncome">
                            <el-input v-model="item.itIncome" @keyup.native="verifyNumber(item, 'IT')" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="CT收入金额（元）" :prop="'incomeDetails.' + index + '.ctIncome'" :rules="rules.ctIncome">
                            <el-input v-model="item.ctIncome" @keyup.native="verifyNumber(item, 'CT')"  size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="到账时间" :prop="'incomeDetails.' + index + '.arrivalDate'" :rules="rules.arrivalDate">
                            <el-date-picker
                                v-model="item.arrivalDate"
                                type="date"
                                value-format="yyyy-MM-dd"
                                placeholder="选择日期">
                            </el-date-picker>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="到账凭证">
                            <el-input v-model="item.billFile.fileName" size="small">
                                <el-button style="color:#409EFF;" slot="append" @click="pickFileEvent(item)" icon="el-icon-upload" size="small"></el-button>
                            </el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="24">
                        <el-form-item label="备注" :prop="'incomeDetails.' + index + '.remark'" :rules="rules.remark">
                            <el-input type="textarea" rows="3" @focus="getIncomeType(item)" v-model="item.remark"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="24">
                        <el-button type="text" style="color:#f40;" @click="deleteOne(index)">删除此明细</el-button>
                        <div class="one-splite-line"></div>
                    </el-col>
                </div>
            </el-row>
        </el-form>
      </article>
      <footer>
        <el-button size="small" @click="submitEvent" type="primary">提&nbsp;&nbsp;交</el-button>
        <el-button @click="$router.go(-1)" size="small" plain>取消</el-button>
      </footer>
    </div>
  </detail-layout>
</template>

<script>
import DetailLayout from "@/pages/layout/DetailLayout";
import { getRequestMethod, postRequestMethod, putRequestMethod } from "@/api/common";
import * as Tool from "@/util/tool";
import { mapGetters } from "vuex";



export default {
  components: { DetailLayout },
  props: {
    breadList: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    ...mapGetters({
    //   userInfo: 'getLoginUserInfo'
    })
  },
  data () {
        let remarkValidator = (rules, value, callback) =>{
            if (this.correntIncomeType === '其它收入') {
                if (!value) {
                    callback(new Error('收入类型为‘其他’时，备注为必填项目'));
                } else {
                    callback();
                }
            } else {
                callback();
            }
        };
        return {
            pageLoading:false,
            projects:[],
            contractList:[],
            icomeTypes:[],
            correntIncomeType:'',
            fileLoading:{
                info:'',
                load:'',
            },
            pageData: {
                pName:'',  
                projectSN:'',  
                capitalExpenditureType:'',  
                projectYear:'',  
                cUnit:'',  
                region:'',  
                industry:'',  
                projectType:'', 
                incomeTime:'',
                incomeMoney:'',
                incomeRate:'',
                incomeDetails:[
                    {pid:'' ,cid:'',incomeType:'', itIncome:'', ctIncome:'', arrivalDate:'', billFile:{fileName:'',filePath:''}, remark:''}
                ], 
            },
            rules: {
                projectName: [{ required: true, message: '请选择项目名称', trigger: 'change' }],
                incomeType: [{ required: true, message: '请选择收入类型', trigger: 'change' }],
                itIncome: [{ required: true, message: '请输入IT收入金额（元）', trigger: 'blur' }],
                ctIncome: [{ required: true, message: '请输入CT收入金额（元）', trigger: 'blur' }],
                arrivalDate: [{ required: true, message: '请选择到账时间', trigger: 'change' }],
                remark: [{ validator:remarkValidator, trigger: 'blur' }],
            },
        }
    },
    watch:{},
    methods: {
        submitEvent () {
            this.$refs.submitForm.validate(valid => {
                if (valid) {
                    this.submitFunc();
                } else {
                    return 0;
                }
            });
        },
        getIncomeType(item){
            this.correntIncomeType = item.incomeType;
        },
        async submitFunc () {  
            //回填项目id到提交数据中
            this.pageData.incomeDetails.forEach(oo => oo.pid = this.rowId);

            this.pageLoading = true;          
            let result = await putRequestMethod('PROJECT_BILL_MODIFY', this.pageData.incomeDetails);
            this.pageLoading = false;
            if (!!result && result.code === 'SUCCESS') {
                this.$router.go(-1);
            } else {
                this.$message.error(!!result ? result.message : '接口异常');
            }
        },
        async getIcomeTypes(){
            let result = await getRequestMethod('MENU_LIST',{key:'收入类型'});
            if(!!result && result.code==='SUCCESS'){                        
                this.icomeTypes=result.data;
            } else {
                this.$message.error(!!result.message ? result.message:'接口异常');
            }
        },
        async getContractList(){
            let result = await getRequestMethod('QUERY_CONTRACT_LIST',{pid:this.rowId, contractType:'收入类'});
            if(!!result && result.code==='SUCCESS'){                        
                this.contractList=result.data;
            } else {
                this.$message.error(!!result.message ? result.message:'接口异常');
            }
        },
        pickFileEvent(item){
            Tool.fileUploadMethod(async files => {
                if (files[0].size > 1024 * 1024 * 300) {
                    this.$message.error('请上传小于300M的文件！');
                    return
                }
                if (files[0].name.length > 200) {
                    this.$message.error('文件名称不能大于200个字符！');
                    return
                }
                this.pageLoading = true;
                this.fileLoading.info = '文件开始上传';
                let str = `上传文件成功！`;
                /* 文件上传方法 */
                let result = await postRequestMethod('FILE_ADD', { 'file': files[0] }, progress => {
                    this.fileLoading.info = `文件上传中，已完成：${Math.floor((progress.loaded / progress.total) * 100)}%`;
                    if (progress.loaded / progress.total * 100 >= 100) {
                        this.fileLoading.info = `文件上传完成`;
                    }
                });
                this.pageLoading = false;
                if (!!result && result.code === 'SUCCESS') {
                    /* 附件回显 */
                    item.billFile.fileName = result.data.fileName;
                    item.billFile.filePath = result.data.filePath;
                    this.$notify.success({
                        title: '上传文件',
                        type: 'success',
                        message: str,
                        duration: 3000,
                        showClose: false
                    });
                } else {
                    this.$message.error(!!result ? result.message : '接口异常');
                }
            });
        },
        addOne(){
            this.pageData.incomeDetails.push({pid:'',cid:'',incomeType:'', itIncome:'', ctIncome:'', arrivalDate:'', billFile:{fileName:'',filePath:''}, remark:''});
        },
        deleteOne(index){
            if (this.pageData.incomeDetails.length <=1) {
                this.$message.warning('请至少添加一条明细');
            } else {
                this.pageData.incomeDetails.splice(index,1);
            }
        },
        async getDetailInfo() {
            this.pageLoading = true;
            let result = await getRequestMethod('PROJECT_BILL_QUERY_INFO', {pid: this.rowId});
            this.pageLoading = false;

            if (!!result && result.code === 'SUCCESS') {
                this.pageData = result.data.projectInfo;

                let staObj = result.data.billSatEntity;
                this.$set(this.pageData, 'incomeTime', staObj.maxArrivalDate);
                this.$set(this.pageData, 'incomeMoney', staObj.totalIncome);
                this.$set(this.pageData, 'incomeRate', staObj.incomeRate);

                //明细
                this.$set(this.pageData, 'incomeDetails', result.data.billEntity);

                this.getContractList();
            } else {
                this.$message.error(!!result? result.message:'接口异常');
            }
        },
        verifyNumber(item, type){
            let param = type === 'IT' ? 'itIncome':'ctIncome'
            item[param] = item[param].replace(/[^\d.]/g,""); //清除"数字"和"."以外的字符
            item[param] = item[param].replace(/^\./g,""); //验证第一个字符是数字
            item[param] = item[param].replace(/\.{2,}/g,""); //只保留第一个, 清除多余的
            item[param] = item[param].replace(".","$#$").replace(/\./g,"").replace("$#$",".");
            item[param] = item[param].replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3'); //只能输入两个小数
        },

    },
    created () {
        this.rowId = this.$route.query.id;
        this.getDetailInfo();
        this.getIcomeTypes();
    },
    mounted () {   
        this.$root.eventBus.$emit('orderChange', this.breadList);
    }
}
</script>

<style lang="less" scoped>
</style>