<template>
    <list-layout>
        <!-- 查询form表单 -->
        <div slot="header">
            <el-form slot="header" inline :model="queryData" size="small" label-position="left">
                <el-form-item label="项目名称:">
                    <el-input v-model="queryData.pName" size='small'></el-input>
                </el-form-item>
                <el-form-item label="项目类型:">
                    <el-input v-model="queryData.projectType" size='small'></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" size="small" @click="pageEvent('query')">查询</el-button>
                </el-form-item>
            </el-form>
            <el-button class='new-btn' type="primary" size="small" @click="pageEvent('add')"><i class="el-icon-plus"></i> 添加出账信息</el-button>
        </div>
        <!-- 正文表格 -->
        <el-table v-loading="tableData.loading" :data="tableData.data" height="100%">
            <el-table-column 
                v-for="(item,i) in tableData.column" 
                :label="item.label" 
                :prop="item.key"
                :width="item.width" 
                :key="`table_key_${i}`" 
                show-overflow-tooltip>
                <template slot-scope="scope">
                    <div v-if="item.key === 'opt'">
                        <el-button 
                            type="text" 
                            size="mini" 
                            v-for="(it,k) in scope.row.opt" 
                            @click="tableCellEvt(it, scope.row)" 
                            :key="`opt_${i}_${k}`">
                            {{it}}
                        </el-button>
                    </div>
                    <span v-else class="common-table-cell">{{scope.row[item.key]}}</span>
                </template>
            </el-table-column>
        </el-table>
        <!-- 导出/分页 -->
        <el-pagination 
                @size-change="pagingEvent($event, 'size')" 
                @current-change="pagingEvent($event, 'current')"
                :current-page="pagingData.current" 
                :page-sizes="pagingData.sizes" 
                :page-size="pagingData.size"
                :total="pagingData.total" 
                slot="footer" 
                layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
    </list-layout>
</template>

<script>
    import ListLayout from "@/pages/layout/ListLayout";
    import BaseView from "@/pages/BaseView";
    import { getRequestMethod, postRequestMethod, deleteRequestMethod } from "@/api/common";
    import { mapGetters } from "vuex";
    import * as Tool from "@/util/tool";
    import ConstConfig from "@/config/const.config";
    export default {
        extends: BaseView,
        components: {
            ListLayout
        },
        props: {
            breadList: {
                type: Array,
                default: () => []
            }
        },
        computed: {
            // ...mapGetters({
            //     userInfo: 'getUserInfo',
            // }),
        },
        data() {
            return {
                projects: [],
                queryData: {
                    pName: '',
                    projectType: '',
                },
            }
        },
        methods: {
            pageEvent(type) {
                if (type === 'query') {
                    if (this.tableData.loading) return;
                    this.pagingData.current = 1;
                    this.getTableData();
                } else if (type === 'add') {
                    this.$router.push('/projectbill/add');
                } else if (type === 'export') {
                    this.exportExcel();
                }
            },
            async exportExcel () {
                Tool.exportExcel('ANNUAL_PLAN_EXPORT', this.queryData, '年度计划列表');
            },

            async getTableData() {
                this.tableData.loading = true;
                let result = await getRequestMethod('PROJECT_BILL_LIST', Object.assign(this.queryData, {
                    pageSize: this.pagingData.size,
                    pageNum: this.pagingData.current
                }));
                this.tableData.loading = false;

                if (!!result && result.code === 'SUCCESS') {
                    this.tableData.data = result.data.dataList;
                    this.pagingData.total = result.data.totalNum;
                    this.tableData.loading = false;
                    this.dealData();
                } else {
                    this.$message.error(!!result ? result.message:'接口异常');
                }
            },
            dealData() {
                this.tableData.data.map((item, k) => {
                    // let isCreater = item.createBy === this.userInfo.loginNo;
                    let isCreater = true;
                    item.opt = ['详情',isCreater ? '编辑':'',isCreater ? '删除':''];
                })
            },
            tableCellEvt(type, row) {
                sessionStorage.setItem(this.cacheKey, JSON.stringify({...this.queryData,pageTotal: this.pagingData.total}));
                switch (type) {
                    case "编辑":
                        this.$router.push({path: '/projectbill/edit', query: {id: row.pid}});
                        break;
                    case "详情":
                        this.$router.push({path: '/projectbill/detail', query: {id: row.pid}});
                        break;
                    case "删除":
                        this.deleteOne(row.annulPlanSerial);
                        break;
                }
            },
            deleteOne(rowId){
                this.confirmSubmit('删除', this.deleteInfo, rowId);
            },
            async deleteInfo(rowId){
                this.tableData.loading = true;
                let result = await getRequestMethod('ANNUAL_PLAN_REMOVE', {id: rowId});
                this.tableData.loading = false;

                if (!!result && result.code === 'success') {
                    this.$router.go(0);
                } else {
                    this.$message.error(!!result ? result.message:'接口异常');
                }
            },
            dealbuttonPormision(){
                this.canNew = this.actions.includes(ConstConfig.buttonConfig.annual_plan_add);
                this.canExport = this.actions.includes(ConstConfig.buttonConfig.annual_plan_export);
            },
        },
        created() {

            /* 如果 exportData 存在数据需要对页面参数进行回填，主要判断是否有分页参数 */
            if (!!this.exportData && !!this.exportData.pageSize) {
                this.queryData.patentType = this.exportData.patentType;
                this.queryData.registCertificateDateSt = this.exportData.registCertificateDateSt;
            }

            /* 初始化页面表格列属性数据 */
            this.tableData.column = [
                {label: '项目名称',key: 'pName'},
                {label: '项目编号',key: 'projectSn'},
                {label: '资金支出类型',key: 'capitalExpenditureType',width:120},
                {label: '年份', key: 'projectYear',width:60},
                {label: '建设单位', key: 'cUnit'},
                {label: '归属县区', key: 'region'},
                {label: '行业属性', key: 'industry'},
                {label: '项目类型', key: 'projectType'},
                {label: '最近一次收款时间', key: 'maxArrivalDate',width:140},
                {label: '所需收入总金额', key: 'totalIncome',width:140},
                {label: '累计收入进度（%）', key: 'incomeRate',width:150},
                {label: '操作', key: 'opt',width: 120},
            ];

            /* 查询表格数据 */
            this.getTableData();

        },
        mounted(){
            // this.dealbuttonPormision();
            this.$root.eventBus.$emit('orderChange', this.breadList);
        }
    }
</script>
<style lang="less" scoped>
    /deep/.el-form-item {
        margin-bottom: 18px;
    }
    .new-btn{
        margin: 15px 0 0 12px;
    }
</style>