/*********************************************************************
* Meeting second router file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
    <router-view :breadList="breadList"></router-view>
</template>

<script>
    export default {
        data() {
            return {
                breadcrumbList: {
                    "_contract_contractList": [{path: '', name: '合同管理'}, {path: '', name: '合同管理列表'}],                  
                    "_contract_contractAdd": [{path: '', name: '合同管理'}, {path: '', name: '合同管理新增'}],   
                    "_contract_contractUpdate": [{path: '', name: '合同管理'}, {path: '', name: '合同管理修改'}],   
                    "_contract_contractDetail": [{path: '', name: '合同管理'}, {path: '', name: '合同管理详情'}],   

                    "_contract_contractFlowOut": [{path: '', name: '合同管理'}, {path: '', name: '合同支出-列表'}],
                    "_contract_contractFlowOutDetail": [{path: '', name: '合同管理'}, {path: '', name: '合同支出-详情'}],
                    "_contract_contractFlowOutAdd": [{path: '', name: '合同管理'}, {path: '', name: '合同支出-新增'}],
                    "_contract_contractFlowOutEdit": [{path: '', name: '合同管理'}, {path: '', name: '合同支出-修改'}],

                    "_contract_contractFlowIn": [{path: '', name: '合同管理'}, {path: '', name: '合同收入-列表'}],
                    "_contract_contractFlowInDetail": [{path: '', name: '合同管理'}, {path: '', name: '合同收入-详情'}],
                    "_contract_contractFlowInAdd": [{path: '', name: '合同管理'}, {path: '', name: '合同收入-新增'}],
                    "_contract_contractFlowInEdit": [{path: '', name: '合同管理'}, {path: '', name: '合同收入-修改'}],
                },
                breadList: []
            }
        },
        watch: {
            "$route.path": function(val) {
                console.log(val)
                this.assembleBreadcrumb(val);
            }
        },
        methods: {
            assembleBreadcrumb(path) {
                if (path !== '') path = path.replace(/\//g, '_');                
                this.breadList = JSON.parse(JSON.stringify(this.breadcrumbList[path] || []));
            }
        },
        created() {

            sessionStorage.removeItem('page_list_params_cache');

            this.assembleBreadcrumb(this.$route.path);
        }
    }
</script>