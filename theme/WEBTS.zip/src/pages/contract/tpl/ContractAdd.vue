/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <detail-layout v-loading="pageLoading" :breadcrumb-list="breadList">
    <div class="common-form-container full">
      <article>
        <el-form
          ref="submitForm"
          :model="pageData"
          :rules="rules"
          label-position="top"
          size="medium"
        >
            <el-row style="margin-top:20px;margin-bottom: 20px;">
                <span>项目信息</span>
            </el-row>
          <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label="项目名称" prop="pName">                
                <el-select v-model="pageData.pName"  @change="changePName(pageData.pName)" placeholder="请选择">
                        <el-option                       
                        v-for="(item,k) in pNames"
                        :key="`key_${k}`"
                        :label="item.projectName"
                        :value="item.sn"
                        ></el-option>
                </el-select>   
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目编号" prop="upperLimit">                 
                <el-select v-model="pageData.upperLimit"  @change="changeCUnit()"   placeholder="请选择">
                        <el-option                       
                        v-for="(item,k) in upperLimits"
                        :key="`key_${k}`"
                        :label="item.sn"
                        :value="item.sn"
                        ></el-option>
                </el-select>          
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="年份" prop="year">              
                <el-input v-model="pageData.year" :disabled='true' placeholder="请填写成本剔除上线"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="建设单位" prop="cUnit">       
                <el-input v-model="pageData.cUnit" :disabled='true' placeholder="请填写成本剔除上线"></el-input>                         
              </el-form-item>
            </el-col>                       
            <el-col :span="8">
              <el-form-item label="归属县区" v-if="pageData.region!==''" prop="region">
                <el-input v-model="pageData.region"  :disabled='true' placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="行业属性" prop="industry">
                <el-input v-model="pageData.industry" :disabled='true' placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>                                           
          </el-row>
          <el-row style="margin-top:20px;margin-bottom: 20px;">
                <span>合同信息</span>
            </el-row>
          <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label="合同编号" prop="sn">
                <el-input v-model="pageData.sn" placeholder="请填写项目命题"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="合同名称" prop="contractName">
                <el-input v-model="pageData.contractName" placeholder="请填写成本剔除上线"></el-input>
              </el-form-item>
            </el-col>           
            <el-col :span="8">
              <el-form-item label="合同类型" prop="type">
                 <el-select v-model="pageData.type"  @change="changeType(pageData.type)"   placeholder="请选择">
                        <el-option                       
                        v-for="(item,k) in contractTypes"
                        :key="`key_${k}`"
                        :label="item.label"
                        :value="item.value"
                        ></el-option>
                </el-select>   
              </el-form-item>
            </el-col>                       
            <el-col :span="8">
              <el-form-item label="中标时间" prop="bidTime">
                <el-date-picker
                  v-model="pageData.bidTime"
                  type="date"                  
                  placeholder="选择截止时间"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="合同额-含税（元）" prop="amount">
                <el-input v-model="pageData.amount" @input.native="pageData.amount=checkInput(pageData.amount)" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>  
            <el-col :span="8">
              <el-form-item label="预计签约当年可纳收金额（元）" v-if="firstYearIncome" prop="firstYearIncome">
                <el-input v-model="pageData.firstYearIncome" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col> 
            <el-col :span="8">
              <el-form-item label="合同期（月）" prop="duration">
                <el-input v-model="pageData.duration" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col> 
            <el-col :span="8">
               <el-form-item label="履行开始时间" prop="startDate">
                <el-date-picker
                  v-model="pageData.startDate"
                  type="date"                  
                  placeholder="选择截止时间"
                ></el-date-picker>
              </el-form-item>
            </el-col> 
            <el-col :span="8">
               <el-form-item label="履行结束时间" prop="endDate">
                <el-date-picker
                  v-model="pageData.endDate"
                  type="date"                  
                  placeholder="选择截止时间"
                ></el-date-picker>
              </el-form-item>
            </el-col>                                          
            <el-col :span="8">
              <el-form-item label="甲方名称" prop="partA">
                <el-input v-model="pageData.partA" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col> 
            <el-col :span="8">
              <el-form-item label="乙方名称" prop="partB">
                <el-input v-model="pageData.partB" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col> 
             <el-col :span="8">
               <el-form-item label="审批完成时间" prop="reviewCompleteDate">
                <el-date-picker
                  v-model="pageData.reviewCompleteDate"
                  type="date"                  
                  placeholder="选择截止时间"
                ></el-date-picker>
              </el-form-item>
            </el-col>    
            <el-col :span="24">
              <el-form-item label="备注说明" prop="remark">
                <el-input v-model="pageData.remark" placeholder="请填写时限要求"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </article>
      <footer>
        <el-button size="small" @click="submitEvent" type="primary">提&nbsp;&nbsp;交</el-button>
        <el-button @click="$router.go(-1)" size="small" plain>取消</el-button>
      </footer>
    </div>
  </detail-layout>
</template>

<script>
import DetailLayout from "@/pages/layout/DetailLayout";
import { getRequestMethod, postRequestMethod, postNewRequestMethod } from "@/api/common";
import Tool from "@/util/tool";
import { mapGetters } from "vuex";
console.log(Tool)
export default {
    components: { DetailLayout },
    props: {
        breadList: {
        type: Array,
        default: () => []
        }
    },
    computed: {
        ...mapGetters({
            userInfo: 'getUserInfo'
        })
    },
    data () {
        return {
            firstYearIncome:false,
            pageLoading: false,
            pNames:[],
            upperLimits:[],
            contractTypes:[
                {label:"支出类",value:'支出类'},
                {label:"收入类",value:'收入类'},
            ],
            pageData: {                
                year:'',
                pName:'',
                amount: '',
                bidTime: '',
                contractName: '',
                type: '',
                duration: '',
                endDate: '',
                firstYearIncome: '',
                partA: '',
                partB: '',
                pid: '',
                remark: '',
                reviewCompleteDate: '',
                sn: '',
                startDate: ''                
            },
            rules: {
                pName:[{ required: true, message: '项目名称不能为空', trigger: 'blur' }],  
                upperLimit:[{ required: true, message: '项目编号不能为空', trigger: 'blur' }],  
                amount: [{ required: true, message: '合同额-含税（元）不能为空', trigger: 'blur' }],  
                bidTime: [{ required: true, message: '中标时间不能为空', trigger: 'blur' }],  
                contractName: [{ required: true, message: '合同名称不能为空', trigger: 'blur' }],  
                type: [{ required: true, message: '合同类型不能为空', trigger: 'blur' }],  
                duration: [{ required: true, message: '合同期不能为空', trigger: 'blur' }],  
                endDate: [{ required: true, message: '履行结束时间不能为空', trigger: 'blur' }],  
                // firstYearIncome: [{ required: true, message: '预计签约当年可纳收金额（元）不能为空', trigger: 'blur' }],  
                partA: [{ required: true, message: '甲方名称不能为空', trigger: 'blur' }],  
                partB: [{ required: true, message: '乙方名称不能为空', trigger: 'blur' }],                
                remark: [{ required: true, message: '备注不能为空', trigger: 'blur' }],  
                reviewCompleteDate: [{ required: true, message: '审批完成时间不能为空', trigger: 'blur' }],  
                sn: [{ required: true, message: '合同编号不能为空', trigger: 'blur' }],  
                startDate: [{ required: true, message: '履行开始时间不能为空', trigger: 'blur' }],  
            },
            /* 文件上传数据 */
            fileUploadLoading: {
                load: false,
                info: '',
            }
        }
    },
    methods: {
        checkInput(data){                        
            Tool.checkInput(data);
        },
        changeType(data){                 
            if(data!=='支出类'){
                this.firstYearIncome=true;
            }else{
                this.firstYearIncome=false;
            }
        },
        changeCUnit(){                     
            if(this.pageData.upperLimit===''){
                this.$message.error('确认项目名称和项目编号已选择');                
            }else{                
                this.getProjectBySnOrName();
            }            
        },
        changePName(data){            
            this.upperLimits=[];               
            let pName='';
            this.pNames.forEach(item=>{
                if(item.sn===data){
                    pName=item.projectName;
                }
            })                        
            this.pNames.forEach(item=>{
                if(item.projectName===pName){
                    this.upperLimits.push(item)
                }
            })                        
        },
        async getProjectBySnOrName(){
            let result = await getRequestMethod('PROJECT_INFO_LIST', {'sn':this.pageData.upperLimit});
            if (!!result && result.code === 'SUCCESS') {                
                this.pageData.year=result.data[0].year;       
                this.pageData.cUnit=result.data[0].construnctionUnit;
                this.pageData.region=result.data[0].region;
                this.pageData.industry=result.data[0].industry;                
                this.pageData.pid=result.data[0].id;
            } else {
                this.$message.error(!!result ? result.message : '接口异常');
            }
        },
        submitEvent () {            
            this.$refs.submitForm.validate(valid => {                
                if (valid) {
                    this.submitFunc();
                } else {
                    return 0;
                }
            });
        },
        async submitFunc () {
            let result = await postRequestMethod('ADD_CONTRACT', this.pageData);
            if (!!result && result.code === 'SUCCESS') {                
                this.$router.go(-1);
            } else {
                this.$message.error(!!result ? result.message : '接口异常');
            }
        },
        async getPName(){           
            let result = await getRequestMethod('PROJECT_INFO_LIST',{});            
            if (!!result && result.code === 'SUCCESS') {                
                this.pNames=result.data;
            } else {
                this.$message.error(!!result ? result.message : '接口异常');
                this.tableData.show = false;
            }
        }
    },
    created () {
        this.getPName();
    },
    mounted () {   
        this.$root.eventBus.$emit('orderChange', this.breadList);
    }
}
</script>

<style lang="less" scoped>
.flow-height {
  height: 130px !important;
}
</style>