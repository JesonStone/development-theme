<!--
 * @Descripttion: 任务管理
 * @Author: zhixiang-bai
 * @Date: 2020-01-07 11:43:18
 -->

<template>
    <detail-layout v-loading="pageLoading">
        <div class="commone-detail-layout">
            <div class="main">
                <div class="box-detail">
                    <div class="title">合同信息</div>
                    <div class="box-content">
                        <div v-for="(item,k) in baseObj" :key="`key_${k}`" :class="item.clx">
                            <div class="label">{{item.label}}</div>
                            <div class="text2">{{item.value}}</div>
                        </div>
                    </div>
                </div>
                <div class="box-detail">
                    <div class="title">收入明细</div>
                    <div class="box-content">
                        <div v-for="(item,k) in moneyObj" :key="`key_${k}`" :class="item.clx">
                            <div class="label">{{item.label}}</div>
                            <div class="text2">{{item.value}}</div>
                        </div>
                    </div>
                </div>                            
            </div>
            <div class="footer">
                <el-button  @click="$router.go(-1)" size="small">返回</el-button>
            </div>
        </div>
    </detail-layout>
</template>

<script>
    import DetailLayout from "@/pages/layout/DetailLayout";
    import {getFullUrl, getRequestMethod} from "@/api/common";
    import Tool from "@/util/tool";
    import {mapGetters} from 'vuex';

    export default {
        components: { DetailLayout },
        props: {
            breadList: {
                type: Array,
                default: () => []
            }
        },
        computed:{
            ...mapGetters({
                userInfo:'getUserInfo'
            })
        },
        data() {
            return {
                pageLoading: false,
                sn: '',
                id: '',
                baseObj: [
                    {label:'合同编号：',clx:'item w2', key:'sn', value:''},
                    {label:'合同名称:',clx:'item w2', key:'contractName', value:''},
                    {label:'合同额-含税(元)：',clx:'item w2', key:'amount', value:''},
                    {label:'预计签约当年可纳收金额(元)：',clx:'item w2 text14', key:'firstYearIncome', value:''},
                    {label:'对应收入',clx:'item w2', key:'count', value:''},
                ],
                moneyObj:[
                    {label:'收入类型:',clx:'item w2', key:'type', value:''},
                    {label:'出账周期：',clx:'item w2', key:'billingCycle', value:''},
                    {label:'预计出账起始日期：',clx:'item w2', key:'billingCycle', value:''},
                    {label:'IT收入金额（元）：',clx:'item w2', key:'itIncome', value:''},
                    {label:'CT收入金额（元）：',clx:'item w2', key:'ctIncome', value:''},
                    {label:'备注：',clx:'item w1', key:'remark', value:''},
                ],
                pageData: {}
            }
        },
        methods: {
            getCount() {
                let count = 0;
                let ctIncome = parseInt(this.pageData.ctIncome);
                let itIncome = parseInt(this.pageData.itIncome);
                if (!isNaN(ctIncome)) {
                    count = count + ctIncome;
                }
                if (!isNaN(itIncome )) {
                    count = count + itIncome;
                }
                return count;
            },
            async getDetailInfo() {
                this.pageLoading = true;
                let result = await getRequestMethod('INCOME_INFO_DETAIL', {id: this.id});
                this.pageLoading = false;

                if (!!result && result.code === 'SUCCESS') {
                    let data = result.data;
                    this.pageData = data;
                    //单独查询合同信息
                    this.moneyObj.map( oo => {
                        oo.value = data[oo.key];
                    });
                    if (!!data.cid) {
                        this.getContract(data.cid);
                    }
                } else {
                    this.$message.error(!!result? result.message:'接口异常');
                }
            },
            async getContract(cid) {
                this.pageLoading = true;
                let result = await getRequestMethod('QUERY_CONTRACT_LIST',{id:cid});
                this.pageLoading = false;
                if (!!result && result.code === 'SUCCESS' && !!result.data  &&  result.data.length === 1) {
                    let data = result.data[0];
                    this.baseObj.map( oo => {
                        oo.value = data[oo.key];
                        if (oo.key === 'count') {
                            oo.value = this.getCount();
                        }
                    });
                } else {
                    this.$message.error('查询合同信息异常');
                }
            },
        },
        created() {
            this.id = this.$route.query.id;
            if (!this.id) {
                this.$message.error('非法进入页面，请重新进入');
            } else {
                this.getDetailInfo();
            }
        },
        mounted(){
            this.$root.eventBus.$emit('orderChange', this.breadList);
        }
    }
</script>

<style lang="less" scoped>

    .text14 {
        >.text2{
            width: calc(~"100% - 14em") !important;
        }
    }

</style>