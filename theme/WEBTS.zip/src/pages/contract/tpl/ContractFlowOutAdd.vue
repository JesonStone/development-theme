/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31  合同收入
*********************************************************************/

<template>
  <detail-layout v-loading="pageLoading" :breadcrumb-list="breadList">
    <div class="common-form-container full">
      <article>
        <el-form
          ref="submitForm"
          :model="pageData"
          label-position="top"
          size="medium"
        >
            <el-row style="margin-top:20px;margin-bottom: 20px;">
                <span>合同信息</span>
            </el-row>
          <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label="合同名称" prop="contract" :rules="rules['contract']">
                <el-select  @change="setSecond" v-model="pageData.contract"  value-key="id" size="small" placeholder="请选择合同名称" >
                  <el-option v-for="(item,k) in contractList" :key="`${item.id}`" :label="item.contractName"
                             :value="item">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="合同编号" prop="sn" :rules="rules['sn']">
                <el-input v-model="pageData.sn" readonly placeholder="请填写合同编号"></el-input>
              </el-form-item>
            </el-col>            
            <el-col :span="8">
              <el-form-item label="合同额-含税（元）" prop="amount" :rules="rules['amount']">
                <el-input v-model="pageData.amount" readonly placeholder="请填写合同额-含税（元）"></el-input>
              </el-form-item>
            </el-col>                       
          </el-row>

          <el-row style="margin-top:20px;margin-bottom: 20px;">
                <span>支出明细</span>
                <el-button type="text" class="el-icon-circle-plus" @click="addOne"></el-button>
          </el-row>
          <el-row :gutter="16" v-for="(item,k) in pageData.incomeInfo" :key="`icome_${k}`">
            <el-col :span="8">
              <el-form-item label="序号" >
                <el-input :value="k+1" readonly placeholder="请填写序号"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="IT收入金额（元）" :prop="`incomeInfo[${k}].itDisburse`" :rules="rules['itDisburse']" >
                <el-input v-model="item.itDisburse"   @keyup.native = "clearNoNum(item,'itDisburse')" placeholder="请填写IT收入金额（元）"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="CT收入金额（元）" :prop="`incomeInfo[${k}].ctDisburse`" :rules="rules['ctDisburse']">
                <el-input v-model="item.ctDisburse" @keyup.native = "clearNoNum(item,'ctDisburse')" placeholder="请填写CT收入金额（元）"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="支出类型"  :prop="`incomeInfo[${k}].disburseType`" :rules="rules['disburseType']">
                  <el-select   v-model="item.disburseType" size="small" placeholder="请选择支出类型">
                    <el-option v-for="(item,k) in disburseType" :key="`pname_${k}`" :label="item.value" :value="item.value"></el-option>
                  </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="付款类型"  :prop="`incomeInfo[${k}].paymentType`" :rules="rules['paymentType']">
                <el-select   v-model="item.paymentType" size="small" placeholder="付款类型">
                  <el-option v-for="(item,k) in paymentType" :key="`pname_${k}`" :label="item.value" :value="item.value"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="备注说明" :prop="`incomeInfo[${k}].remark`" >
                <el-input v-model="item.remark" placeholder="请填写备注说明"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </article>
      <footer>
        <el-button size="small" @click="submitEvent" type="primary">提&nbsp;&nbsp;交</el-button>
        <el-button @click="$router.go(-1)" size="small" plain>取消</el-button>
      </footer>
    </div>
  </detail-layout>
</template>

<script>
import DetailLayout from "@/pages/layout/DetailLayout";
import { getRequestMethod, postRequestMethod, postNewRequestMethod } from "@/api/common";
import Tool from "@/util/tool";
import { mapGetters } from "vuex";

export default {
  components: { DetailLayout },
  props: {
    breadList: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    ...mapGetters({
      userInfo: 'getUserInfo'
    }),
  },
  data () {
    let validater = (rules, value, callback) => {

      if (this.pageData.count  <= this.pageData.amount) {
        callback();
      } else {
        callback(new Error('对应收入不能大于合同额-含税'));
      }
    };
    return {
      pageLoading: false,
      contractList: [],
      disburseType: [],
      paymentType: [],
      pageData: {
        contract:  '',
        cid: '',
        sn: '',
        amount: '',
        firstYearIncome: '',
        incomeInfo:[{
          cid: '',
          disburseType: '',
          paymentType: '',
          ctDisburse: '',
          itDisburse: '',
          remark: '',
        }]
      },
      rules: {
        contract: [{ required: true, message: '请选择合同名称', trigger: 'change' }],
        sn: [{ required: true, message: '请填写合同编号', trigger: 'change' }],
        amount: [{ required: true, message: '请填写合同额-含税（元）', trigger: 'change' }],
        firstYearIncome: [{ required: true, message: '请填写预计签约当年可纳收金额（元）', trigger: 'change' }],
        count: [{ required: true, message: '请填写对应收入', trigger: 'change' },{validator: validater, trigger:['change'] }],

        paymentType: [{ required: true, message: '请选择付款类型', trigger: 'change' }],
        disburseType: [{ required: true, message: '请选择支出类型', trigger: 'change' }],
        itDisburse: [{ required: true, message: '请填写IT收入金额（元）', trigger: 'blur' }],
        ctDisburse: [{ required: true, message: '请填写CT收入金额（元）', trigger: 'blur' }],
      },
    }
  },
  methods: {
    clearNoNum(item,key) {
      item[key] =  item[key].replace(/[^\d]/g, ""); //清除"数字"以外的字符;
    },
    setSecond(value) {
      this.pageData.cid  = value.id;
      this.pageData.sn  = value.sn;
      this.pageData.amount  = value.amount;
      this.pageData.firstYearIncome  = value.firstYearIncome;
    },
    addOne(){
      this.pageData.incomeInfo.push({
        disburseType: '',
        paymentType: '',
        ctDisburse: '',
        itDisburse: '',
        remark: '',
      });
    },
    deleteOne(index){
      if (this.pageData.incomeInfo.length <=1) {
        this.$message.warning('请至少添加一条明细');
      } else {
        this.pageData.incomeInfo.splice(index,1);
      }
    },
    async  getContractList() {
      this.pageLoading = true;
      let result = await getRequestMethod('QUERY_CONTRACT_LIST');
      this.pageLoading = false;
      if (!!result && result.code === 'SUCCESS') {
        this.contractList  = result.data;
      } else {
        this.$message.error(!!result ? result.message:'接口异常');
      }
    },
    submitEvent () {
      this.$refs.submitForm.validate(valid => {
        if (valid) {
          this.submitFunc();
        } else {
          return 0;
        }
      });
    },
    async submitFunc () {
      //重新构造参数
      let submit = [];
      let cid = this.pageData.cid;
      this.pageData.incomeInfo.forEach(oo =>{
        submit.push({
          cid: cid,
          ctDisburse: oo.ctDisburse,
          itDisburse: oo.itDisburse,
          disburseType: oo.disburseType,
          paymentType: oo.paymentType,
          remark: oo.remark,
          type: oo.type,
        });
      });
      this.pageLoading = true;
      let result = await postRequestMethod('DISBURSE_INFO_ADD', submit);
      this.pageLoading = false;
      if (!!result && result.code === 'SUCCESS') {
        this.$router.go(-1);
      } else {
        this.$message.error(!!result ? result.message : '接口异常');
      }
    },
    async getEnums(key,value){
      let result = await getRequestMethod("MENU_LIST", {key: value});
      if(!!result && result.code==='SUCCESS'){
        this[key] = result.data;
      } else {
        this.$message.error(!!result.message ? result.message:'接口异常');
      }
    },
  },
  created () {
    this.getContractList();
    this.getEnums("disburseType",'支出类型');
    this.getEnums("paymentType",'付款类型');
  },
  mounted () {   
    this.$root.eventBus.$emit('orderChange', this.breadList);
  }
}
</script>

<style lang="less" scoped>
.flow-height {
  height: 130px !important;
}
</style>