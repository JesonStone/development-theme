/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <list-layout :breadcrumb-list="breadList">
    <!-- 查询form表单 -->
    <el-form slot="header" inline :model="queryData" size="small" label-position="left">
      <el-form-item label="合同名称:">
        <el-select  v-model="queryData.contract"  value-key="id" size="small" placeholder="请选择合同名称" >
          <el-option v-for="(item,k) in contractList" :key="`${item.id}`" :label="item.contractName"
                     :value="item"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="收入类型:">
        <el-select   v-model="queryData.type" size="small" placeholder="请选择收入类型">
          <el-option v-for="(item,k) in type" :key="`pname_${k}`" :label="item.value" :value="item.value"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="出账周期:">
        <el-select v-model="queryData.billingCycle" size="small"  placeholder="请选择出账周期">
          <el-option v-for="(item,k) in billingCycle" :key="`pname_${k}`" :label="item.value" :value="item.value"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small" @click="pageEvent">查询</el-button>
      </el-form-item>
      <el-button @click="add" size="small" type="primary">
        增加
      </el-button>
    </el-form>
    <!-- 正文表格 -->
    <el-table v-loading="tableData.loading" :data="tableData.data" height="100%">
      <el-table-column :fixed="item.fixed" v-for="(item,i) in tableData.column" :label="item.label" :prop="item.key"
                       :min-width="item.minWidth" :width="item.width" :key="`table_key_${i}`" align="center" show-overflow-tooltip>
        <template slot-scope="scope">

          <div v-if="item.key === 'opt'">
            <el-button
                    size="mini" v-for="(it,k) in scope.row.opt"
                    type="text"
                    :icon="it.icon"
                    v-show="!!it.label"
                    @click="tableCellEvt(it.label, scope.row)"
                    :key="`opt_${i}_${k}`">
            </el-button>
          </div>
          <span v-else class="common-table-cell">{{scope.row[item.key]}}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 导出/分页 -->
    <!-- <el-button slot="footer" type="primary" icon="el-icon-download" size="small">导出</el-button> -->
    <el-pagination @size-change="pagingEvent($event, 'size')" @current-change="pagingEvent($event, 'current')"
                   :current-page="pagingData.current" :page-sizes="pagingData.sizes" :page-size="pagingData.size"
                   :total="pagingData.total" slot="footer" layout="total, sizes, prev, pager, next, jumper"></el-pagination>
  </list-layout>
</template>

<script>
  import ListLayout from "@/pages/layout/ListLayout";
  import BaseView from "@/pages/BaseView";
  import {deleteRequestMethod, getRequestMethod, postRequestMethod} from "@/api/common";

  export default {
    extends: BaseView,
    components: { ListLayout },
    props: {
      breadList: {
        type: Array,
        default: () => []
      }
    },
    data () {
      return {
        contractList: [],
        type: [],
        billingCycle: [],
        queryData: {
          sn: null,
          contractName: null,
          type: null
        },
      }
    },
    methods: {
      add(){
        this.$router.push({ path: '/contract/contractFlowInAdd'});
      },
      pageEvent () {
        if (this.tableData.loading) return;
        this.pagingData.current = 1;
        this.getTableData();
      },
      async getTableData () {
        this.tableData.loading = true;
        let result = await getRequestMethod('INCOME_INFO_PAGE', Object.assign(this.queryData, {
          pageSize: this.pagingData.size,
          pageNum: this.pagingData.current}
        ));

        if (!!result && result.code === 'SUCCESS') {
          this.tableData.data = result.data.dataList;
          this.pagingData.total = result.data.totalNum;
          this.tableData.loading = false;
          this.dealData();
        } else {
          this.$message.error(!!result ? result.mess : '接口异常');
          this.tableData.show = false;
        }
      },
      dealData () {
        this.tableData.data.map((item, k) => {
          item.index = k + 1;
          item.opt = [{label:'详情',icon:'el-icon-document'},{label:'编辑',icon:'el-icon-edit'},{label:'删除',icon:'el-icon-delete'}];
        })
      },
      tableCellEvt (type,row) {
        switch (type) {
          case '详情':
            this.$router.push({ path: '/contract/contractFlowInDetail', query: { id: row.id } });
            break;
          case '编辑':
            this.$router.push({ path: '/contract/contractFlowInEdit', query: { id: row.id } });
            break;
          case '删除':
            this.delete(row);
            break;
        }
        sessionStorage.setItem(this.cacheKey, JSON.stringify({ ...this.queryData, pageTotal: this.pagingData.total }));
      },
      delete(row){
        this.$confirm(`确认提交删除操作?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.deleteOne(row.id);
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消'
          });
        });
      },
      async deleteOne(id){
        this.tableData.loading = true;
        let result = await deleteRequestMethod('INCOME_INFO_DELETE', {id: id});
        this.tableData.loading = false;
        if (!!result && result.code === 'SUCCESS') {
          this.$router.go(0);
        } else {
          this.$message.error(!!result ? result.message:'接口异常');
        }
      },
      async getEnums(key,value){
        let result = await getRequestMethod("MENU_LIST", {key: value});
        if(!!result && result.code==='SUCCESS'){
          this[key] = result.data;
        } else {
          this.$message.error(!!result.message ? result.message:'接口异常');
        }
      },
      async  getContractList() {
        this.pageLoading = true;
        let result = await getRequestMethod('QUERY_CONTRACT_LIST');
        this.pageLoading = false;
        if (!!result && result.code === 'SUCCESS') {
          this.contractList  = result.data;
        } else {
          this.$message.error(!!result ? result.message:'接口异常');
        }
      },
    },

    mounted () {
      /* 如果 exportData 存在数据需要对页面参数进行回填，主要判断是否有分页参数 */
      if (!!this.exportData.pageSize) {
        // this.queryData.subject = this.exportData.subject;
        // this.queryData.gbB = this.exportData.gbB;
        // this.queryData.gbE = this.exportData.gbE;
        // this.publishTime.push(this.exportData.gbB);
        // this.publishTime.push(this.exportData.gbE);
      }
      /* 初始化页面表格列属性数据 */
      this.tableData.column = [
        { label: '合同名称', key: 'contractName',fixed:false, width: 200 },
        { label: '收入类型', key: 'type',fixed:false, width: 120 },
        { label: '出账周期', key: 'billingCycle', fixed:false,width: 120 },
        { label: '预计出账起始日期', key: 'firstBillDate',fixed:false, width: 160 },
        { label: 'IT收入金额（元）', key: 'itIncome', fixed:false,minWidth: 160 },
        { label: 'CT收入金额（元）', key: 'ctIncome',fixed:false, minWidth: 160 },
        { label: '备注', key: 'remark', fixed:false,minWidth: 200 },
        { label: '操作', key: 'opt', fixed:'right',width: 120 }
      ];
      /* 查询表格数据 */
      this.getTableData();
      this.getContractList();
      this.getEnums("type",'收入类型');
      this.getEnums("billingCycle",'出账周期');
      this.$root.eventBus.$emit('orderChange', this.breadList);

    }
  }
</script>