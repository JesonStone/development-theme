/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <list-layout :breadcrumb-list="breadList">
    <!-- 查询form表单 -->
    <el-form slot="header" inline :model="queryData" size="small" label-position="left">
      <el-form-item label="合同编号:">
        <el-input v-model="queryData.sn" size="small" placeholder="请输入"></el-input>
      </el-form-item>
      <el-form-item label="合同名称:">
        <el-input v-model="queryData.contractName" size="small" placeholder="请输入"></el-input>
      </el-form-item>
        <el-form-item label="合同类型:">
         <el-select v-model="queryData.type"    placeholder="请选择">
                        <el-option                       
                        v-for="(item,k) in contractTypes"
                        :key="`key_${k}`"
                        :label="item.label"
                        :value="item.value"
                        ></el-option>
                </el-select> 
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small" @click="pageEvent">查询</el-button>
      </el-form-item>
       <el-button @click="add()" size="small" type="primary">
            增加           
        </el-button>      
    </el-form>
    <!-- 正文表格 -->
    <el-table v-loading="tableData.loading" :data="tableData.data" height="100%">
      <el-table-column v-for="(item,i) in tableData.column" :label="item.label" :prop="item.key"
        :min-width="item.minWidth" :width="item.width" :key="`table_key_${i}`" align="center" show-overflow-tooltip>
        <template slot-scope="scope">
          <div v-if="item.key === 'state'">
            <el-button type="text" size="mini" icon="el-icon-tickets" @click="tableCellEvt(scope.row)"></el-button>
            <el-button type="text" v-if="scope.row.edite" size="mini" icon="el-icon-edit" @click="tableCellEdite(scope.row)"></el-button>          
          </div>
          <span v-else class="common-table-cell">{{scope.row[item.key]}}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 导出/分页 -->
    <!-- <el-button slot="footer" type="primary" icon="el-icon-download" size="small">导出</el-button> -->
    <el-pagination @size-change="pagingEvent($event, 'size')" @current-change="pagingEvent($event, 'current')"
      :current-page="pagingData.current" :page-sizes="pagingData.sizes" :page-size="pagingData.size"
      :total="pagingData.total" slot="footer" layout="total, sizes, prev, pager, next, jumper"></el-pagination>
  </list-layout>
</template>

<script>
import ListLayout from "@/pages/layout/ListLayout";
import BaseView from "@/pages/BaseView";
import { getRequestMethod, postRequestMethod } from "@/api/common";

export default {
    extends: BaseView,
    components: { ListLayout },
    props: {
        breadList: {
        type: Array,
        default: () => []
        }
    },
    data () {
        return {
            publishTime: [],
            queryData: {
                sn: '',
                contractName: '',
                type: ''
            },
            contractTypes:[
                {label:"支出类",value:'支出类'},
                {label:"收入类",value:'收入类'}
            ]
        }
    },
    watch: {
        publishTime: function (val) {
            if (!val) {
                this.queryData.gbB = '';
                this.queryData.gbE = '';
            } else {
                this.queryData.gbB = val[0] || '';
                this.queryData.gbE = val[1] || '';
            }
        }
    },
    methods: {
            add(){
                this.$router.push({ path: '/contract/contractAdd'});
            },
            pageEvent () {
                if (this.tableData.loading) return;
                this.pagingData.current = 1;
                this.getTableData();
            },
            async getTableData () {
                this.tableData.loading = true;
                let result = await getRequestMethod('QUERY_CONTRACT_PAGE', Object.assign(this.queryData, {
                    pageSize: this.pagingData.size,
                    pageNum: this.pagingData.current}
                ));

                if (!!result && result.code === 'SUCCESS') {                    
                    this.tableData.data = result.data.dataList;
                    this.pagingData.total = result.data.totalNum;
                    this.tableData.loading = false;                    
                    this.dealData();
                } else {
                    this.$message.error(!!result ? result.message : '接口异常');
                    this.tableData.show = false;
                }
            },
            dealData () {
                this.tableData.data.map((item, k) => {
                    if(item.createUser===this.$store.getters.getLoginUserInfo.userInfo.loginName){                    
                        item.edite=true;
                    }
                    item.index = k + 1;
                    item.opt = ['详情'];
                })
            },
            tableCellEvt (row) {                
                sessionStorage.setItem(this.cacheKey, JSON.stringify({ ...this.queryData, pageTotal: this.pagingData.total }));
                this.$router.push({ path: '/contract/contractDetail', query: { id: row.id } })
            },
            tableCellEdite(row){
                sessionStorage.setItem(this.cacheKey, JSON.stringify({ ...this.queryData, pageTotal: this.pagingData.total }));
                this.$router.push({ path: '/contract/contractUpdate', query: { id: row.id } })
            }
        },
    mounted () {
        
        /* 如果 exportData 存在数据需要对页面参数进行回填，主要判断是否有分页参数 */
        if (!!this.exportData.pageSize) {
        this.queryData.subject = this.exportData.subject;
        this.queryData.gbB = this.exportData.gbB;
        this.queryData.gbE = this.exportData.gbE;
        this.publishTime.push(this.exportData.gbB);
        this.publishTime.push(this.exportData.gbE);
        }

        /* 初始化页面表格列属性数据 */
        this.tableData.column = [
            { label: '合同编号', key: 'sn', width: 200 },
            { label: '合同名称', key: 'contractName', width: 220 },
            { label: '合同类型', key: 'type', width: 180 },
            { label: '中标时间', key: 'bidTime', width: 180 },
            { label: '合同额-含税（元）', key: 'amount', minWidth: 200 },
            { label: '预计签约当年可纳收金额（元）', key: 'firstYearIncome', minWidth: 250 },
            { label: '合同期（月）', key: 'duration', minWidth: 200 },
            { label: '履行开始时间', key: 'startDate', minWidth: 200 },
            { label: '履行结束时间', key: 'endDate', minWidth: 200 },
            { label: '甲方名称', key: 'partA', minWidth: 200 },
            { label: '乙方名称', key: 'partB', minWidth: 200 },
            { label: '审批完毕时间', key: 'reviewCompleteDate', minWidth: 200 },
            { label: '备注说明', key: 'remark', minWidth: 200 },
            { label: '操作', key: 'state', width: 100 }        
        ];

        /* 查询表格数据 */
        this.getTableData();
        
        this.$root.eventBus.$emit('orderChange', this.breadList);

    }
}
</script>