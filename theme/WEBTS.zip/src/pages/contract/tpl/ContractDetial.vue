<!--
 * @Descripttion: 任务管理
 * @Author: zhixiang-bai
 * @Date: 2020-01-07 11:43:18
 -->

<template>
    <detail-layout v-loading="pageLoading">
        <div class="commone-detail-layout">
            <div class="main">
                <div class="box-detail">
                    <div class="title">项目信息</div>
                    <div class="box-content">
                        <div v-for="(item,k) in baseObj" :key="`key_${k}`" :class="item.clx">
                            <div  class="label">{{item.label}}</div>
                            <div  class="text2">{{item.value}}</div>
                        </div>
                    </div>
                </div>
                <div class="box-detail">
                    <div class="title">合同信息</div>
                    <div class="box-content">
                        <div v-for="(item,k) in moneyObj" :key="`key_${k}`" :class="item.clx">
                            <div class="label">{{item.label}}</div>
                            <div class="text2">{{item.value}}</div>
                        </div>
                    </div>
                </div>                            
            </div>
            <div class="footer">
                <el-button  @click="$router.go(-1)" size="small">返回</el-button>
            </div>
        </div>
    </detail-layout>
</template>

<script>
    import DetailLayout from "@/pages/layout/DetailLayout";
    import {getFullUrl, getRequestMethod} from "@/api/common";
    import Tool from "@/util/tool";
    import {mapGetters} from 'vuex';

    export default {
        components: { DetailLayout },
        props: {
            breadList: {
                type: Array,
                default: () => []
            }
        },
        computed:{
            ...mapGetters({
                userInfo:'getUserInfo'
            })
        },
        data() {
            return {
                pageLoading: false,
                sn: '',
                baseObj: [
                    {label:'项目名称:',clx:'item w2', key:'pName', value:''},
                    {label:'项目编号:',clx:'item w2', key:'projectSn', value:''},                    
                    {label:'年份:',clx:'item w2', key:'projectYear', value:''},
                    {label:'建设单位:',clx:'item w2', key:'cUnit', value:''},
                    {label:'归属县区:',clx:'item w2', key:'region', value:''},
                    {label:'行业属性:',clx:'item w2', key:'industry', value:''},                   
                ],
                moneyObj:[
                    {label:'合同编号:',clx:'item w2', key:'sn', value:''},
                    {label:'合同名称:',clx:'item w2', key:'contractName', value:''},
                    {label:'合同类型:',clx:'item w2', key:'type', value:''},
                    {label:'中标时间:',clx:'item w2', key:'bidTime', value:''},
                    {label:'合同额-含税(元):',clx:'item w2', key:'amount', value:''},
                    {label:'预计签约当年可纳收金额(元):',clx:'item w2', key:'firstYearIncome', value:''},
                    {label:'合同期(月):',clx:'item w2', key:'duration', value:''},
                    {label:'履行开始时间:',clx:'item w2', key:'startDate', value:''},
                    {label:'履行结束时间:',clx:'item w2', key:'endDate', value:''},
                    {label:'甲方名称:',clx:'item w2', key:'partA', value:''},
                    {label:'乙方名称:',clx:'item w2', key:'partB', value:''},
                    {label:'审批完毕时间:',clx:'item w2', key:'reviewCompleteDate', value:''},
                    {label:'备注说明:',clx:'item w2', key:'remark', value:''}                 
                ]
            }
        },
        methods: {
            async getDetailInfo() {
                this.pageLoading = true;
                let result = await getRequestMethod('CONTRACT_DETAIL', {id: this.id});
                this.pageLoading = false;

                if (!!result && result.code === 'SUCCESS') {                                        
                    let data = result.data;
                    this.projectInfo(data.projectInfo);
                    this.contractInfo(data);                    
                } else {
                    this.$message.error(!!result? result.message:'接口异常');
                }
            },
            projectInfo(data){                
                this.baseObj.map( oo => {
                    oo.value = data[oo.key];
                });              
            }, 
            contractInfo(data){                
                this.moneyObj.map( oo => {
                    oo.value = data[oo.key];
                });              
            },           
        },
        created() {
            this.id = this.$route.query.id;
            if (!this.id) {
                this.$message.error('非法进入页面，请重新进入');
            } else {
                this.getDetailInfo();
            }
        },
        mounted(){
            this.$root.eventBus.$emit('orderChange', this.breadList);
        }
    }
</script>

<style lang="less" scoped>
</style>