/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31  合同收入
*********************************************************************/

<template>
  <detail-layout v-loading="pageLoading" :breadcrumb-list="breadList">
    <div class="common-form-container full">
      <article>
        <el-form
                ref="submitForm"
                :model="pageData"
                label-position="top"
                size="medium"
        >
          <el-row style="margin-top:20px;margin-bottom: 20px;">
            <span>合同信息</span>
          </el-row>
          <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label="合同名称" prop="contract" :rules="rules['contract']">
                <el-select  @change="setSecond" v-model="pageData.contract"  value-key="id" size="small" placeholder="请选择合同名称" >
                  <el-option v-for="(item,k) in contractList" :key="`${item.id}`" :label="item.contractName"
                             :value="item"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="合同编号" prop="sn" :rules="rules['sn']">
                <el-input v-model="pageData.sn" readonly placeholder="请填写合同编号"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="合同额-含税（元）" prop="amount" :rules="rules['amount']">
                <el-input v-model="pageData.amount" readonly placeholder="请填写合同额-含税（元）"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="预计签约当年可纳收金额（元）" prop="firstYearIncome" :rules="rules['firstYearIncome']">
                <el-input v-model="pageData.firstYearIncome"  readonly placeholder="请填写预计签约当年可纳收金额（元）"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="对应收入" prop="count" :rules="rules['count']">
                <el-input   v-model="pageData.count"  readonly placeholder="请填写对应收入"></el-input>
              </el-form-item>
            </el-col>
          </el-row>


          <el-row style="margin-top:20px;margin-bottom: 20px;">
            <span>收入明细</span>
          </el-row>
          <el-row :gutter="16" v-for="(item,k) in pageData.incomeInfo" :key="`icome_${k}`">
            <el-col :span="8">
              <el-form-item label="序号" >
                <el-input :value="k+1" readonly placeholder="请填写序号"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="收入类型"  :prop="`incomeInfo[${k}].type`" :rules="rules['type']">
                <el-select  @change="setcount" v-model="item.type" size="small" placeholder="请选择收入类型">
                  <el-option v-for="(item,k) in type" :key="`pname_${k}`" :label="item.value" :value="item.value"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="预计出账起始日期" :prop="`incomeInfo[${k}].firstBillDate`" :rules="rules['firstBillDate']">
                <el-date-picker
                        v-model="item.firstBillDate"
                        type="month"
                        value-format="yyyy-MM"
                        placeholder="请选择预计出账起始日期"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="出账周期" :prop="`incomeInfo[${k}].billingCycle`" :rules="rules['billingCycle']" >
                <el-select v-model="item.billingCycle" size="small"  placeholder="请选择出账周期">
                  <el-option v-for="(item,k) in billingCycle" :key="`pname_${k}`" :label="item.value" :value="item.value"></el-option>
                </el-select>
              </el-form-item>
            </el-col>

            <el-col :span="8">
              <el-form-item label="IT收入金额（元）" :prop="`incomeInfo[${k}].itIncome`" :rules="rules['itIncome']" >
                <el-input v-model="item.itIncome"   @keyup.native = "clearNoNum(item,'itIncome')" placeholder="请填写IT收入金额（元）"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="CT收入金额（元）" :prop="`incomeInfo[${k}].ctIncome`" :rules="rules['ctIncome']">
                <el-input v-model="item.ctIncome" @keyup.native = "clearNoNum(item,'ctIncome')" placeholder="请填写CT收入金额（元）"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="备注说明" :prop="`incomeInfo[${k}].remark`" :rules="pageData.incomeInfo[k].type === '其它收入'? rules['remarkTrue']:rules['remarkFalse']">
                <el-input v-model="item.remark" placeholder="请填写备注说明"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </article>
      <footer>
        <el-button size="small" @click="submitEvent" type="primary">提&nbsp;&nbsp;交</el-button>
        <el-button @click="$router.go(-1)" size="small" plain>取消</el-button>
      </footer>
    </div>
  </detail-layout>
</template>

<script>
  import DetailLayout from "@/pages/layout/DetailLayout";
  import {getRequestMethod, postRequestMethod, postNewRequestMethod, putRequestMethod} from "@/api/common";
  import Tool from "@/util/tool";
  import { mapGetters } from "vuex";

  export default {
    components: { DetailLayout },
    props: {
      breadList: {
        type: Array,
        default: () => []
      }
    },
    computed: {
      ...mapGetters({
        userInfo: 'getUserInfo'
      }),
    },
    data () {
      let validater = (rules, value, callback) => {

        if (this.pageData.count  <= this.pageData.amount) {
          callback();
        } else {
          callback(new Error('对应收入不能大于合同额-含税'));
        }
      };
      return {
        pageLoading: false,
        contractList: [],
        type: [],
        billingCycle: [],
        id: '',
        pageData: {
          contract:  '',
          cid: '',
          sn: '',
          amount: '',
          firstYearIncome: '',
          count: 0,
          incomeInfo:[{
            billingCycle: '',
            cid: '',
            type: '',
            ctIncome: '',
            firstBillDate: '',
            itIncome: '',
            remark: '',
            id: ''
          }]
        },
        rules: {
          contract: [{ required: true, message: '请选择合同名称', trigger: 'change' }],
          sn: [{ required: true, message: '请填写合同编号', trigger: 'change' }],
          amount: [{ required: true, message: '请填写合同额-含税（元）', trigger: 'change' }],
          firstYearIncome: [{ required: true, message: '请填写预计签约当年可纳收金额（元）', trigger: 'change' }],
          count: [{ required: true, message: '请填写对应收入', trigger: 'change' },{validator: validater, trigger:['change'] }],

          type: [{ required: true, message: '请选择收入类型', trigger: 'change' }],
          firstBillDate: [{ required: true, message: '请选择预计出账起始日期', trigger: 'change' }],
          billingCycle: [{ required: true, message: '请选择出账周期', trigger: 'change' }],
          itIncome: [{ required: true, message: '请填写IT收入金额（元）', trigger: 'blur' }],
          ctIncome: [{ required: true, message: '请填写CT收入金额（元）', trigger: 'blur' }],
          remarkFalse: [{ required: false, message: '请填写备注说明', trigger: 'blur' }],
          remarkTrue: [{ required: true, message: '请填写备注说明', trigger: 'blur' }],
        },
      }
    },
    methods: {
      setcount() {
        //计算总成本 设备销售/租赁收入 除外
        let count = 0;
        this.pageData.incomeInfo.forEach(oo=>{
          if (!!oo.type && oo.type !== '设备销售/租赁收入') {
            let ctIncome = parseInt(oo.ctIncome);
            let itIncome = parseInt(oo.itIncome);
            if (!isNaN(ctIncome)) {
              count = count + ctIncome;
            }
            if (!isNaN(itIncome )) {
              count = count + itIncome;
            }
          }
        });
        this.pageData.count = count;
      },
      clearNoNum(item,key) {
        item[key] =  item[key].replace(/[^\d]/g, ""); //清除"数字"以外的字符;
        this.setcount();
      },
      setSecond(value) {
        this.pageData.cid  = value.id;
        this.pageData.sn  = value.sn;
        this.pageData.amount  = value.amount;
        this.pageData.firstYearIncome  = value.firstYearIncome;
      },
      async  getContractList() {
        this.pageLoading = true;
        let result = await getRequestMethod('QUERY_CONTRACT_LIST');
        this.pageLoading = false;
        if (!!result && result.code === 'SUCCESS') {
          this.contractList  = result.data;
        } else {
          this.$message.error(!!result ? result.message:'接口异常');
        }
      },
      submitEvent () {
        this.$refs.submitForm.validate(valid => {
          if (valid) {
            this.submitFunc();
          } else {
            return 0;
          }
        });
      },
      async submitFunc () {
        //重新构造参数
        let incomeInfoElement = this.pageData.incomeInfo[0];
        let submit = {
            cid: this.pageData.cid,
            id: incomeInfoElement.id,
            ctIncome: incomeInfoElement.ctIncome,
            billingCycle: incomeInfoElement.billingCycle,
            firstBillDate: incomeInfoElement.firstBillDate,
            itIncome: incomeInfoElement.itIncome,
            remark: incomeInfoElement.remark,
            type: incomeInfoElement.type,
          };
        this.pageLoading = true;
        let result = await putRequestMethod('INCOME_INFO_UPDATE', submit);
        this.pageLoading = false;
        if (!!result && result.code === 'SUCCESS') {
          this.$router.go(-1);
        } else {
          this.$message.error(!!result ? result.message : '接口异常');
        }
      },
      async getEnums(key,value){
        let result = await getRequestMethod("MENU_LIST", {key: value});
        if(!!result && result.code==='SUCCESS'){
          this[key] = result.data;
        } else {
          this.$message.error(!!result.message ? result.message:'接口异常');
        }
      },
      async getDetailInfo() {
        this.pageLoading = true;
        let result = await getRequestMethod('INCOME_INFO_DETAIL', {id: this.id});
        this.pageLoading = false;

        if (!!result && result.code === 'SUCCESS') {
          let data = result.data;
          this.pageData.incomeInfo[0].id = data.id;
          this.pageData.incomeInfo[0].cid = data.cid;
          this.pageData.incomeInfo[0].type = data.type;
          this.pageData.incomeInfo[0].ctIncome = data.ctIncome;
          this.pageData.incomeInfo[0].firstBillDate = data.firstBillDate;
          this.pageData.incomeInfo[0].itIncome = data.itIncome;
          this.pageData.incomeInfo[0].remark = data.remark;
          this.pageData.incomeInfo[0].billingCycle = data.billingCycle;
          if (!!data.cid) {
            this.getContract(data.cid);
          }
        } else {
          this.$message.error(!!result? result.message:'接口异常');
        }
      },
      async getContract(cid) {
        this.pageLoading = true;
        let result = await getRequestMethod('QUERY_CONTRACT_LIST',{id:cid});
        this.pageLoading = false;
        if (!!result && result.code === 'SUCCESS' && !!result.data  &&  result.data.length === 1) {
          this.pageData.contract = result.data[0];
          this.setSecond(result.data[0]);
          this.setcount();
        } else {
          this.$message.error('查询合同信息异常');
        }
      },
    },
    created () {
      this.id = this.$route.query.id;
      if (!this.id) {
        this.$message.error('非法进入页面，请重新进入');
      } else {
        this.getDetailInfo();
        this.getContractList();
        this.getEnums("type",'收入类型');
        this.getEnums("billingCycle",'出账周期');
      }
    },
    mounted () {
      this.$root.eventBus.$emit('orderChange', this.breadList);
    }
  }
</script>

<style lang="less" scoped>
  .flow-height {
    height: 130px !important;
  }
</style>