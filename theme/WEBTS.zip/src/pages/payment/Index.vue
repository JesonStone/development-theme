<!--
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-19 11:17:57
 -->

<template>
    <router-view :breadList="breadList"></router-view>
</template>

<script>
    export default {
        data() {
            return {
                breadcrumbList: {
                    "_payment_list": [{path: '', name: '供应商付款'}, {path: '', name: '列表'}],                  
                    "_payment_detail": [{path: '', name: '供应商付款'}, {path: '', name: '详情'}],                  
                    "_payment_add": [{path: '', name: '供应商付款'}, {path: '', name: '新增'}], 
                    "_payment_edit": [{path: '', name: '供应商付款'}, {path: '', name: '编辑'}]                
                },
                breadList: []
            }
        },
        watch: {
            "$route.path": function(val) {
                this.assembleBreadcrumb(val);
            }
        },
        methods: {
            assembleBreadcrumb(path) {
                if (path !== '') path = path.replace(/\//g, '_');
                this.breadList = JSON.parse(JSON.stringify(this.breadcrumbList[path] || []));
            }
        },
        created() {

            sessionStorage.removeItem('page_list_params_cache');

            this.assembleBreadcrumb(this.$route.path);
        }
    }
</script>