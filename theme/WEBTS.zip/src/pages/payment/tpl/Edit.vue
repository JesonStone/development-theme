/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <detail-layout v-loading="pageLoading" :breadcrumb-list="breadList">
    <div class="common-form-container full">
      <article>
        <el-form ref="submitForm" :model="pageData" :rules="rules" label-position="top" size="medium">
            <el-row style="margin-top:20px;margin-bottom: 20px;"><span>项目信息</span></el-row>
          <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label="项目名称" prop="pName" size="small">
                <el-select v-model="pageData.pName" size="small">
                    <el-option v-for="(item,k) in projects" :key="`pname_${k}`" :label="item.name" :value="item.name"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目编号" size="small">
                <el-input v-model="pageData.projectSn" size="small"></el-input>
              </el-form-item>
            </el-col>
             <el-col :span="8">
              <el-form-item label="资金支出类型"  size="small">
                  <el-input v-model="pageData.disburseType" size="small"></el-input>
              </el-form-item>
            </el-col>
             <el-col :span="8">
              <el-form-item label="年份"><el-input v-model="pageData.projectYear" size="small"></el-input></el-form-item>
            </el-col>
            <el-col :span="8">
                <el-form-item label="建设单位"><el-input v-model="pageData.payee" size="small"></el-input></el-form-item>
            </el-col>                      
            <el-col :span="8">
                <el-form-item label="归属县区"><el-input v-model="pageData.region" size="small"></el-input></el-form-item>
            </el-col>            
            <el-col :span="8">
                <el-form-item label="行业属性"><el-input v-model="pageData.industry" size="small"></el-input></el-form-item>
            </el-col>
            <el-col :span="8">
                <el-form-item label="项目类型"><el-input v-model="pageData.projectType" size="small"></el-input></el-form-item>
            </el-col>
          </el-row>
           <el-row style="margin-top:20px;margin-bottom: 20px;"><span>项目金额</span></el-row>
            <el-row :gutter="16">
                <el-col :span="8">
                    <el-form-item label="最近一次收款时间" prop="title">
                        <el-input v-model="pageData.lastPayDate" size="small"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="所需收入总金额" prop="title">
                        <el-input v-model="pageData.totalAmount" size="small"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="累计收入进度（%）" prop="title">
                        <el-input v-model="pageData.payRate" size="small"></el-input>
                    </el-form-item>
                </el-col>
            </el-row>
           <el-row style="margin-top:20px;margin-bottom: 20px;">
               <span>出账明细</span>
               <el-button type="text" class="el-icon-circle-plus" @click="addOne"></el-button>
            </el-row>
            <el-row :gutter="16" v-for="(item,k) in icomeDetails" :key="`icome_${k}`">
                <div class="">
                    <el-col :span="8">
                        <el-form-item label="合同名称" prop="name">
                            <el-input v-model="item.name" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="收入类型" prop="icomeType">
                            <el-select v-model="item.icomeType" size="small">
                                <el-option v-for="(item,k) in icomeTypes" :key="`pname_${k}`" :label="item.value" :value="item.value"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="IT收入金额（元）" prop="ITIcomeCount">
                            <el-input v-model="item.ITIcomeCount" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="CT收入金额（元）" prop="CTIcomeCount">
                            <el-input v-model="item.CTIcomeCount" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="到账时间" prop="time">
                            <el-input v-model="item.time" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="到账凭证" prop="evidence">
                            <el-input v-model="item.evidence" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="24">
                        <el-form-item label="备注" prop="dis">
                            <el-input type="textarea" rows="3" v-model="item.dis"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="24">
                        <el-button type="text" style="color:#f40;" @click="deleteOne(k)">删除此明细</el-button>
                        <div style="height:0;border-bottom:1px solid #a9b7da;margin-bottom: 10px;"></div>
                    </el-col>
                </div>
            </el-row>
        </el-form>
      </article>
      <footer>
        <el-button size="small" @click="submitEvent" type="primary">提&nbsp;&nbsp;交</el-button>
        <el-button @click="$router.go(-1)" size="small" plain>取消</el-button>
      </footer>
    </div>
  </detail-layout>
</template>

<script>
import DetailLayout from "@/pages/layout/DetailLayout";
import { getRequestMethod, postRequestMethod, postNewRequestMethod } from "@/api/common";
import Tool from "@/util/tool";
import { mapGetters } from "vuex";

export default {
  components: { DetailLayout },
  props: {
    breadList: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    ...mapGetters({
    //   userInfo: 'getLoginUserInfo'
    })
  },
  data () {
        return {
            pageLoading:false,
            projects:[],
            icomeTypes:[],

            icomeDetails:[
                {name:'',icomeType:'', ITIcomeCount:'', CTIcomeCount:'', time:'', evidence:'', dis:''}
            ],
            pageData: {
            },
            rules: {
                industry: [{ required: true, message: '项目命题不能为空', trigger: 'blur' }]
            },
        }
    },
    methods: {
        submitEvent () {
            this.$refs.submitForm.validate(valid => {
                if (valid) {
                    this.submitFunc();
                } else {
                    return 0;
                }
            });
        },
        async submitFunc () {            
            let result = await postRequestMethod('ANNUAL_PLAN_MODIFY', this.pageData);
            if (!!result && result.code === 'success') {
                this.$router.go(-1);
            } else {
                this.$message.error(!!result ? result.message : '接口异常');
            }
        },


        async getIcomeTypes(){
            let result = await getRequestMethod('MENU_LIST',{key:'收入类型'});
            if(!!result && result.code==='SUCCESS'){                        
                this.icomeTypes=result.data;
            } else {
                this.$message.error(!!result.message ? result.message:'接口异常');
            }
        },
        addOne(){
            this.icomeDetails.push({name:'',icomeType:'', ITIcomeCount:'', CTIcomeCount:'', time:'', evidence:'', dis:''});
        },
        deleteOne(index){
            this.icomeDetails.length <= 1 ? this.$message.warning('请至少添加一条明细') : this.icomeDetails.splice(index,1);
        }

    },
    created () {
        this.getIcomeTypes();
    },
    mounted () {   
        this.pageData = JSON.parse(sessionStorage.getItem('edit_row'));
        sessionStorage.removeItem('edit_row')
        let contractDetail = this.icomeDetails[0];
        contractDetail.name = this.pageData.contractName;
        contractDetail.icomeType = this.pageData.disburseType;
        
        console.log(this.pageData)
        this.$root.eventBus.$emit('orderChange', this.breadList);
    }
}
</script>

<style lang="less" scoped>
</style>