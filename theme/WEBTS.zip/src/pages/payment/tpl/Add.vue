/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
  <detail-layout v-loading="pageLoading" :breadcrumb-list="breadList">
    <div class="common-form-container full">
      <article>
        <el-form ref="submitForm" :model="pageData" :rules="rules" label-position="top" size="medium">
            <el-row style="margin-top:20px;margin-bottom: 20px;"><span>项目信息</span></el-row>
          <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label="项目名称" prop="projectName" size="small">
                <el-select v-model="selectedProject" value-key="pName" size="small">
                    <el-option v-for="(item,k) in projects" :key="`pname_${k}`" :label="item.pName" :value="item"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="合同名称" prop="projectName" size="small">
                <!-- <el-select v-model="selectedProject" value-key="pName" size="small">
                    <el-option v-for="(item,k) in projects" :key="`pname_${k}`" :label="item.contractName" :value="item"></el-option>
                </el-select> -->
                <el-input v-model="pageData.contractName" size="small"></el-input>
              </el-form-item>
            </el-col>

            <el-col :span="8">
              <el-form-item label="项目编号" prop="projectName" size="small">
                <el-input v-model="pageData.projectSn" size="small"></el-input>
              </el-form-item>
            </el-col>
             <el-col :span="8">
              <el-form-item label="资金支出类型"  size="small">
                  <el-input v-model="pageData.disburseType" size="small"></el-input>
              </el-form-item>
            </el-col>

             <el-col :span="8">
              <el-form-item label="年份"><el-input v-model="pageData.projectYear" size="small"></el-input></el-form-item>
            </el-col>
            <el-col :span="8">
                <el-form-item label="建设单位"><el-input v-model="pageData.payee" size="small"></el-input></el-form-item>
            </el-col>                      
            <el-col :span="8">
                <el-form-item label="归属县区"><el-input v-model="pageData.region" size="small"></el-input></el-form-item>
            </el-col>            
            <el-col :span="8">
                <el-form-item label="行业属性"><el-input v-model="pageData.industry" size="small"></el-input></el-form-item>
            </el-col>
            <el-col :span="8">
                <el-form-item label="项目类型"><el-input v-model="pageData.projectType" size="small"></el-input></el-form-item>
            </el-col>
          </el-row>
           <el-row style="margin-top:20px;margin-bottom: 20px;"><span>付款信息</span></el-row>
            <el-row :gutter="16">
                <el-col :span="8">
                    <el-form-item label="供应商最近一次付款时间" prop="title">
                        <el-input v-model="pageData.lastPayDate" size="small"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="所需付款总金额（元）" prop="title">
                        <el-input v-model="pageData.totalAmount" size="small"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="供应商累计付款进度（%)" prop="title">
                        <el-input v-model="pageData.payRate" size="small"></el-input>
                    </el-form-item>
                </el-col>
            </el-row>
           <el-row style="margin-top:20px;margin-bottom: 20px;">
               <span>付款明细</span>
               <el-button type="text" class="el-icon-circle-plus" @click="addOne"></el-button>
            </el-row>
            <el-row :gutter="16" v-for="(item,k) in icomeDetails" :key="`icome_${k}`">
                <div class="">
                    <el-col :span="6">
                        <el-form-item label="合同名称" prop="name">
                            <el-input v-model="item.name" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="6">
                        <el-form-item label="收款单位" prop="name">
                            <el-input v-model="item.name" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="6">
                        <el-form-item label="支出类型" prop="icomeType">
                            <el-select v-model="item.icomeType" size="small">
                                <el-option v-for="(item,k) in icomeTypes" :key="`pname_${k}`" :label="item.value" :value="item.value"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="6">
                        <el-form-item label="成本IT采购金额（元）" prop="ITIcomeCount">
                            <el-input v-model="item.ITIcomeCount" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="6">
                        <el-form-item label="成本CT采购金额（元）" prop="CTIcomeCount">
                            <el-input v-model="item.CTIcomeCount" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="6">
                        <el-form-item label="资本IT采购金额（元）" prop="CTIcomeCount">
                            <el-input v-model="item.CTIcomeCount" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="6">
                        <el-form-item label="资本CT采购金额（元）" prop="CTIcomeCount">
                            <el-input v-model="item.CTIcomeCount" size="small"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="6">
                        <el-form-item label="付款时间" prop="time">
                            <el-date-picker
                                v-model="item.assessTime"
                                type="date"
                                value-format="yyyy-MM-dd"
                                placeholder="选择日期">
                            </el-date-picker>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="到账凭证" prop="fileName">
                            <el-input v-model="item.fileName" size="small">
                                <el-button style="color:#409EFF;" slot="append" @click="pickFileEvent(item)" icon="el-icon-upload" size="large"></el-button>
                            </el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="24">
                        <el-button type="text" style="color:#f40;" @click="deleteOne(k)">删除此明细</el-button>
                        <div style="height:0;border-bottom:1px solid #a9b7da;margin-bottom: 10px;"></div>
                    </el-col>
                </div>
            </el-row>
        </el-form>
      </article>
      <footer>
        <el-button size="small" @click="submitEvent" type="primary">提&nbsp;&nbsp;交</el-button>
        <el-button @click="$router.go(-1)" size="small" plain>取消</el-button>
      </footer>
    </div>
  </detail-layout>
</template>

<script>
import DetailLayout from "@/pages/layout/DetailLayout";
import { getRequestMethod, postRequestMethod, postNewRequestMethod } from "@/api/common";
import Tool from "@/util/tool";
import { mapGetters } from "vuex";

export default {
  components: { DetailLayout },
  props: {
    breadList: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    ...mapGetters({
    //   userInfo: 'getLoginUserInfo'
    })
  },
  data () {
        return {
            pageLoading:false,
            projects:[],
            selectedProject:{},
            icomeTypes:[],
            fileLoading:{
                load:'',
                info:''
            },
            icomeDetails:[
                {name:'',icomeType:'', ITIcomeCount:'', CTIcomeCount:'', time:'', evidence:'', dis:''}
            ],
            pageData: {
                projectName:'',  
                projectSN:'',  
                disburseType:'',  
                projectYear:'',  
                payee: '',
                cUnit:'',  
                region:'',  
                industry:'',  
                projectType:'',  
                contractName: '',
                payRate: null,
                lastPayDate: '',
                totalAmount: null
            },
            rules: {
                projectName: [{ required: true, message: '请选择项目名称', trigger: 'change' }]
            },
        }
    },
    watch:{
        selectedProject:function(value) {
            let project = value;
            this.pageData.projectYear = project.lastPayDate.split("-")[0]

            this.pageData.projectName = project.pName;
            this.pageData.projectSn = project.projectSn;
            this.pageData.disburseType = project.disburseType;
            // this.pageData.projectYear = project.projectYear;
            this.pageData.payee = project.payee;
            this.pageData.cUnit = project.cUnit;
            this.pageData.region = project.region;
            this.pageData.industry = project.industry;
            this.pageData.projectType = project.projectType;
            this.pageData.contractName = project.contractName;
            this.pageData.payRate = project.payRate;
            this.pageData.totalAmount = project.totalAmount;
            this.pageData.lastPayDate = project.lastPayDate;
        }
    },
    methods: {
        submitEvent () {
            this.$refs.submitForm.validate(valid => {
                if (valid) {
                    this.submitFunc();
                } else {
                    return 0;
                }
            });
        },
        async submitFunc () {            
            let result = await postRequestMethod('ANNUAL_PLAN_ADD', this.pageData);
            this.$message.info("添加成功！")
            if (!!result && result.code === 'success') {
                this.$router.go(-1);
                this.$message.info("添加成功！")
            } else {
                this.$message.error(!!result ? result.message : '接口异常');
            }
        },
        async getIcomeTypes(){
            let result = await getRequestMethod('MENU_LIST',{key:'支出类型'});
            if(!!result && result.code==='SUCCESS'){                        
                this.icomeTypes=result.data;
            } else {
                this.$message.error(!!result.message ? result.message:'接口异常');
            }
        },
        async getProjects(){
            let result = await getRequestMethod('ANNUAL_PLAN_DETAIL', {state: 2});
            if (!!result && result.code === 'SUCCESS') {
                this.projects = result.data;
            } else {
                this.$message.error(!!result ? result.message : '接口异常');
            }
        },
        pickFileEvent(item){
            Tool.fileUploadMethod(async files => {
                if (files[0].size > 1024 * 1024 * 300) {
                    this.$message.error('请上传小于300M的文件！');
                    return
                }
                if (files[0].name.length > 200) {
                    this.$message.error('文件名称不能大于200个字符！');
                    return
                }
                this.pageLoading = true;
                this.fileLoading.info = '文件开始上传';
                let str = `上传文件成功！`;
                /* 文件上传方法 */
                let result = await postRequestMethod('FILE_ADD', { 'file': files[0] }, progress => {
                    this.fileLoading.info = `文件上传中，已完成：${Math.floor((progress.loaded / progress.total) * 100)}%`;
                    if (progress.loaded / progress.total * 100 >= 100) {
                        this.fileLoading.info = `文件上传完成`;
                    }
                });
                this.pageLoading = false;
                if (!!result && result.code === 'SUCCESS') {
                    /* 附件回显 */
                    item.fileName = result.data.fileName;
                    item.filePath = result.data.filePath;
                    this.$notify.success({
                        title: '上传文件',
                        type: 'success',
                        message: str,
                        duration: 3000,
                        showClose: false
                    });
                } else {
                    this.$message.error(!!result ? result.message : '接口异常');
                }
            });
        },
        addOne(){
            this.icomeDetails.push({name:'',icomeType:'', ITIcomeCount:'', CTIcomeCount:'', time:'', fileName:'',filePath:'',});
        },
        deleteOne(index){
            if (this.icomeDetails.length <=1) {
                this.$message.warning('请至少添加一条明细');
            } else {
                this.icomeDetails.splice(index,1);
            }
        }

    },
    created () {
        this.getIcomeTypes();
        this.getProjects();
    },
    mounted () {   
        this.$root.eventBus.$emit('orderChange', this.breadList);
    }
}
</script>

<style lang="less" scoped>
</style>