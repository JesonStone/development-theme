/*
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-19 11:38:59
 */

/* 项目出账信息管理--列表 */
const PROJECT_STATISTICS_LIST = '';


export {
    PROJECT_STATISTICS_LIST,
}