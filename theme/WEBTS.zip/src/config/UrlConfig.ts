/*********************************************************************
 * ajax request url file
 * Created by deming-su on 2019/12/06
 *********************************************************************/
/* 主页路由引入 */
import * as HomeUrl from "./home.url.config";

/* 通用路由引入 */
import * as CommonUrl from "./common.url.config";

/* 项目路由引入 */
import * as ProjectUrl from './project.url.config';

/* 合同路由引入 */
import * as ContractUrl from './contract.url.config';

/* 枚举路由引入 */
import * as Menu from './menu.config';

/* 售中流程路由引入 */
// import * as Sale from './sale.url.config';

/* 项目出账信息 */
import * as projecBill from './projectBill.url.config';

/* 项目出账信息 */
import * as statistics from './projectStatistics.url.config';

/* 供应商付款信息 */
import * as paymentURL from './payment.url.config';


/* 页面启动路由，根据不同的环境启动不同的基础路由 */
let BASE_URL = window.BASE_SERVICE_URL;
let BASE_FILE = window.BASE_FILE_URL;

let PathUrlList: UrlKey[] = [],
    keys: any = {
        BASE_URL,
        BASE_FILE,
        ...HomeUrl,
        ...CommonUrl,
        ...ProjectUrl,
        ...ProjectUrl,
        ...Menu,
        ...projecBill,
        ...statistics,
        ...ContractUrl,
        // ...Sale,
        ...paymentURL,
    };

for (let name in keys) {
    if (keys.hasOwnProperty(name)) {
        PathUrlList.push({key: name, value: keys[name]});
    }
}

interface UrlKey {
    key: string;
    value: string;
}

class UrlConfig {
    private readonly nowKey: string;
    constructor(key: string = '') {
        this.nowKey = key;
    }
    public initBaseUrl(path: string) {
        PathUrlList.map((it: UrlKey) => {
            if (it.key === 'BASE_URL') it.value = path;
        });
    }
    get currentUrl(): string {
        let res: UrlKey = PathUrlList.find((it: UrlKey) => it.key === this.nowKey) || {key: '', value: ''};
        return res.value;
    }
}

/* 首页 ---end--- */
export default UrlConfig;