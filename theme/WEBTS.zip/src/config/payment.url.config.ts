/*
 * @Descripttion: 
 * @Author: jjchen-chen
 * @Date: 2020-03-23 16:43:00
 */

/* 供应商付款--列表 */
const ANNUAL_PLAN_LIST = '/apis/api/selManage/queryPaymentInfoList';

/* 供应商付款--详情 */
const ANNUAL_PLAN_DETAIL = '/apis/api/selManage/queryPaymentInfoList';

/* 供应商付款--修改 */
const ANNUAL_PLAN_MODIFY = '/apis/api/selManage/updatePaymentInfo';

/* 供应商付款--删除 */
const ANNUAL_PLAN_REMOVE = '/apis/api/selManage/removePlaymentInfo';

/* 供应商付款--添加 */
const ANNUAL_PLAN_ADD = '/apis/api/selManage/addPaymentInfo';




export {
    ANNUAL_PLAN_LIST,
    ANNUAL_PLAN_DETAIL,
    ANNUAL_PLAN_MODIFY,
    ANNUAL_PLAN_REMOVE,
    ANNUAL_PLAN_ADD
}