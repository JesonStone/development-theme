/*
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-20 18:14:17
 */

/*********************************************************************
* Interface page of recapping 
*********************************************************************/

/* 1、合同管理 新增 */
const ADD_CONTRACT = '/apis/api/contract/addContract';

/* 2、合同管理 列表分页 */ 
const QUERY_CONTRACT_PAGE='/apis/api/contract/queryContractPage';

/* 2、合同管理--全量列表 */ 
const QUERY_CONTRACT_LIST='/apis/api/contract/queryContractList';

/* 3、合同管理--详情*/ 
const  CONTRACT_DETAIL='/apis/api/contract/contractDetail';

/* 4、合同管理--修改*/ 
const  CONTRACT_UPDATE='/apis/api/contract/updateContract';


/*  合同管理 - 添加收入明细 -  新增 */
const INCOME_INFO_ADD = '/apis/api/contract/addIncomeInfo';

/*  合同管理 - 收入明细 -  列表分页 */
const INCOME_INFO_PAGE = '/apis/api/contract/queryIncomeInfoPage';

/*  合同管理 - 收入明细 -  删除 */
const INCOME_INFO_DELETE = '/apis/api/contract/deleteIncomeInfo';

/*  合同管理 - 收入明细 -  详情 */
const INCOME_INFO_DETAIL = '/apis/api/contract/queryIncomeInfoById';

/*  合同管理 - 收入明细 -  更新 */
const INCOME_INFO_UPDATE = '/apis//api/contract/updateIncomeInfo';


/*  合同管理 - 添加支出明细 -  新增 */
const DISBURSE_INFO_ADD = '/apis/api/contract/addDisburseInfo';

/*  合同管理 - 支出明细 -  列表分页 */
const DISBURSE_INFO_PAGE = '/apis/api/contract/queryDisburseInfoPage';

/*  合同管理 - 支出明细 -  删除 */
const DISBURSE_INFO_DELETE = '/apis/api/contract/deleteDisburseInfo';

/*  合同管理 - 支出明细 -  详情 */
const DISBURSE_INFO_DETAIL = '/apis/api/contract/queryDisburseInfoById';

/*  合同管理 - 支出明细 -  更新 */
const DISBURSE_INFO_UPDATE = '/apis//api/contract/updateDisburseInfo';

export {
    ADD_CONTRACT,
    QUERY_CONTRACT_PAGE,
    QUERY_CONTRACT_LIST,
    CONTRACT_DETAIL,
    CONTRACT_UPDATE,
    

    INCOME_INFO_ADD,
    INCOME_INFO_PAGE,
    INCOME_INFO_DELETE,
    INCOME_INFO_DETAIL,
    INCOME_INFO_UPDATE,

    DISBURSE_INFO_ADD,
    DISBURSE_INFO_PAGE,
    DISBURSE_INFO_DELETE,
    DISBURSE_INFO_DETAIL,
    DISBURSE_INFO_UPDATE,
}