/*********************************************************************
 * defined home page router file
 * Created by deming-su on 2019/7/5
 *********************************************************************/

/* 获取表单列表数据 */
const HOME_FORM_LIST = "/plat/form/templates/list";

export {
    HOME_FORM_LIST
}