/*
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-19 11:38:59
 */

/* 项目出账信息管理--列表 */
const PROJECT_BILL_LIST = '/apis/api/selManage/queryBillSatInfoList';

/** 项目出账信息管理--下拉选择列表 */
const PROJECT_LIST_FOR_ADD = '/apis/api/project/queryProjectPagedForBill';

/* 项目出账信息管理--新增 */
const PROJECT_BILL_ADD = '/apis/api/selManage/addBillInfo';

/* 项目出账信息管理--查询项目收款信息 */
const PROJECT_BILL_QUERY_INFO = '/apis/api/selManage/queryBillStatInfo';

/* 项目出账信息管理--详情 */
const PROJECT_BILL_DETAIL = '/apis/api/selManage/queryBillInfoById';

/* 项目出账信息管理--修改明细*/
const PROJECT_BILL_MODIFY = '/apis/api/selManage/modifyBillInfo';


export {
    PROJECT_BILL_LIST,
    PROJECT_BILL_ADD,
    PROJECT_BILL_DETAIL,
    PROJECT_BILL_QUERY_INFO,
    PROJECT_LIST_FOR_ADD,
    PROJECT_BILL_MODIFY,
}