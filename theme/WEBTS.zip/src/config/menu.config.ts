/*********************************************************************
 * Interface page of recapping 
 *********************************************************************/

/* 下拉属性枚举 */
const MENU_LIST = '/apis/api/dict/queryList';

export {
    MENU_LIST
}
