/*
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-20 10:01:52
 */
/*********************************************************************
 * defined home page router file
 * Created by deming-su on 2019/7/5
 *********************************************************************/

const HOME_INDEX_URL = "/static/assets";

// 附件接口
const FILE_ADD="/sys/file/add";

// 查询公司下面的人员信息
const QUERY_BY_ORGCODE_AND_ROLE_CODE ='/sys/user/api/queryByOrgCodeAndRoleCode';

const QUERY_USER_BRANCH="/sys/user/queryUserBranch"

/** 统计报表 */
const PROJECT_STATISTICS = "/apis/api/project/sat/execSat";

export {
    HOME_INDEX_URL,
    FILE_ADD,
    QUERY_USER_BRANCH,
    QUERY_BY_ORGCODE_AND_ROLE_CODE,
    PROJECT_STATISTICS
}