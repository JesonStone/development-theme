/*********************************************************************
 * Interface page of recapping 
 *********************************************************************/

/* 1、项目管理项目新增 */
const PROJECT_ADD = '/apis/api/projectInfo/addProject';

/* 1、项目管理项目新增 */
const PROJECT_ALL_PRIJECT = '/apis/api/project/queryAllProject';

/* 2、项目管理项目-下拉 */ 
const PROJECT_INFO_LIST = '/apis/api/project/queryProjectInfoList';

/* 3、项目管理项目-分页 */ 
const PROJECT_INFO_LIST_PAGE ='/apis/api/project/queryProjectInfoPage';

/* 3、项目管理项目-修改 */ 
const UPDATE_PROJECT_INFO ='/apis/api/project/updateProjectInfo';

/* 4、项目管理项目新增-建设单位 */
const COMPANY_TREE ='/sys/org/queryAllBranch';

/* 5、项目管理项目详情 */
const QUERY_PROJECT_ALL_INFO_BY_PID ='/apis/api/projectInfo/queryProjectAllInfoByPid';




export {
    PROJECT_ALL_PRIJECT,
    PROJECT_ADD,
    PROJECT_INFO_LIST,
    PROJECT_INFO_LIST_PAGE,
    COMPANY_TREE,
    QUERY_PROJECT_ALL_INFO_BY_PID,
    UPDATE_PROJECT_INFO
}