declare var document: Document;
declare var socket: any;
declare var getRequestUrlParams: (s: string) => string;


/** 请求地址定义 */
declare var BASE_SERVICE_URL: string;
declare var BASE_FILE_URL: string;
declare module 'crypto-js';
declare module "element-ui/lib/transitions/collapse-transition";
declare module "element-ui";
