/*
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-19 11:34:04
 */

import { RouteConfig } from 'vue-router';


/* 项目出账信息管理主路由 */
const ProjectStatisticsIndex = () => import(/* webpackChunkName: "ProjectStatisticsIndex"*/"../pages/statistics/Index.vue");

/* 项目出账信息管理--列表 */
const ProjectStatisticsList = () => import(/* webpackChunkName: "ProjectStatisticsList"*/"../pages/statistics/tpl/List.vue");



const routes: RouteConfig[] = [
    {
        path: "/statistics",
        component: ProjectStatisticsIndex,
        children: [   
            {path: '', redirect: 'list'},         
            {path: 'list', component: ProjectStatisticsList, meta: { layout: 'main-layout' }},
        ]
    }
];

export default routes;