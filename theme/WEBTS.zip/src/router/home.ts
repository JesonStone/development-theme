/*********************************************************************
 * defined text message page router file
 * Created by deming-su on 2017/12/30
 *********************************************************************/
import { RouteConfig } from 'vue-router';

/* 报告首页路由 */
const MessageIndex = () => {
    return import(/* webpackChunkName: "MessageIndex"*/"../pages/home/Index.vue");
};

const routes: RouteConfig[] = [
    { path: "/home", component: MessageIndex, meta: {  }},
    { path: "/dashboard", component: MessageIndex, meta: {  }},
    { path: "/demand/demand_list", component: MessageIndex, meta: {  }},
    { path: "/demand/demand_presentation", component: MessageIndex, meta: {  }},
    { path: "/home", component: MessageIndex, meta: {  }},
];

export default routes;