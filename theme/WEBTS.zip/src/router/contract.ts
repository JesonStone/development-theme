import { RouteConfig } from 'vue-router';

/* 项目管理路由 */
const ContractIndex = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/Index.vue");

const ContractList = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractList.vue");

const ContractAdd = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractAdd.vue");

// const ContractUpDate= () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractUpDate.vue");

const ContractDetail = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractDetial.vue");

const ContractFlowIn = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractFlowInList.vue");
const ContractFlowInDetail = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractFlowInDetail.vue");
const ContractFlowInAdd = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractFlowInAdd.vue");
const ContractFlowInEdit = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractFlowInEdit.vue");

const ContractFlowOut = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractFlowOutList.vue");
const ContractFlowOutDetail = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractFlowOutDetail.vue");
const ContractFlowOutAdd = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractFlowOutAdd.vue");
const ContractFlowOutEdit = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractFlowOutEdit.vue");
const contractFlowOut = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/contract/tpl/ContractFlowOutList.vue");

const routes: RouteConfig[] = [
    {
        path: "/contract",
        component: ContractIndex,
        children: [            
            {path: 'contractList', component: ContractList, meta: { layout: 'main-layout' }},
            {path: 'contractAdd', component: ContractAdd, meta: { layout: 'main-layout' }},
            // {path: 'contractUpDate', component: ContractUpDate, meta: { layout: 'main-layout' }},
            {path: 'contractDetail', component: ContractDetail, meta: { layout: 'main-layout' }},
            {path: 'contractFlowIn', component: ContractFlowIn, meta: { layout: 'main-layout' }},
            {path: 'contractFlowInDetail', component: ContractFlowInDetail, meta: { layout: 'main-layout' }},
            {path: 'contractFlowInAdd', component: ContractFlowInAdd, meta: { layout: 'main-layout' }},
            {path: 'contractFlowInEdit', component: ContractFlowInEdit, meta: { layout: 'main-layout' }},
            {path: 'contractFlowOut', component: ContractFlowOut, meta: { layout: 'main-layout' }},
            {path: 'contractFlowOutDetail', component: ContractFlowOutDetail, meta: { layout: 'main-layout' }},
            {path: 'contractFlowOutAdd', component: ContractFlowOutAdd, meta: { layout: 'main-layout' }},
            {path: 'contractFlowOutEdit', component: ContractFlowOutEdit, meta: { layout: 'main-layout' }},
            {path: 'contractFlowOut', component: contractFlowOut, meta: { layout: 'main-layout' }}
        ]
    }
];

export default routes;