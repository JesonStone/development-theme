/*********************************************************************
 * defined common node router file
 * Created by deming-su on 2019/11/13
 *********************************************************************/

/* 通用路由--用户权限认证页面 */
import { RouteConfig } from 'vue-router';

const AuthenticationIndex = () => import(/* webpackChunkName: "AuthenticationIndex"*/"../pages/common/Authentication.vue");

/* 通用路由--无权限页面 */
const NotRightIndex = () => import(/* webpackChunkName: "NotRightIndex"*/"../pages/common/NotRight.vue");

/* 通用路由--无路由页面 */
const NotFoundIndex = () => import(/* webpackChunkName: "NotFoundIndex"*/"../pages/common/NotFound.vue");

/* 自定义配置--首页路由 */
const HomeIndex = () => import(/* webpackChunkName: "HomeIndex"*/"../pages/home/Index.vue");

const LoginNode = () => import(/* webpackChunkName: "LoginNode"*/"../pages/common/Login.vue");


const routes: RouteConfig[] = [
    { path: "/", redirect: '/sys/cms/login' },
    { path: '/authentication', component: AuthenticationIndex, meta: {layout: 'blank-layout'} },
    { path: '/not/right', component: NotRightIndex, meta: {layout: 'blank-layout'} },
    { path: '/not/found', component: NotFoundIndex, meta: {layout: 'blank-layout'} },
    { path: "/sys/cms/login", component: LoginNode, meta: { layout: 'blank-layout'} }
];

export default routes;
