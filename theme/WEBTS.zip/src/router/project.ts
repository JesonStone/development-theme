/*
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-19 11:17:44
 */
/* 项目管理路由 */
import { RouteConfig } from 'vue-router';

const ProjectIndex = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/project/Index.vue");

const ProjectList = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/project/tpl/ProjectList.vue");

const ProjectDetail = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/project/tpl/ProjectDetail.vue");

const ProjectAdd = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/project/tpl/ProjectAdd.vue");

// const ProjectUpdate=()=>import(/* webpackChunkName: "NotFoundNode"*/"../pages/project/tpl/ProjectUpdate.vue");

const ProjectLedgerList = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/project/tpl/ProjectLedgerList.vue");

const ProjectLedgerDetail = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/project/tpl/ProjectLedgerDetail.vue");


const routes : RouteConfig[] = [
    {
        path: "/project",
        component: ProjectIndex,
        children: [            
            {path: 'projectList', component: ProjectList, meta: { layout: 'main-layout' }},
            {path: 'projectDetail', component: ProjectDetail, meta: { layout: 'main-layout' }},
            {path: 'projectAdd', component: ProjectAdd, meta: { layout: 'main-layout' }},
            {path: 'projectLedgerDetail', component: ProjectLedgerDetail, meta: { layout: 'main-layout' }},
            {path: 'projectLedgerList', component: ProjectLedgerList, meta: { layout: 'main-layout' }}
        ]
    }
    
];

export default routes;