/*
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-19 11:34:04
 */
/* 项目出账信息管理主路由 */
import { RouteConfig } from 'vue-router';

const ProjectBillIndex = () => import(/* webpackChunkName: "ProjectBillIndex"*/"../pages/projectBill/Index.vue");

/* 项目出账信息管理--列表 */
const ProjectBillList = () => import(/* webpackChunkName: "ProjectBillList"*/"../pages/projectBill/tpl/List.vue");

/* 项目出账信息管理--新增 */
const ProjectBillAdd = () => import(/* webpackChunkName: "ProjectBillAdd"*/"../pages/projectBill/tpl/Add.vue");

/* 项目出账信息管理--详情 */
const ProjectBillDetail = () => import(/* webpackChunkName: "ProjectBillDetail"*/"../pages/projectBill/tpl/Detail.vue");

/* 项目出账信息管理--编辑 */
const ProjectBillEdit = () => import(/* webpackChunkName: "ProjectBillDetail"*/"../pages/projectBill/tpl/Edit.vue");

const routes: RouteConfig[] = [
    {
        path: "/projectbill",
        component: ProjectBillIndex,
        children: [   
            {path: '', redirect: 'list'},         
            {path: 'list', component: ProjectBillList, meta: { layout: 'main-layout' }},
            {path: 'add', component: ProjectBillAdd, meta: { layout: 'main-layout' }},
            {path: 'detail', component: ProjectBillDetail, meta: { layout: 'main-layout' }},
            {path: 'edit', component: ProjectBillEdit, meta: { layout: 'main-layout' }},
        ]
    }
];

export default routes;