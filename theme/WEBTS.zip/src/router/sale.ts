import { RouteConfig } from 'vue-router';

/* 售中路由 */
const SaleIndex = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/sale/Index.vue");

const SaleFlowList = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/sale/tpl/SaleFlowList.vue");

const SaleFlowDetail = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/sale/tpl/SaleFlowDetail.vue");

// const SaleFlowAdd = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/sale/tpl/SaleFlowAdd.vue");

// const SaleFlow = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/sale/tpl/SaleFlow.vue");

// const SaleFlowUpdate = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/sale/tpl/SaleFlowUpdate.vue");



const routes: RouteConfig[] = [
    {
        path: "/sale",
        component: SaleIndex,
        children: [            
            {path: 'saleFlowList', component: SaleFlowList, meta: { layout: 'main-layout' }},
            {path: 'saleFlowDetail', component: SaleFlowDetail, meta: { layout: 'main-layout' }},
            // {path: 'saleFlowAdd', component: SaleFlowAdd, meta: { layout: 'main-layout' }},
            // {path: 'saleFlow', component: SaleFlow, meta: { layout: 'main-layout' }},
            // {path: 'saleFlowUpdate', component: SaleFlowUpdate, meta: { layout: 'main-layout' }}
        ]
    }   
];

export default routes;