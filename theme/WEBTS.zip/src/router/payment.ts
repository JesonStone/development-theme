/*
 * @Descripttion: 
 * @Author: zhixiang-bai
 * @Date: 2020-03-19 11:17:44
 */
/* 项目管理路由 */
import { RouteConfig } from 'vue-router';

const PayMentIndex = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/payment/Index.vue");

const PayMentList = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/payment/tpl/List.vue");

const PayMentDetail = () => import(/* webpackChunkName: "NotFoundNode"*/"../pages/payment/tpl/Detail.vue");

const PayMentAdd = () => import(/* webpackChunkName: "PayMentAdd"*/"../pages/payment/tpl/Add.vue");

const PayMentEdit = () => import(/* webpackChunkName: "PayMentAdd"*/"../pages/payment/tpl/Edit.vue");

const routes: RouteConfig[] = [
    {
        path: "/payment",
        component: PayMentIndex,
        children: [            
            {path: 'list', component: PayMentList, meta: { layout: 'main-layout' }},
            {path: 'detail', component: PayMentDetail, meta: { layout: 'main-layout' }},
            {path: 'add', component: PayMentAdd, meta: { layout: 'main-layout' }},
            {path: 'edit', component: PayMentEdit, meta: { layout: 'main-layout' }}
        ]
    }
];

export default routes;