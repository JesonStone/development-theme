"use strict";

/* 加载vue核心组件 */
import Vue, {CreateElement} from 'vue';
import Component from 'vue-class-component';

/* 加载vue状态管理器 */
import store from './store';

/* 注入路由生命周期-ts */
Component.registerHooks([
    "beforeRouteEnter",
    "beforeRouteLeave",
    "beforeRouteUpdate"
]);

/* 加载模块路由 */
import router from './router/index';

/* 引入容器页面 */
import Index from "./pages/Index.vue";

/* 加载全局过滤器/指令 */
import GlobalComponent from "./components/index";
Vue.use(GlobalComponent);

/* 引入element-ui组件库 */
import ElementUI from "element-ui";
import "element-ui/lib/theme-chalk/index.css";
Vue.use(ElementUI);

/* 引入页面样式文件 */
import './styles/main.less';

new Vue({
    el: "#mainContent",
    router,
    store,
    data: {
        eventBus: new Vue()
    },
    render(createElement: CreateElement) {
        if (this.$route.path === "/") {
            return createElement("div");
        }

        let routeMeta = this.$route.meta,
            props: { layout?: string } = {};

        if (routeMeta && routeMeta.layout) {
            props.layout = routeMeta.layout;
        }
        return createElement(Index, {props});
    }
});

if ((process.env.NODE_ENV as string).trim() === "production") {
    Vue.config.silent = true;
    Vue.config.productionTip = false;
}
