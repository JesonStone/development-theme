/*********************************************************************
 * Common ajax api
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import Ajax from "../util/request";
import UrlConfig from "../config/UrlConfig";

/**
 * 通过 params 以get方式获取数据
 * @param      key                 请求定义静态地址
 * @param      params              请求参数
 * @return     {Promise<*>}        返回promise对象
 */
let getDataRequest = (key: string, params?: any): Promise<any> => {
    return Ajax({
        url: new UrlConfig(key).currentUrl,
        params
    });
};

/**
 * 通过 data 以post方式提交数据
 * @param      key                 请求定义静态地址
 * @param      data                请求参数
 * @return     {Promise<*>}        返回promise对象
 */
let postDataRequest = (key: string, data?: any): Promise<any> => {
    return Ajax({
        method: 'POST',
        url: new UrlConfig(key).currentUrl,
        data
    });
};

/**
 * 通过FormData以post方式提交文件并获取文件上传进度
 * @param      key                 请求定义静态地址
 * @param      data                请求参数
 * @param      onUploadProgress    上传进度
 * @return     {Promise<*>}        返回promise对象
 */
let postFileRequest = (key: string, data: any, onUploadProgress: (data: any) => void) => {
    return Ajax({
        method: 'POST',
        url: new UrlConfig(key).currentUrl,
        data,
        onUploadProgress
    });
};

/**
 * 返回一个完整请求地址
 * @param      key                 请求定义静态地址
 * @param      flag                请求参数
 * @return     string              返回promise对象
 */
let getFullUrl = (key: string, flag: boolean = false): string => {
    if (flag) return new UrlConfig(key).currentUrl;
    return `${new UrlConfig('BASE_URL').currentUrl}${new UrlConfig(key).currentUrl}`;
};

/**
 * 引用页面用法释义
 * import { getDataRequest } form "@/api/common";
 * async getFunc()
 * let result = await getDataRequest('', {});
 */

let getRequestMethod = (key: string, params: Object, name: string) => {
    if (!key || key.trim() === '') return {code: 600, message: '请求地址为空'};
    let url = name ? new UrlConfig(key).currentUrl + name : new UrlConfig(key).currentUrl;
    return Ajax({
        url: url as string,
        params
    });
};


/**
 * post 请求方法 （如果有上传进度方法或需要转码，都默认为form提交，提交类型也默认）
 * @param {String}      key                请求地址key
 * @param {Object}      data               请求参数
 * @param {Function}    onUploadProgress   form提交进度回调函数
 * @param {Boolean}     encode             是否需要转码
 */
let postRequestMethod = (key: string, data: any, onUploadProgress: ()=>void, encode: string) => {
    if (!key || key.trim() === '') return {code: 600, message: '请求地址为空'};
    return Ajax({
        method: "POST",
        url: new UrlConfig(key).currentUrl,
        contentType: !!onUploadProgress || encode !== undefined ? 'application/x-www-form-urlencoded' : undefined,
        onUploadProgress,
        data
    });
};

/**
 * put  请求方法 （如果有上传进度方法或需要转码，都默认为form提交，提交类型也默认）
 * @param {String}      key                请求地址key
 * @param {Object}      data             请求参数
 */
let putRequestMethod = (key: string, data: any): any => {
    if (!key || key.trim() === '') return {code: 600, message: '请求地址为空'};
    return Ajax({
        method: "PUT",
        url: new UrlConfig(key).currentUrl,
        data
    });
};


export {
    getRequestMethod,
    getDataRequest,
    postDataRequest,
    postFileRequest,
    getFullUrl,
    postRequestMethod,
    putRequestMethod,
};
